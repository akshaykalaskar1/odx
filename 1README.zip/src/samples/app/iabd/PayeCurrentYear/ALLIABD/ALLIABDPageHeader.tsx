import { Heading } from 'hmrc-gds-react-components';
import React from 'react';
import { useTranslation } from 'react-i18next';

interface ALLIABDHeaderProps {
  isDetailsAvailable?: boolean;
}

const ALLIABDHeader: React.FC<ALLIABDHeaderProps> = ({ isDetailsAvailable }) => {
  const { t } = useTranslation();

  return (
    <div className='govuk-grid-row'>
      <div className='govuk-grid-column-two-thirds'>
        <Heading headingLevel={1} className='govuk-heading-xl'>
          {t('OTHER_INCOMES_IABD')}
        </Heading>
        {isDetailsAvailable ? (
          <>
            <p className='govuk-body'>{t('LIST_SHOWS_ALL_PAY_AS_YOU_EARN')}</p>

            <div className='govuk-inset-text'>
              <p className='govuk-body'>{t('AMOUNT_DO_NOT_ACCOUNT_PERSONAL_RELIEFS')}</p>
            </div>
          </>
        ) : (
          <p className='govuk-body'>{t('NO_INCOME_OTHER_SOURCE')}</p>
        )}
      </div>
    </div>
  );
};

export default ALLIABDHeader;
