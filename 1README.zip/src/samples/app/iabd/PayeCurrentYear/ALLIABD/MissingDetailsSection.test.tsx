import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import MissingDetailLinksSection from './MissingDetailsSection';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

const mockAppendLangParam = jest.fn((url: string) => `mocked-${url}`);

jest.mock('../../../../../components/helpers/utils', () => ({
  appendLangParam: (url: string) => mockAppendLangParam(url)
}));

describe('MissingDetailLinksSection (BDD)', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Given component renders', () => {
    test('Then it shows header and descriptive text', () => {
      render(<MissingDetailLinksSection />);

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_DETAILS_HEADER')).toBeInTheDocument();

      expect(screen.getByText('MISSING_DETAILS_LINKS.IF_YOU_NOTICE_SOMETHING_MISSING')).toBeInTheDocument();
    });
  });

  describe('Given links are present', () => {
    test('Then all expected links are rendered', () => {
      render(<MissingDetailLinksSection />);

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK')).toBeInTheDocument();

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_LINK')).toBeInTheDocument();

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_INVESTMENT_INCOME_LINK')).toBeInTheDocument();

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_COMPANY_BENEFIT_LINK')).toBeInTheDocument();

      expect(screen.getByText('MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_EXTERNAL_LINK')).toBeInTheDocument();
    });
  });

  describe('Given appendLangParam is used', () => {
    test('Then links contain modified href values', () => {
      render(<MissingDetailLinksSection />);

      const links = screen.getAllByRole('link');

      links.forEach(link => {
        expect(link).toHaveAttribute('href', expect.stringContaining('mocked-'));
      });

      expect(mockAppendLangParam).toHaveBeenCalled();
    });
  });

  describe('Given all links are rendered', () => {
    test('Then correct number of links exist', () => {
      render(<MissingDetailLinksSection />);

      const links = screen.getAllByRole('link');

      expect(links).toHaveLength(5);
    });
  });

  describe('Given links have tracking attributes', () => {
    test('Then each link has tracking metadata', () => {
      render(<MissingDetailLinksSection />);

      const links = screen.getAllByRole('link');

      links.forEach(link => {
        expect(link).toHaveAttribute('data-tracking-type', 'Outbound');
        expect(link).toHaveAttribute('data-tracking-target');
      });
    });
  });
});
