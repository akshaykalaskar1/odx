import { useState, useEffect, useCallback, MouseEvent } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import AppHeader from '../../../components/AppComponents/AppHeader';
import AppFooter from '../../../components/AppComponents/AppFooter';
import setPageTitle from '../../../components/helpers/setPageTitleHelpers';
import TimeoutPopup from '../../../components/AppComponents/TimeoutPopup';
import ServiceNotAvailable from '../../../components/AppComponents/ServiceNotAvailable';
import { DetailsTypes } from './PayeCurrentYear/PayeCurrentYearTypes';
import NavBar from '../../../components/helpers/navbar/navbar';
import NavBarMobile from '../../../components/helpers/navbar/navbarMobile';
import { useStartMashup } from '../../../reuseables/PegaSetup';
import { TimeLineEvent } from '../../../reuseables/Types/TimeLineEvents';
// import { addDeviceIdCookie } from '../../../components/helpers/cookie';
import { appendLangParam, triggerLogout } from '../../../components/helpers/utils';
import { staySignedIn, settingTimer, initTimeout } from '../../../components/AppComponents/TimeoutPopup/timeOutUtils';
import { getServiceShutteredStatus } from '../../../components/helpers/utils';
import { AnalyticsConfigProvider, AnalyticsPayload } from 'hmrc-odx-features-and-functions';
import useServiceShuttered from '../../../components/helpers/hooks/useServiceShuttered';
import LoadingWrapper from '../../../components/helpers/LoadingSpinner/LoadingWrapper';
import ShutteredServiceWrapper from '../../../components/AppComponents/ShutterService/ShutteredServiceWrapper';
import PAYE_ROUTES from '../../AppSelector/payeRoutes';
import useNavigationEffects from '../../../components/helpers/hooks/useNavigationEffects';
import useCustomNavigate from '../../../components/helpers/hooks/useCustomNavigate';

let milisecondsTilSignout = 115 * 1000;
export declare const PCore: any;

export default function Iabd() {
  const [showTimeoutModal, setShowTimeoutModal] = useState(false);
  const [employmentTaxData, setEmploymentTaxData] = useState(null);
  const [accessGroup, setAccessGroup] = useState<string>('');
  const [dynamicDisabledIABDDetails, setDynamicDisabledIABDDetails] = useState<boolean>(false);
  const [navClickHandler, setNavClickHandler] = useState(null);
  const [customerDetails, setCustomerDetails] = useState(null);
  const [isMobileView, setIsMobileView] = useState(window.innerWidth <= 770);

  const [isPCoreReady, setIsPCoreReady] = useState(false);
  const [annualCodingData, setAnnualCodingData] = useState(null);
  const [taxYearStartDate, setTaxYearStartDate] = useState('');
  const [isLoading, setIsLoading] = useState(!isPCoreReady);
  const [serviceIsShuttered, setServiceIsShuttered] = useState(false);

  const { serviceShuttered, isLoading: isShutteredServiceLoading } = useServiceShuttered();
  const { t } = useTranslation();
  const location = useLocation();

  useNavigationEffects(setShowTimeoutModal);
  const goTo = useCustomNavigate();

  const handleResize = () => {
    setIsMobileView(window.innerWidth <= 770);
  };

  type payeDynamicEmpPension = {
    EmploymentEndLeavingPeriod: number;
    MissingEmploymentPayPeriod: number;
    PensionPayPeriod: number;
    PensionEndLeavingPeriod: number;
    IncomeThresholdForWinterFuelPayment: number;
    NextTaxStartYear: number;
  };

  const [dynamicIABDVals, setDynamicIABDVals] = useState<payeDynamicEmpPension>();

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // This needs to be changed in future when we handle the shutter for multiple service, for now this one's for single service
  const featureID = 'PAYE';

  const {
    showPega,
    setShowPega,
    showResolutionPage,
    setShowResolutionPage,
    caseId,
    serviceNotAvailable,
    shutterServicePage,
    renderRootComponent,
    rootProps
  } = useStartMashup({
    appBacklinkProps: {},
    appNameHeader: featureID
  });

  function resetAppDisplay() {
    setShowPega(false);
  }

  useEffect(() => {
    setPageTitle();
  }, [showPega, shutterServicePage]);

  // Function to force re-render the pega Root component
  const forceRefreshRootComponent = () => {
    renderRootComponent();
  };

  useEffect(() => {
    if (Object.keys(rootProps).length) {
      PCore.getPubSubUtils().subscribe('forceRefreshRootComponent', forceRefreshRootComponent, 'forceRefreshRootComponent');
    }
    return () => {
      PCore?.getPubSubUtils().unsubscribe('forceRefreshRootComponent', 'forceRefreshRootComponent');
    };
  }, [rootProps]);

  const getShutteredService = async () => {
    setIsLoading(true);
    const status: boolean = await getServiceShutteredStatus();
    setServiceIsShuttered(status);
    setIsLoading(false);
    return status;
  };

  async function startNow(e: MouseEvent<HTMLAnchorElement, MouseEvent>, caseType: string, startPageUrl: string) {
    e.preventDefault();
    goTo(startPageUrl, { caseType });
  }

  async function showPegaView() {
    setShowPega(true);
  }

  function beginClaim() {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_EMPLOYMENT);
  }

  function beginIntrruptionPage(
    TheEmploymentSequenceNumber: number,
    handleNavClick: (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, path: string) => void,
    fromPage: string
  ) {
    staySignedIn(setShowTimeoutModal, true);
    setNavClickHandler(() => handleNavClick);
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.INTERRUPTION, {
      employmentSequenceNumber: TheEmploymentSequenceNumber,
      previousPage: fromPage
    });
  }

  function beginUpdateEstimatedTaxableIncomePage(
    details: DetailsTypes,
    handleNavClick: (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, path: string) => void,
    tesUrl: string
  ) {
    staySignedIn(setShowTimeoutModal, true);

    setNavClickHandler(() => handleNavClick);

    goTo(`${location.pathname}/update-estimated-taxable-income`, {
      employerName: details.EmployerName,
      estimatedPay: details.EstimatedPay,
      tesUrl
    });
  }

  function beginUpdateClaim() {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_EMPLOYMENT);
  }

  function beginAddPensionClaim() {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_PENSION);
  }

  function beginUpdatePensionClaim() {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_PENSION);
  }
  function redirectCurrentYearPage(options: { backOverride?: string; replace?: boolean }) {
    setShowResolutionPage(false);

    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.SUMMARY, {
      backOverride: options?.backOverride,
      replace: options?.replace ?? false
    });
  }

  function redirectAnnualCodingTemplatePage({ templateValue, pageName }: { templateValue: string; pageName: string }) {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.ANNUAL_CODING, { templateValue, pageName });
  }

  function redirectLandingPage() {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING);
  }

  function redirecLatestEventPage(fromPage) {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.LATEST_EVENTS, { fromPage });
  }

  function redirectToAllIABDLandingPage(fromPage) {
    goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.OTHER_INCOME_ALLOWANCES, { comingFromPage: fromPage });
  }
  function redirectToUnderstandYourTaxPage() {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.UNDERSTAND_YOUR_TAX);
  }

  function redirectToViewTimelineDetailsPage(fromPage: string = '', timelineDetails?: TimeLineEvent, eventType?: string) {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS, {
      comingFromPage: fromPage,
      timelineDetails,
      eventType
    });
  }

  function redirectToDeductionExplainerpage(comingFrom: string, explainerPage: string, SourceAmount: string) {
    const routeMap: Record<string, string> = {
      winterFuelPaymentIABDPage: PAYE_ROUTES.RESTRICTED_REDIRECTION.WINTER_FUEL_PAYMENT,
      untaxedsavingsinterest: PAYE_ROUTES.RESTRICTED_REDIRECTION.UNTAXED_SAVINGS_INTEREST,
      winterfuelpaymentcharge: PAYE_ROUTES.RESTRICTED_REDIRECTION.WINTER_FUEL_PAYMENT_CHARGE
    };

    goTo(routeMap[explainerPage], {
      comingFromPage: comingFrom,
      sourceAmount: SourceAmount
    });
  }

  function returnToPortalPage() {
    staySignedIn(setShowTimeoutModal, true);
    PCore.getContainerUtils().closeContainerItem(PCore.getContainerUtils().getActiveContainerItemContext('app/primary'), { skipDirtyCheck: true });
  }

  async function fetchDynamicValue() {
    try {
      const dataViewName = 'D_PAYEDynamicConfig';
      const parameters = { Inputparam: '' };
      const context = 'app/primary_1';
      const options = { invalidateCache: true };
      const res = await PCore.getDataPageUtils().getPageDataAsync(dataViewName, context, parameters, options);
      return res;
    } catch (error) {
      console.error('Error fetching employment tax data:', error);
      return null;
    }
  }

  async function fetchDynamicValueData() {
    try {
      const data = await fetchDynamicValue();
      setDynamicDisabledIABDDetails(data?.DisabledIABDDetails);
      setDynamicIABDVals({
        EmploymentEndLeavingPeriod: data?.EmploymentEndLeavingPeriod,
        MissingEmploymentPayPeriod: data?.MissingEmploymentPayPeriod,
        PensionPayPeriod: data?.PensionPayPeriod,
        PensionEndLeavingPeriod: data?.PensionEndLeavingPeriod,
        IncomeThresholdForWinterFuelPayment: data?.IncomeThresholdForWinterFuelPayment,
        NextTaxStartYear: data?.NextTaxStartYear
      });
    } catch (error) {
      console.log(error);
    }
  }

  async function addDeviceId() {
    try {
      // await addDeviceIdCookie();
    } catch (error) {
      console.log(error);
    }
  }

  async function fetchMDTPData(link) {
    const parameters = {
      ContinueURL: link
    };
    try {
      const res = await PCore.getDataPageUtils().getPageDataAsync('D_PAYERedirectURL', 'root', parameters);

      return res;
    } catch (error) {
      console.error('Error fetching employment tax data:', error);
      return null;
    }
  }

  async function handleLinkClick(link) {
    try {
      const data = await fetchMDTPData(link);
      window.location.href = appendLangParam(data.pyURLContent);
    } catch (error) {
      console.log(error);
    }
  }

  const publishAnalyticsEventToPega = useCallback(async (payload: AnalyticsPayload) => {
    PCore.getDataPageUtils().getPageDataAsync(
      'D_OnClientAction',
      'root',
      { ...payload },
      {
        invalidateCache: true
      }
    );
  }, []);

  const handleSummaryLinkClick = useCallback(
    event => {
      try {
        const element = event.target as HTMLElement | null;
        const link = element?.closest('a');
        const targetIsHomepageLink = link?.id?.toLowerCase() === 'homepage';

        if (targetIsHomepageLink) {
          event.preventDefault();
          event.stopPropagation();
          resetAppDisplay();
          goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.SUMMARY, { replace: true });

          redirectCurrentYearPage({
            backOverride: PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING,
            replace: true
          });
        }
      } catch (err) {
        console.error('Error with summary link click:', err);
      }
    },
    [redirectCurrentYearPage]
  );

  useEffect(() => {
    document.addEventListener('click', handleSummaryLinkClick);
    return () => {
      document.removeEventListener('click', handleSummaryLinkClick);
    };
  }, [handleSummaryLinkClick]);

  useEffect(() => {
    if (isPCoreReady) {
      PCore.getPubSubUtils().subscribe(
        'languageToggleTriggered',
        () => {
          getShutteredService();
        },
        'summarypageLanguageChange'
      );
      return () => {
        PCore.getPubSubUtils().unsubscribe('languageToggleTriggered', 'summarypageLanguageChange');
      };
    }
  }, [isPCoreReady]);

  useEffect(() => {
    if (!showResolutionPage) {
      return;
    }

    goTo(`${location.pathname}/status`);
  }, [showResolutionPage, caseId]);

  document.addEventListener('SdkConstellationReady', () => {
    PCore.onPCoreReady(() => {
      setIsPCoreReady(true);
    });
    settingTimer();
  });

  useEffect(() => {
    (async () => {
      if (isPCoreReady) {
        try {
          setIsLoading(true);
          await Promise.all([addDeviceId(), fetchDynamicValueData()]);
          const sdkConfig = await getSdkConfig();
          if (sdkConfig.timeoutConfig.secondsTilLogout) {
            milisecondsTilSignout = sdkConfig.timeoutConfig.secondsTilLogout * 1000;
          }

          // Subscribe to any store change to reset timeout counter
          PCore.getStore().subscribe(() => staySignedIn(setShowTimeoutModal, false));
          initTimeout(setShowTimeoutModal);
        } catch {
          return false;
        } finally {
          setIsLoading(false);
        }
      }
    })();
  }, [isPCoreReady]);

  const handleViewAllDetailsClick = (detail: DetailsTypes) => {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_ALL_DETAILS, { details: detail });
  };

  const handleUnderstandYourTaxCodeClick = (understandYourTax: DetailsTypes, taxCode: string, fromPage: string) => {
    goTo(
      taxCode === 'defaulttaxcode'
        ? PAYE_ROUTES.RESTRICTED_REDIRECTION.UNDERSTAND_YOUR_TAX
        : PAYE_ROUTES.RESTRICTED_REDIRECTION.UNDERSTAND_YOUR_TAX_SPECIAL,
      {
        understandYourTaxDetails: understandYourTax,
        fromPage
      }
    );
  };

  const handleMoreInformationClick = (ComponentName: string) => {
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.WINTER_FUEL_PAYMENT, { ComponentName });
  };

  const handleViewDetailsClick = (timeline: TimeLineEvent, event: string) => {
    let url: string = PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS;
    if (timeline?.pyTemplateDataField === 'P2TAXCODE') {
      url = PAYE_ROUTES.RESTRICTED_REDIRECTION.P2_EXPLAINER;
    }

    goTo(url, {
      timelineDetails: timeline,
      eventType: event,
      comingFromPage: ''
    });
  };

  const handleDetailExplainerLinkClick = (e: MouseEvent, ComponentName: string) => {
    e.preventDefault();
    goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.DETAIL_EXPLAINER, { componentName: ComponentName });
  };

  const renderContent = () => {
    return (
      <>
        <div id='pega-part-of-page' aria-hidden={showResolutionPage}>
          <div id='pega-root'></div>
        </div>
        {!showPega && (
          <AnalyticsConfigProvider apiCallback={publishAnalyticsEventToPega}>
            <ShutteredServiceWrapper serviceIsShuttered={serviceIsShuttered || shutterServicePage || serviceShuttered}>
              <LoadingWrapper
                pageIsLoading={isLoading || isShutteredServiceLoading}
                spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}
              >
                <Outlet
                  context={{
                    employmentTaxData,
                    setEmploymentTaxData,
                    dynamicIABDVals,
                    dynamicDisabledIABDDetails,
                    annualCodingData,
                    setAnnualCodingData,
                    setTaxYearStartDate,
                    taxYearStartDate,
                    handleLinkClick,
                    beginClaim,
                    beginIntrruptionPage,
                    beginUpdateEstimatedTaxableIncomePage,
                    beginUpdateClaim,
                    beginAddPensionClaim,
                    beginUpdatePensionClaim,
                    redirectLandingPage,
                    redirectCurrentYearPage,
                    redirectToAllIABDLandingPage,
                    redirecLatestEventPage,
                    redirectToUnderstandYourTaxPage,
                    redirectToViewTimelineDetailsPage,
                    redirectAnnualCodingTemplatePage,
                    redirectToDeductionExplainerpage,
                    handleViewAllDetailsClick,
                    handleViewDetailsClick,
                    handleUnderstandYourTaxCodeClick,
                    handleDetailExplainerLinkClick,
                    handleMoreInformationClick,
                    navClickHandler,
                    startNow,
                    setCustomerDetails,
                    customerDetails,
                    setAccessGroup,
                    accessGroup,
                    showPegaView,
                    resetAppDisplay,
                    getShutteredService,
                    caseId,
                    showResolutionPage
                  }}
                />
              </LoadingWrapper>
            </ShutteredServiceWrapper>
          </AnalyticsConfigProvider>
        )}
      </>
    );
  };

  return (
    <>
      <TimeoutPopup
        signoutHandler={() => triggerLogout(true)}
        show={showTimeoutModal}
        staySignedinHandler={(e: MouseEvent) => {
          e?.preventDefault();
          staySignedIn(setShowTimeoutModal, true);
        }}
        milisecondsTilSignout={milisecondsTilSignout}
        isAuthorised
      />
      <AppHeader />
      {isMobileView ? (
        <NavBarMobile
          handleSignout={(e: MouseEvent) => {
            e.preventDefault();
            triggerLogout(false);
          }}
          milisecondsTilSignout={milisecondsTilSignout}
          handleLinkClick={handleLinkClick}
          hasLanguageToggle
        />
      ) : (
        <NavBar
          handleSignout={(e: MouseEvent) => {
            e.preventDefault();
            triggerLogout(false);
          }}
          milisecondsTilSignout={milisecondsTilSignout}
          handleLinkClick={handleLinkClick}
          hasLanguageToggle
        />
      )}

      <div className='govuk-width-container'>
        {serviceNotAvailable ? <ServiceNotAvailable returnToPortalPage={returnToPortalPage} /> : <>{renderContent()}</>}
      </div>

      <AppFooter />
    </>
  );
}
