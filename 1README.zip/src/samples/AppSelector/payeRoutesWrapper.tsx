import { MouseEvent } from 'react';
import LandingPage from '../app/iabd/LandingPage';
import PayeCurrentYear from '../app/iabd/PayeCurrentYear/PayeCurrentYear';
import AddEmpStartPage from '../app/iabd/StartPage/AddEmpStartPage';
import UpdateEmpStartPage from '../app/iabd/StartPage/UpdateEmpStartPage';
import AddPensionStartPage from '../app/iabd/StartPage/AddPensionStartPage';
import UpdatePensionStartPage from '../app/iabd/StartPage/UpdatePensionStartPage';
import InterruptionPage from '../app/iabd/InterruptionPage/InterruptionPage';
import UpdateEstimatedTaxableIncomePage from '../app/iabd/PayeCurrentYear/UpdateEstimatedTaxableIncomePage';
import LatestEventsPage from '../app/iabd/LatestEvents/LatestEventsPage';
import ViewAllDetails from '../app/iabd/PayeCurrentYear/ViewAllDetails';
import AllIABDLanding from '../app/iabd/PayeCurrentYear/ALLIABD/AllIABDLanding';
import ViewTimelineDetails from '../app/iabd/PayeCurrentYear/ViewTimelineDetails';
import DetailExplainer from '../app/iabd/PayeCurrentYear/DetailExplainer';
import UnderstandYourTaxCodePage from '../app/iabd/PayeCurrentYear/UnderstandYourTaxCodePage';
import UnderstandYourTaxForSpecialPage from '../app/iabd/PayeCurrentYear/UnderstandYourTaxForSpecialPage';
import AnnualCodingTemplate from '../app/iabd/AnnualCodingTemplate/AnnualCodingTemplate';
import WinterFuelExplainerPage from '../app/iabd/PayeCurrentYear/WinterFuelExplainerPage';
import UntaxedSavingsInterestPage from '../app/iabd/PayeCurrentYear/UntaxedSavingsInterestPage';
import TaxCodeExplainerWFP from '../app/iabd/PayeCurrentYear/WinterFuelPaymentPages/TaxCodeExplainerWFP';
import withIabdRoute from './withIabdRoute';
import P2Explainer from '../app/iabd/PayeCurrentYear/P2Explainer';
import { TimeLineContentObj } from '../../reuseables/Types/TimeLineEvents';
import PegaCaseContainer from '../app/iabd/StartPage/PegaCaseContainer';
import SummaryPage from '../../components/AppComponents/SummaryPage';

export const PayeLandingRoute = withIabdRoute(LandingPage, ({ outlet }) => ({
  pageName: 'Pay As You Earn (PAYE)',
  redirectCurrentYearPage: outlet.redirectCurrentYearPage,
  handleLinkClick: outlet.handleLinkClick,
  userFullName: outlet.customerDetails?.pyFullName,
  redirectAnnualCodingTemplatePage: outlet.redirectAnnualCodingTemplatePage
}));

export const PayeSummaryRoute = withIabdRoute(PayeCurrentYear, ({ outlet, state }) => ({
  pageName: 'Your Pay As You Earn summary',
  userFullName: outlet.customerDetails?.pyFullName,
  beginClaim: outlet.beginClaim,
  beginIntrruptionPage: outlet.beginIntrruptionPage,
  beginUpdateEstimatedTaxableIncomePage: outlet.beginUpdateEstimatedTaxableIncomePage,
  beginUpdateClaim: outlet.beginUpdateClaim,
  beginAddPensionClaim: outlet.beginAddPensionClaim,
  beginUpdatePensionClaim: outlet.beginUpdatePensionClaim,
  employmentTaxData: outlet.employmentTaxData,
  dynamicDisabledIABDDetails: outlet.dynamicDisabledIABDDetails,
  handleLinkClick: outlet.handleLinkClick,
  redirectLandingPage: outlet.redirectLandingPage,
  redirectToAllIABDLandingPage: outlet.redirectToAllIABDLandingPage,
  redirecLatestEventPage: outlet.redirecLatestEventPage,
  handleViewAllDetailsClick: outlet.handleViewAllDetailsClick,
  handleViewDetailsClick: outlet.handleViewDetailsClick,
  handleUnderstandYourTaxCodeClick: outlet.handleUnderstandYourTaxCodeClick,
  setEmpTaxData: outlet.setEmploymentTaxData,
  setAnnualCodingData: outlet.setAnnualCodingData,
  setTaxYearStartDate: outlet.setTaxYearStartDate,
  backOverride: state?.backOverride
}));

export const PegaCaseInitiatedRoute = withIabdRoute(PegaCaseContainer, ({ outlet, state }) => ({
  caseType: state.caseType,
  redirectPath: state.redirectPath,
  employmentTaxData: outlet.employmentTaxData,
  showPegaView: () => outlet.showPegaView(),
  resetAppDisplay: outlet.resetAppDisplay,
  getShutteredService: outlet.getShutteredService,
  showResolutionPage: outlet.showResolutionPage
}));

export const AddEmploymentRoute = withIabdRoute(AddEmpStartPage, ({ outlet }) => ({
  resetAppDisplay: outlet.resetAppDisplay,
  dynamicEmpPayPeriod: outlet.dynamicIABDVals?.MissingEmploymentPayPeriod,
  pageName: 'Add a missing employment'
}));

export const UpdateEmploymentRoute = withIabdRoute(UpdateEmpStartPage, ({ outlet }) => ({
  onStart: (e: MouseEvent<HTMLAnchorElement>) => outlet.startNow(e, 'updateEmployee'),
  onBack: outlet.redirectCurrentYearPage,
  EmploymentPeriod: outlet.dynamicIABDVals?.EmploymentEndLeavingPeriod,
  pageName: 'Tell us if an employment has ended'
}));

export const AddPensionRoute = withIabdRoute(AddPensionStartPage, ({ outlet }) => ({
  onStart: (e: MouseEvent<HTMLAnchorElement>) => outlet.startNow(e, 'addPension'),
  onBack: outlet.redirectCurrentYearPage,
  dynamicPenPayPeriod: outlet.dynamicIABDVals?.PensionPayPeriod,
  pageName: 'Add a missing pension'
}));

export const UpdatePensionRoute = withIabdRoute(UpdatePensionStartPage, ({ outlet }) => ({
  onStart: (e: MouseEvent<HTMLAnchorElement>) => outlet.startNow(e, 'updatePension'),
  onBack: outlet.redirectCurrentYearPage,
  pensionPeriod: outlet.dynamicIABDVals?.PensionEndLeavingPeriod,
  pageName: 'Tell us if a pension has ended'
}));

export const LatestEventsRoute = withIabdRoute(LatestEventsPage, ({ outlet }) => ({
  pageName: 'View All Activity',
  employmentTaxData: outlet.employmentTaxData,
  goBack: outlet.redirectCurrentYearPage,
  handleViewDetailsClick: outlet.handleViewDetailsClick
}));

export const ViewAllDetailsRoute = withIabdRoute(ViewAllDetails, ({ outlet, state }) => ({
  pageName: 'View All Details',
  details: state.details,
  redirectCurrentYearPage: outlet.redirectCurrentYearPage,
  beginIntrruptionPage: outlet.beginIntrruptionPage,
  handleLinkClick: outlet.handleLinkClick,
  handleUnderstandYourTaxCodeClick: outlet.handleUnderstandYourTaxCodeClick,
  beginUpdateEstimatedTaxableIncomePage: outlet.beginUpdateEstimatedTaxableIncomePage
}));

export const OtherIncomeRoute = withIabdRoute(AllIABDLanding, ({ outlet, state }) => ({
  pageName: 'View and update the information',
  handleLinkClick: outlet.handleLinkClick,
  comingFromPage: state.comingFromPage || '',
  redirectToUnderstandYourTaxPage: outlet.redirectToUnderstandYourTaxPage,
  redirectCurrentYearPage: outlet.redirectCurrentYearPage,
  redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
  handleMoreInformationClick: outlet.handleMoreInformationClick,
  setComingFromPage: outlet.setComingFromPage
}));

export const P2ExplainerRoute = withIabdRoute(P2Explainer, ({ outlet, state }) => ({
  redirectCurrentYearPage: outlet.redirectCurrentYearPage,
  redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
  redirecLatestEventPage: outlet.redirecLatestEventPage,
  timelineDetails: state.timelineDetails,
  eventType: state.eventType
}));

export const ViewTimelineDetailsRoute = withIabdRoute(ViewTimelineDetails, ({ outlet, state }) => ({
  pageName:
    state.timelineDetails?.pyTemplateDataField === 'TAXCODE' || state.timelineDetails?.pyTemplateDataField === 'P2TAXCODE'
      ? 'View Details for Updated Tax Code'
      : `${(state.timelineDetails.Content as TimeLineContentObj[])[0].pyKeyString} event details`,
  timelineDetails: state.timelineDetails,
  eventType: state.eventType,
  comingFromPage: state.comingFromPage || '',
  redirectCurrentYearPage: outlet.redirectCurrentYearPage,
  redirecLatestEventPage: outlet.redirecLatestEventPage,
  setComingFromPage: outlet.setComingFromPage,
  handleLinkClick: outlet.handleLinkClick,
  redirectToAllIABDLandingPage: outlet.redirectToAllIABDLandingPage,
  handleDetailExplainerLinkClick: outlet.handleDetailExplainerLinkClick,
  redirectToDeductionExplainerpage: outlet.redirectToDeductionExplainerpage
}));

export const DetailExplainerRoute = withIabdRoute(DetailExplainer, ({ outlet, state }) => ({
  pageName: 'More information',
  componentName: state.componentName,
  redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage
}));

export const UnderstandYourTaxRoute = withIabdRoute(UnderstandYourTaxCodePage, ({ outlet, state }) => ({
  pageName: 'Understand your tax code',
  understandYourTaxDetails: state.understandYourTaxDetails,
  handleLinkClick: outlet.handleLinkClick,
  redirectToAllIABDLandingPage: outlet.redirectToAllIABDLandingPage,
  onBack: outlet.goBack,
  redirectToDeductionExplainerpage: outlet.redirectToDeductionExplainerpage
}));

export const UnderstandYourTaxSpecialRoute = withIabdRoute(UnderstandYourTaxForSpecialPage, ({ outlet, state }) => ({
  pageName: 'Understand your tax code',
  understandYourTaxDetails: state.understandYourTaxDetails,
  onBack: outlet.goBack,
  handleLinkClick: outlet.handleLinkClick
}));

export const AnnualCodingRoute = withIabdRoute(AnnualCodingTemplate, ({ outlet, state }) => ({
  onBack: outlet.redirectLandingPage,
  annualCodingTemplateValue: state.templateValue,
  pageName: state.pageName,
  taxYearStartDate: outlet.taxYearStartDate,
  handleLinkClick: outlet.handleLinkClick
}));

export const WinterFuelPaymentRoute = withIabdRoute(WinterFuelExplainerPage, ({ outlet }) => ({
  pageName: 'Winter Fuel Payment',
  redirectToAllIABDLandingPage: outlet.redirectToAllIABDLandingPage,
  incomeThresholdForWinterFuelPayment: outlet.dynamicIABDVals?.IncomeThresholdForWinterFuelPayment
}));

export const UntaxedSavingsInterestRoute = withIabdRoute(UntaxedSavingsInterestPage, ({ outlet, state }) => ({
  pageName: 'Untaxed savings interest',
  redirectToUnderstandYourTaxPage: outlet.redirectToUnderstandYourTaxPage,
  redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
  comingFromPage: state.comingFromPage || ''
}));

export const WinterFuelPaymentChargeRoute = withIabdRoute(TaxCodeExplainerWFP, ({ outlet, state }) => ({
  pageName: 'Winter Fuel Payment charge',
  taxCodeSourceAmount: state.sourceAmount,
  redirectToUnderstandYourTaxPage: outlet.redirectToUnderstandYourTaxPage,
  redirectToViewTimelineDetailsPage: outlet.redirectToViewTimelineDetailsPage,
  comingFromPage: state.comingFromPage || '',
  incomeThreshold: outlet.dynamicIABDVals?.IncomeThresholdForWinterFuelPayment,
  nextTaxStartYear: outlet.dynamicIABDVals?.NextTaxStartYear
}));

export const UpdateEstimatedTaxableIncomeRoute = withIabdRoute(UpdateEstimatedTaxableIncomePage, ({ outlet, state }) => ({
  pageName: 'Update estimated taxable income',
  employerName: state.employerName,
  estimatedPay: state.estimatedPay,
  tesUrl: state.tesUrl,
  handleNavClick: outlet.navClickHandler
}));

export const InterruptionRoute = withIabdRoute(InterruptionPage, ({ outlet, state }) => ({
  pageName: 'Update estimated pay',
  onBack: outlet.goBack,
  employmentSequenceNumber: state.employmentSequenceNumber ?? null,
  handleNavClick: outlet.navClickHandler
}));

export const SummaryPageRoute = withIabdRoute(SummaryPage, ({ outlet }) => ({
  caseId: outlet.caseId
}));
