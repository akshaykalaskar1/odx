import '@testing-library/jest-dom';
import { configure } from '@testing-library/react';
import 'jest-fetch-mock';
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import translationEN from '../assets/i18n/en.json';
import translationCY from '../assets/i18n/cy.json';

if (typeof global.TextEncoder === 'undefined') {
  // Jest/jsdom may not provide TextEncoder in some environments
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (global as any).TextEncoder = class TextEncoder {
    encode(input: string) {
      return new Uint8Array(Buffer.from(input, 'utf8'));
    }
  };
}

i18n.use(initReactI18next).init({
  lng: 'en',
  resources: {
    en: {
      translation: translationEN
    },
    cy: {
      translation: translationCY
    }
  },
  fallbackLng: 'en',
  debug: false
});

export default i18n;

configure({ testIdAttribute: 'data-test-id' });
