import { i18n } from 'i18next';
import setPageTitle from './setPageTitleHelpers';
import dayjs from 'dayjs';

const languageToggle = async (lang: string, i18nRef: i18n) => {
  sessionStorage.setItem('rsdk_locale', `${lang}_GB`);
  dayjs.locale(lang);
  i18nRef.changeLanguage(lang).then(() => {
    setPageTitle();
  });
};

export default languageToggle;
