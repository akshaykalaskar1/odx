import React from 'react';
import { render } from '@testing-library/react';
import HideOnMobileView from './HideOnMobileView';
import { useGetUserAgent } from 'hmrc-odx-features-and-functions';

jest.mock('hmrc-odx-features-and-functions', () => ({
  useGetUserAgent: jest.fn()
}));

describe('Given the component is using the HideOnMobileView component', () => {
  const TestComponent = () => <div>Test Content</div>;

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('then renders the react node children when not in mobile app view', () => {
    (useGetUserAgent as jest.Mock).mockReturnValue(false);

    const { getByText } = render(
      <HideOnMobileView>
        <TestComponent />
      </HideOnMobileView>
    );

    expect(getByText('Test Content')).toBeInTheDocument();
  });

  it('then does not render the react node children when in mobile app view', () => {
    (useGetUserAgent as jest.Mock).mockReturnValue(true);

    const { queryByText } = render(
      <HideOnMobileView>
        <TestComponent />
      </HideOnMobileView>
    );

    expect(queryByText('Test Content')).not.toBeInTheDocument();
  });
});
