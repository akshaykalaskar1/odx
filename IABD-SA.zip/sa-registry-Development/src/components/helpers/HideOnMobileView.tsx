import React, { ReactNode } from 'react';
import { CustomView } from 'react-device-detect';
import { useGetUserAgent } from 'hmrc-odx-features-and-functions';
import { mobileAppUserAgent } from '../helpers/constants';

const HideOnMobileView: React.FC<{ children: ReactNode }> = ({ children }) => {
  const isMobileApp: boolean = useGetUserAgent(mobileAppUserAgent);

  return <CustomView condition={!isMobileApp}>{children}</CustomView>;
};

export default HideOnMobileView;
