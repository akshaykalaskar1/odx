import React from 'react';
import CessationServiceNotAvailable from '../../samples/Cessation/CessationServiceNotAvailable/CessationServiceNotAvailable';
import RegistrationServiceNotAvailable from '../../samples/Registration/RegistrationServiceNotAvailable/RegistrationServiceNotAvailable';

export const serviceNotAvailablePages: { [key: string]: React.ComponentType } = {
  registration: RegistrationServiceNotAvailable,
  cessation: CessationServiceNotAvailable
};
