export const setCookie = (cname: string, cvalue: string, exdays: number): void => {
  const d = new Date();
  d.setTime(d.getTime() + exdays * 24 * 60 * 60 * 1000);
  const expires = `expires=${d.toUTCString()}`;
  document.cookie = `${cname}=${cvalue};${expires};path=/`;
};

export const setUserConsentCookie = (consent: boolean) => {
  const consentData = {
    version: '2025.1',
    datetimeSet: new Date().toISOString(),
    preferences: { GA: consent }
  };
  setCookie('userConsent', encodeURIComponent(JSON.stringify(consentData)), 365);
};
