import i18n from 'i18next';

/*
  setPageTitle()
  sets h1 on the page as the title in following pattern
  `<<pageHeading>> - <<serviceName>> - GOV.UK`
  accepts optional param errorProperty and appends 'Error :' if there is error on page
*/

let serviceName = '';

export default function setPageTitle(errorProperty = false) {
  // Reset page title to blank before setting it, this makes sure that when a user clicks back in the browser
  // the title reflects the page and not the browser history
  document.title = '';

  const h1Elements = document.getElementsByTagName('h1');
  // In case where there may be multiple H1s on page (e.g. breifly may have pega part of page and confirmation screen shown together)
  // set up an interval to keep checking until we have only one H1, and then set the page title with the remaining H1
  // This assumes we follow the best practice to only display one h1 on the page, and simply works around the 'gap' when our main
  // page updates to hide/show components.
  if (h1Elements.length !== 1) {
    const setPageTitleInterval = setInterval(() => {
      if (document.getElementsByTagName('h1').length === 1) {
        clearInterval(setPageTitleInterval);
        setPageTitle(errorProperty);
      }
    }, 200);
    return;
  }

  const pageHeadingText = h1Elements[0]?.innerText;
  const pageHeading = pageHeadingText ? i18n.t(pageHeadingText) : '';

  const errorPrefix = errorProperty ? `${i18n.t('ERROR')}: ` : '';
  let  fullTitle;

  if (pageHeading && serviceName) {
    fullTitle = `${errorPrefix}${pageHeading} - ${serviceName} - GOV.UK`;
  } else if (pageHeading) {
    fullTitle = `${errorPrefix}${pageHeading} - GOV.UK`;
  } else if (serviceName) {
    fullTitle = `${serviceName} - GOV.UK`;
  } else {
    fullTitle = 'GOV.UK';
  }


  document.title = fullTitle;

  const titleAlert = document.getElementById('titleAlert');
  if (titleAlert) titleAlert.innerHTML = fullTitle;
}

function registerServiceName(name) {
  serviceName = name;
}
export { registerServiceName };
