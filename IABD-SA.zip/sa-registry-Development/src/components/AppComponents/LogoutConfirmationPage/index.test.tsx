import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import LogoutConfirmationPage from '.';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../helpers/journeyRegistry', () => ({
  getJourneyName: jest.fn(() => 'testJourney')
}));

jest.mock('../AskHMRC', () => () => <div data-testid='ask-hmrc' />);

jest.mock('../../../components/BaseComponents/Button/Button', () => {
  return ({ children, onClick }) => <button type="button" onClick={onClick}>{children}</button>;
});


const autoSignoutConfig = require('../../helpers/constants');

describe('LogoutConfirmationPage', () => {
  const defaultProps = {
    baseurl: '/registration-loggedout'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    sessionStorage.clear();

    delete window.location;
    window.location = { href: '' } as any;

    autoSignoutConfig.default['/registration-loggedout'] = {
      isAnsSavedTrackingEnable: true
    };
  });


describe('Given the user has been logged out for security reasons', () => {
    it('Then the logout confirmation message and Sign in button are displayed', () => {
      render(<LogoutConfirmationPage {...defaultProps} />);

      expect(
        screen.getByText('FOR_SECURITY_WE_SIGNED_YOU_OUT')
      ).toBeInTheDocument();

      expect(
        screen.getByText('SIGN_IN')
      ).toBeInTheDocument();
    });
  });

describe('Given the user previously saved answers', () => {
    it('When isAnsSaved exists in sessionStorage, Then the saved answers message is shown', () => {
      sessionStorage.setItem('isAnsSaved', 'true');

      render(<LogoutConfirmationPage {...defaultProps} />);

      expect(
        screen.getByText('WE_SAVED_YOUR_ANSWERS')
      ).toBeInTheDocument();
    });
  });

describe('Given answer saved tracking is disabled for the journey', () => {
    it('When the page loads, Then isAnsSaved is removed from sessionStorage', async () => {
      sessionStorage.setItem('isAnsSaved', 'true');

      autoSignoutConfig.default['/registration-loggedout']  = {
        isAnsSavedTrackingEnable: false
      };

      render(<LogoutConfirmationPage {...defaultProps} />);

  await waitFor(() => {
        expect(sessionStorage.getItem('isAnsSaved')).toBeNull();
      });

    });
  });


describe('Given the user clicks the Sign in button', () => {
    it('Then isAnsSaved is cleared and the user is redirected to the journey logout URL', () => {
      sessionStorage.setItem('isAnsSaved', 'true');

      render(<LogoutConfirmationPage {...defaultProps} />);

      fireEvent.click(screen.getByText('SIGN_IN'));

      expect(sessionStorage.getItem('isAnsSaved')).toBeNull();
    });
  });

});
