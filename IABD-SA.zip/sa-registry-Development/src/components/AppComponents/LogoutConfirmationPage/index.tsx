import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import Button from '../../../components/BaseComponents/Button/Button';
import AskHMRC from '../AskHMRC';
import apiConfig from '../../helpers/constants';

export default function LogoutConfirmationPage({baseurl}) {
  const [isAnsSaved, setIsAnsSaved] = useState(null);
  const { t } = useTranslation();

  useEffect(() => {
    const isAnsSavedTrackingEnable = apiConfig[baseurl]?.isAnsSavedTrackingEnable;

    if (isAnsSavedTrackingEnable === false) {
      sessionStorage.removeItem('isAnsSaved');
      setIsAnsSaved(false)
    }
    setIsAnsSaved(sessionStorage.getItem('isAnsSaved'));
  }, [t]);

  const handleSignIn = () => {
    sessionStorage.removeItem('isAnsSaved');
    window.location.href = `${baseurl}`;
  };

  return (
    <>
      <h1 className='govuk-heading-xl'>{t('FOR_SECURITY_WE_SIGNED_YOU_OUT')}</h1>
      {isAnsSaved && <p className='govuk-body'>{t('WE_SAVED_YOUR_ANSWERS')}</p>}
      <div className='govuk-form-group'>
        <Button
          variant='primary'
          onClick={e => {
            e.target.blur();
            handleSignIn();
          }}
          attributes={{
            type: 'button',
            className: 'govuk-button govuk-!-margin-bottom-0'
          }}
        >
          {t('SIGN_IN')}
        </Button>
      </div>
      <AskHMRC />
    </>
  );
}
