import React from 'react';
import { useTranslation } from 'react-i18next';
import useHMRCExternalLinks from '../../helpers/hooks/HMRCExternalLinks';
import LanguageToggle from '../LanguageToggle';
// import CookieBanner from '../../BaseComponents/CookieBanner/CookieBanner';
import HideOnMobileView from '../../helpers/HideOnMobileView';
import { HMRCHeader, Link, PageTemplate, PhaseBanner, ServiceNavigation } from 'hmrc-gds-react-components';

/* Commented all CookieBanner code as per the business requirement. Refer: User Story
(US-20235) Remove GA code, cookie banner, revert cookie page - SA & IABD */

export default function AppHeader(props) {
  const { handleSignout, handleServiceNameClick, appname, hasLanguageToggle } = props;
  const { t } = useTranslation();
  const { hmrcURL } = useHMRCExternalLinks();
  const urlSkipContent = `${window.location.pathname}#main-content`;

  function handleServiceName(e?) {
    e?.preventDefault();
    handleServiceNameClick();
  }

  return (
    <HideOnMobileView>
      <a href={urlSkipContent} className='govuk-skip-link' data-module='govuk-skip-link'>
        {t('SKIP_TO_MAIN')}
      </a>
      {/*   <CookieBanner pageUrl={`${pageUrl}`} /> */}
      <PageTemplate.Header>
        <HMRCHeader.Root>
          <HMRCHeader.WidthContainer>
            <HMRCHeader.LogoContainer>
              <HMRCHeader.LogoLink href='https://www.gov.uk/'>
                <HMRCHeader.LogoImage />
              </HMRCHeader.LogoLink>
            </HMRCHeader.LogoContainer>

            {handleSignout && (
              <HMRCHeader.SignoutNav>
                <HMRCHeader.SignoutLink href='#' onClick={handleSignout}>
                  {t('SIGN-OUT')}
                </HMRCHeader.SignoutLink>
              </HMRCHeader.SignoutNav>
            )}
          </HMRCHeader.WidthContainer>
        </HMRCHeader.Root>
        <ServiceNavigation.Root aria-label={t('SERVICE_INFORMATION')}>
          <ServiceNavigation.WidthContainer inline={hasLanguageToggle}>
            <ServiceNavigation.Container>
              <ServiceNavigation.Name>
                <ServiceNavigation.Link href='#' onClick={handleServiceName}>
                  {appname}
                </ServiceNavigation.Link>
              </ServiceNavigation.Name>
            </ServiceNavigation.Container>
            {hasLanguageToggle && <LanguageToggle />}
          </ServiceNavigation.WidthContainer>
        </ServiceNavigation.Root>
        <PhaseBanner.Root>
          <PhaseBanner.Tag>Beta</PhaseBanner.Tag>
          <PhaseBanner.Text>
            {t('NEW_SERVICE')} {t('BANNER_FEEDBACK_1')}{' '}
            <Link className='govuk-link' opensInNewTab href={`${hmrcURL}contact/beta-feedback?service=427&referrerUrl=${window.location.pathname}`}>
              {t('BANNER_FEEDBACK_LINK')} {t('OPENS_IN_NEW_TAB')}
            </Link>
            .
          </PhaseBanner.Text>
        </PhaseBanner.Root>
      </PageTemplate.Header>
    </HideOnMobileView>
  );
}
