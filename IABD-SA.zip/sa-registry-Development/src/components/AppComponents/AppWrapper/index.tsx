import React, { useEffect, useState } from 'react';
import AppHeader from '../AppHeader';
import { useTranslation } from 'react-i18next';
import AppFooter from '../AppFooter';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import setPageTitle, { registerServiceName } from '../../helpers/setPageTitleHelpers';
import { PageTemplate } from 'hmrc-gds-react-components';
import MainWrapper from '../../BaseComponents/MainWrapper';

export default function AppWrapper({ children, baseurl }) {
  const { t } = useTranslation();
  const [serviceName, setServiceName] = useState('');

  useEffect(() => {
    getSdkConfig().then(sdkConfig => {
      const { serviceName: name } = sdkConfig?.applicationConfig?.[baseurl] || {};
      setServiceName(name);
    });
  }, []);

  useEffect(() => {
    if (serviceName) {
      registerServiceName(t(serviceName));
    }
    setPageTitle();
  }, [serviceName, t]);

  function handleServiceNameClick() {
    window.location.href = `${baseurl}`;
  }

  return (
    <>
      <PageTemplate.Root>
        <AppHeader
          appname={t(serviceName)}
          baseurl={`${baseurl}`}
          hasLanguageToggle
          handleServiceNameClick={handleServiceNameClick}
          isPegaApp={false}
        />

        <PageTemplate.WidthContainer>
          <MainWrapper>{children}</MainWrapper>
        </PageTemplate.WidthContainer>

        <AppFooter baseurl={`${baseurl}`} />
      </PageTemplate.Root>
    </>
  );
}
