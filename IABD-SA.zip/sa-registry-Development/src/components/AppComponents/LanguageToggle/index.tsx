import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { LanguageNavigation } from 'hmrc-gds-react-components';
import dayjs from 'dayjs';
import 'dayjs/locale/cy';
import languageToggle from '../../helpers/languageToggleHelper';

const LanguageToggle = () => {
  const { i18n } = useTranslation();
  let lang = sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';
  const [selectedLang, setSelectedLang] = useState(lang);

  const changeLanguage = async e => {
    e.preventDefault();
    document.body.focus();
    lang = e.currentTarget.getAttribute('lang');
    setSelectedLang(lang);
    await languageToggle(lang, i18n);

    const pCore = typeof window !== 'undefined' ? (window as any).PCore : undefined;
    if (pCore) {
      pCore.getEnvironmentInfo().setLocale(`${lang}_GB`);
      pCore.getPubSubUtils().publish('languageToggleTriggered', { language: lang, localeRef: [] });
    }
  };

  // Initialises language value in session storage, and for dayjs
  useEffect(() => {
    if (!sessionStorage.getItem('rsdk_locale')) {
      sessionStorage.setItem('rsdk_locale', `en_GB`);
      dayjs.locale('en');
    } else {
      const currentLang = sessionStorage.getItem('rsdk_locale').slice(0, 2).toLowerCase();
      dayjs.locale(currentLang);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = selectedLang;
  }, [selectedLang]);

  return (
    <LanguageNavigation.Root className='language-navigation' aria-label={selectedLang === 'cy' ? 'Switcher iaith' : 'Language switcher'}>
      <LanguageNavigation.List>
        <LanguageNavigation.ListItem>
          <LanguageNavigation.Item
            lang='en'
            current={selectedLang === 'en'}
            href='?lang=en'
            onClick={changeLanguage}
            languageDescriptionText='Change the language to English'
            announcementText='Language changed to English'
          >
            ENG
          </LanguageNavigation.Item>
        </LanguageNavigation.ListItem>
        <LanguageNavigation.ListItem>
          <LanguageNavigation.Item
            lang='cy'
            current={selectedLang === 'cy'}
            href='?lang=cy'
            onClick={changeLanguage}
            languageDescriptionText="- Newid yr iaith i'r Gymraeg"
            announcementText='Iaith wedi newid i Gymraeg'
          >
            CYM
          </LanguageNavigation.Item>
        </LanguageNavigation.ListItem>
      </LanguageNavigation.List>
    </LanguageNavigation.Root>
  );
};

export default LanguageToggle;
