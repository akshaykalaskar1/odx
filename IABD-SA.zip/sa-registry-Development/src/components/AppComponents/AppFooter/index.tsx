import React from 'react';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import HideOnMobileView from '../../helpers/HideOnMobileView';
import { GOVUKFooter, PageTemplate, VisuallyHidden } from 'hmrc-gds-react-components';

export default function AppFooter(props) {
  const location = useLocation();
  const { baseurl } = props;
  const pageUrl = baseurl || `${location.pathname.replace('/', '')}`;

  const { t } = useTranslation();
  const footerContentLinks = [
    { linkText: t('COOKIES'), linkHref: `${pageUrl}-cookies`, newTabTextKey: `${t('OPENS_IN_NEW_TAB')}` },
    { linkText: t('ACCESSIBILITY'), linkHref: `${pageUrl}-accessibility`, newTabTextKey: `${t('OPENS_IN_NEW_TAB')}` },
    {
      linkText: t('PRIVACY_POLICY'),
      linkHref: 'https://www.gov.uk/government/publications/data-protection-act-dpa-information-hm-revenue-and-customs-hold-about-you',
      newTabTextKey: `${t('OPENS_IN_NEW_TAB')}`
    },
    {
      linkText: t('TERMS_CONDITIONS'),
      linkHref: 'https://www.tax.service.gov.uk/help/terms-and-conditions',
      newTabTextKey: `${t('OPENS_IN_NEW_TAB')}`
    },
    { linkText: t('HELP'), linkHref: 'https://www.gov.uk/help', newTabTextKey: `${t('OPENS_IN_NEW_TAB')}` },
    {
      linkText: t('CONTACT'),
      linkHref: 'https://www.gov.uk/government/organisations/hm-revenue-customs/contact',
      newTabTextKey: `${t('OPENS_IN_NEW_TAB')}`
    },
    {
      linkText: t('CYMRAEG'),
      linkHref: 'https://www.gov.uk/cymraeg',
      lang: 'cy',
      hrefLang: 'cy',
      newTabTextKey: '(yn agor tab newydd)'
    }
  ];

  return (
    <HideOnMobileView>
      <PageTemplate.Footer>
        <GOVUKFooter.Root>
          <GOVUKFooter.WidthContainer>
            <GOVUKFooter.Crown />
            <GOVUKFooter.Meta>
              <GOVUKFooter.MetaItem grow>
                <GOVUKFooter.InlineListHeading>{t('SUPPORT_LINKS')}</GOVUKFooter.InlineListHeading>

                <GOVUKFooter.InlineList>
                  {footerContentLinks.map((link, index) => (
                    <GOVUKFooter.ListItem key={index} variant='inline'>
                      <GOVUKFooter.Link href={link.linkHref} lang={link.lang} hrefLang={link.hrefLang} opensInNewTab={true}>
                        {link.linkText}
                        <VisuallyHidden>{t(link.newTabTextKey)}</VisuallyHidden>
                      </GOVUKFooter.Link>
                    </GOVUKFooter.ListItem>
                  ))}
                </GOVUKFooter.InlineList>
                <GOVUKFooter.LicenceLogo />
                <GOVUKFooter.LicenceDescription>
                  {t('FOOTER_LISCENSE_P1')}{' '}
                  <GOVUKFooter.LicenceLink opensInNewTab={true}>
                    {t('FOOTER_LISCENSE_LINK')}
                    <VisuallyHidden>{t('OPENS_IN_NEW_TAB')}</VisuallyHidden>
                  </GOVUKFooter.LicenceLink>{' '}
                  {t('FOOTER_LISCENSE_P2')}
                </GOVUKFooter.LicenceDescription>
              </GOVUKFooter.MetaItem>

              <GOVUKFooter.MetaItem>
                <GOVUKFooter.CopyrightLink opensInNewTab={true}>
                  {t('COPYRIGHT')}
                  <VisuallyHidden>{t('OPENS_IN_NEW_TAB')}</VisuallyHidden>
                </GOVUKFooter.CopyrightLink>
              </GOVUKFooter.MetaItem>
            </GOVUKFooter.Meta>
          </GOVUKFooter.WidthContainer>
        </GOVUKFooter.Root>
      </PageTemplate.Footer>
    </HideOnMobileView>
  );
}
