import { useEffect } from 'react';
import setPageTitle from '../../helpers/setPageTitleHelpers';
import NotificationBanner from '../../BaseComponents/NotificationBanner/NotificationBanner';
import CaseDetails from './CaseDetails';
import AskHMRC from '../AskHMRC';
import PageNotWorkingProperly from '../PageNotWorkingProperly';

export default function Landing(props) {
  const {
    showPortalBanner,
    isLogout,
    pConn,
    buttonContent,
    title,
    bannerContent,
    handleCaseStart,
    setServiceStatus,
    loadingInProgressCaseDetail,
    inprogressCaseDetail,
    fetchInProgressCaseDetailData
  } = props;

  useEffect(() => {
    setPageTitle();
    fetchInProgressCaseDetailData();
  }, [showPortalBanner]);

  return (
    !loadingInProgressCaseDetail &&
    inprogressCaseDetail.length > 0 && (
      <main
        className={`govuk-main-wrapper ${isLogout ? 'visibility-hidden' : ''}`}
        id='main-content'
        role='main'
      >
        {showPortalBanner && <NotificationBanner content={bannerContent} />}
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-full govuk-prototype-kit-common-templates-mainstream-guide-body govuk-!-padding-right-0 govuk-!-padding-left-0'>
            {/* CaseDetail */}
            <div className='govuk-grid-column-two-thirds'>
              {inprogressCaseDetail.length > 0 && (
                <>
                  <CaseDetails
                    thePConn={pConn}
                    data={inprogressCaseDetail}
                    rowClickAction='OpenAssignment'
                    buttonContent={buttonContent}
                    title={title}
                    handleCaseStart={handleCaseStart}
                    setServiceStatus={setServiceStatus}
                  />
                  <AskHMRC />
                  <PageNotWorkingProperly />
                </>
              )}
            </div>
          </div>
        </div>
      </main>
    )
  );
}
