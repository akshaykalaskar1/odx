import type { ReactNode } from 'react';
import PageNotWorkingProperly from '../../AppComponents/PageNotWorkingProperly';
import { PageTemplate } from 'hmrc-gds-react-components';

interface MainWrapperProps {
  children: ReactNode;
  showPageNotWorkingLink?: boolean;
}

export default function MainWrapper({ children, showPageNotWorkingLink = true }: MainWrapperProps) {
  return (
    <PageTemplate.Main id='main-content'>
      <div className='govuk-grid-row'>
        <div className='govuk-grid-column-two-thirds'>
          {children}
          {showPageNotWorkingLink && <PageNotWorkingProperly />}
        </div>
      </div>
    </PageTemplate.Main>
  );
}
