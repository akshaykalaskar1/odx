import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import CessationAppLandingPage  from './index';

jest.mock('i18next', () => ({
  language: 'en'
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  useAppLanguageToggle: jest.fn()
}));

jest.mock('../../components/helpers/languageToggleHelper', () => jest.fn());

jest.mock('../../components/helpers/hooks/HMRCExternalLinks', () => ({
  __esModule: true,
  default: jest.fn(() => ({
    referrerURL: 'https://example.com/'
  }))
}));


describe('AppLandingPage', () => {
  test('renders main heading', () => {
    render(<CessationAppLandingPage />);
    const heading = screen.getByRole('heading', { level: 1 });
    expect(heading).toBeInTheDocument();
  });

  test('matches the snapshot', async () => {
    const component = render(<CessationAppLandingPage />);

    expect(component.asFragment()).toMatchSnapshot();
  });
});
