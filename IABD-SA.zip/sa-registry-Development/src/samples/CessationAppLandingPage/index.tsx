import React from 'react';
import { Heading, InsetText, WarningText, Link, StartButton } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { useAppLanguageToggle } from 'hmrc-odx-features-and-functions';
import i18n from 'i18next';
import languageToggle from '../../components/helpers/languageToggleHelper';
import useHMRCExternalLinks from '../../components/helpers/hooks/HMRCExternalLinks';

export default function CessationAppLandingPage() {
  const { t } = useTranslation();
  const { referrerURL } = useHMRCExternalLinks();

  useAppLanguageToggle(async (e: Event) => {
    const event = e as CustomEvent<{ language: string }>;

    await languageToggle(event.detail.language, i18n);
  });

  return (
    <div>
      <Heading headingLevel={1} className='govuk-heading-xl'>
        {t('MOBILE_CESSATION.HEADING')}
      </Heading>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P1')}</p>
      <WarningText iconFallbackText={t('GDS_INFO_WARNING')}>
        {t('MOBILE_CESSATION.WARNING_TEXT')}
        <Link href={t('MOBILE_CESSATION.WARNING_LINK_URL')}>{t('MOBILE_CESSATION.WARNING_TEXT_LINK')}</Link>
        {t('MOBILE_CESSATION.WARNING_TEXT_CONTINUED')}
      </WarningText>
      <Heading headingLevel={2} className='govuk-heading-l'>
        {t('MOBILE_CESSATION.H2_NO_LONGER')}
      </Heading>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P2_NO_LONGER')}</p>
      <ul className='govuk-list govuk-list--bullet'>
        <li>{t('MOBILE_CESSATION.LI_1_NO_LONGER')}</li>
        <li>{t('MOBILE_CESSATION.LI_2_NO_LONGER')}</li>
        <li>
          {t('MOBILE_CESSATION.LI_3_NO_LONGER')}
          <Link href={t('MOBILE_CESSATION.LI_3_LINK_URL')}>{t('MOBILE_CESSATION.LI_3_LINK_TEXT')}</Link> {t('MOBILE_CESSATION.LI_3_CONTINUED')}
        </li>
      </ul>
      <InsetText>
        {t('MOBILE_CESSATION.INSET_CHECK_SEND_TAX_RETURN_1')}
        <Link href={t('MOBILE_CESSATION.INSET_LINK_URL')}>{t('MOBILE_CESSATION.INSET_LINK_TEXT')}</Link>{' '}
        {t('MOBILE_CESSATION.INSET_CHECK_SEND_TAX_RETURN_2')}
      </InsetText>
      <Heading headingLevel={3} className='govuk-heading-m'>
        {t('MOBILE_CESSATION.H3_STOP_SELF_EMPLOYED')}
      </Heading>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P_STOP_SELF_EMPLOYED')}</p>
      <Link className='govuk-body' href={t('MOBILE_CESSATION.STOP_SELF_EMPLOYED_LINK_URL')}>
        {t('MOBILE_CESSATION.STOP_SELF_EMPLOYED_LINK_TEXT')}
      </Link>
      .
      <Heading headingLevel={2} className='govuk-heading-l'>
        {t('MOBILE_CESSATION.H2_USE_SERVICE')}
      </Heading>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P_USE_SERVICE')}</p>
      <ul className='govuk-list govuk-list--bullet'>
        <li>{t('MOBILE_CESSATION.LI_1_USE_SERVICE')}</li>
        <li>{t('MOBILE_CESSATION.LI_2_USE_SERVICE')}</li>
        <li>{t('MOBILE_CESSATION.LI_3_USE_SERVICE')}</li>
      </ul>
      <Heading headingLevel={2} className='govuk-heading-l'>
        {t('MOBILE_CESSATION.H2_TELL_HMRC')}
      </Heading>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P_TELL_HMRC')}</p>
      <p className='govuk-body'>{t('MOBILE_CESSATION.P_TELL_HMRC_2')}</p>
      <StartButton
        text={t('MOBILE_CESSATION.BUTTON_START_NOW')}
        href={`${referrerURL}cessation`}
      ></StartButton>
      <p className='govuk-body'>
        {t('MOBILE_CESSATION.UNABLE_TO_USE')}
        <Link href={t('MOBILE_CESSATION.UNABLE_TO_USE_LINK_URL')}>{t('MOBILE_CESSATION.UNALE_TO_USE_LINK_TEXT')}</Link>.
      </p>
    </div>
  );
}
