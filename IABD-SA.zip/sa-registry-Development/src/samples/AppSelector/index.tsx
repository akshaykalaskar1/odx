import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Registration from '../Registration/index';
import CookiePage from '../cookiePage/index';
import Accessibility from '../Registration/AccessibilityPage';
import AccessibilityCessation from '../Cessation/AccessibilityPage';
import ProtectedRoute from '../../components/HOC/ProtectedRoute';
import Cessation from '../Cessation';
import AppealsAndPenalties from '../AppealsAndPenalties';
import AppWrapper from '../../components/AppComponents/AppWrapper';
import AccessibilityAppealsAndPenalties from '../AppealsAndPenalties/AccessibilityPage';
import LogoutConfirmationPage from '../../components/AppComponents/LogoutConfirmationPage';
import CessationAppLandingPage from '../CessationAppLandingPage';
import useInitI18n from '../../components/helpers/hooks/useInitI18n';

const AppSelector = () => {
 const i18nLoaded = useInitI18n();
 if (!i18nLoaded) return null;

  return (
    <Routes>
      <Route path='/' element={<Navigate to='/registration' replace />} />

      {/* Private Routes */}
      <Route
        path='/registration'
        element={<ProtectedRoute component={Registration} journeyName='registration' />}
      />
      <Route
        path='/cessation'
        element={<ProtectedRoute component={Cessation} journeyName='cessation' />}
      />
      <Route
        path='/appeal-a-self-assessment-penalty'
        element={
          <ProtectedRoute
            component={AppealsAndPenalties}
            journeyName='appeal-a-self-assessment-penalty'
          />
        }
      />

      {/* Public Routes */}
      <Route
        path='/cookies'
        element={
          <AppWrapper baseurl=''>
            <CookiePage />
          </AppWrapper>
        }
      />
      <Route
        path='/accessibility'
        element={
          <AppWrapper baseurl=''>
            <Accessibility />
          </AppWrapper>
        }
      />
      <Route
        path='/registration-cookies'
        element={
          <AppWrapper baseurl='registration'>
            <CookiePage />
          </AppWrapper>
        }
      />
      <Route
        path='/registration-accessibility'
        element={
          <AppWrapper baseurl='registration'>
            <Accessibility />
          </AppWrapper>
        }
      />
      <Route
        path='/cessation-cookies'
        element={
          <AppWrapper baseurl='cessation'>
            <CookiePage />
          </AppWrapper>
        }
      />
      <Route
        path='/cessation-accessibility'
        element={
          <AppWrapper baseurl='cessation'>
            <AccessibilityCessation />
          </AppWrapper>
        }
      />
      <Route
        path='/appeal-a-self-assessment-penalty-cookies'
        element={
          <AppWrapper baseurl='appeal-a-self-assessment-penalty'>
            <CookiePage />
          </AppWrapper>
        }
      />
      <Route
        path='/appeal-a-self-assessment-penalty-accessibility'
        element={
          <AppWrapper baseurl='appeal-a-self-assessment-penalty'>
            <AccessibilityAppealsAndPenalties />
          </AppWrapper>
        }
      />
      <Route
        path='/cessation-loggedout'
        element={
          <AppWrapper baseurl='cessation'>
            <LogoutConfirmationPage baseurl='cessation' />
          </AppWrapper>
        }
      />
      <Route
        path='/registration-loggedout'
        element={
          <AppWrapper baseurl='registration'>
            <LogoutConfirmationPage baseurl='registration' />
          </AppWrapper>
        }
      />
      <Route
        path='/appeal-a-self-assessment-penalty-loggedout'
        element={
          <AppWrapper baseurl='appeal-a-self-assessment-penalty'>
            <LogoutConfirmationPage baseurl='appeal-a-self-assessment-penalty' />
          </AppWrapper>
        }
      />
      <Route
        path='/cessation-mobile'
        element={
          <AppWrapper baseurl='cessation'>
            <CessationAppLandingPage />
          </AppWrapper>
        }
      />
    </Routes>
  );
};

export default AppSelector;
