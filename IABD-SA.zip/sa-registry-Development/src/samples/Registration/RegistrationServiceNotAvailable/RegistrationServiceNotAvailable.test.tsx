import React from 'react';
import { render, screen } from '@testing-library/react';
import RegistrationServiceNotAvailable from './RegistrationServiceNotAvailable';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../components/helpers/setPageTitleHelpers', () => jest.fn());

jest.mock('../../../components/BaseComponents/MainWrapper', () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode; }) => (
    <div data-testid="main-wrapper">{children}</div>
  )
}));

jest.mock('../../../components/AppComponents/AskHMRC', () => ({
  __esModule: true,
  default: () => <div data-testid="ask-hmrc">Ask HMRC</div>
}));



describe('Given the RegistrationServiceNotAvailable component is rendered', () => {
  beforeEach(() => {
    jest.spyOn(Storage.prototype, 'getItem').mockReturnValue('en');
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });


  it('then matches the snapshot', () => {
    const { asFragment } = render(<RegistrationServiceNotAvailable />);

    expect(asFragment()).toMatchSnapshot();
  });

  it('then renders the service unavailable heading', () => {
    render(<RegistrationServiceNotAvailable />);

    expect(
      screen.getByText('SORRY_SERVICE_NOT_AVAILABLE_REGISTRATION')
    ).toBeInTheDocument();
  });

  it('then renders the service unavailable message', () => {
    render(<RegistrationServiceNotAvailable />);

    expect(
      screen.getByText('TRY_AGAIN_OR_REGISTER_ANOTHER_WAY')
    ).toBeInTheDocument();
  });

  it('then renders the self employed section', () => {
    render(<RegistrationServiceNotAvailable />);

    expect(
      screen.getByText('IF_YOU_ARE_SELF_EMPLOYED')
    ).toBeInTheDocument();
  });


  it('then renders the business tax account link', () => {
    render(<RegistrationServiceNotAvailable />);

    const link = screen.getByRole('link', {
      name: /YOUR_BUSINESS_TAX_ACCOUNT/i
    });

    expect(link).toBeInTheDocument();

    expect(link).toHaveAttribute(
      'href',
      'https://www.tax.service.gov.uk/business-account'
    );
  });



  it('then renders the business tax account link', () => {
    render(<RegistrationServiceNotAvailable />);
    const link = screen.getByRole('link', {
      name: /YOUR_BUSINESS_TAX_ACCOUNT/i
    });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute(
      'href',
      'https://www.tax.service.gov.uk/business-account'
    );
  });


  it('then renders the what happens next section', () => {
    render(<RegistrationServiceNotAvailable />);

    expect(
      screen.getByText('WHAT_HAPPENS_NEXT')
    ).toBeInTheDocument();

    expect(
      screen.getByText('UTR_BY_POST_TIMELINE')
    ).toBeInTheDocument();
  });


  it('then renders the hmrc app link', () => {
    render(<RegistrationServiceNotAvailable />);

    const link = screen.getByRole('link', {
      name: /HMRC_APP/i
    });

    expect(link).toHaveAttribute(
      'href',
      'https://www.gov.uk/guidance/download-the-hmrc-app'
    );
  });



  it('then renders the check when to expect it link', () => {
    render(<RegistrationServiceNotAvailable />);

    const link = screen.getByRole('link', {
      name: /CHECK_WHEN_TO_EXPECT_IT/i
    });

    expect(link).toHaveAttribute(
      'href',
      'https://www.gov.uk/guidance/check-when-you-can-expect-a-reply-from-hmrc'
    );
  });


  it('then renders the AskHMRC component', () => {
    render(<RegistrationServiceNotAvailable />);

    expect(screen.getByText('Ask HMRC')).toBeInTheDocument();
  });

});
