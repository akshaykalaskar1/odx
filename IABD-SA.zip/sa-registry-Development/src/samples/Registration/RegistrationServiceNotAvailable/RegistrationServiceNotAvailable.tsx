import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import AskHMRC from '../../../components/AppComponents/AskHMRC';
import setPageTitle from '../../../components/helpers/setPageTitleHelpers';
import MainWrapper from '../../../components/BaseComponents/MainWrapper';
import { Heading, Link } from 'hmrc-gds-react-components';

export default function RegistrationServiceNotAvailable() {
  const { t } = useTranslation();
  const lang = sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';
  useEffect(() => {
    setPageTitle();
  }, [lang]);
  return (
    <MainWrapper showPageNotWorkingLink={false}>
      <Heading headingLevel={1} className='govuk-heading-l'>
        {t('SORRY_SERVICE_NOT_AVAILABLE_REGISTRATION')}
      </Heading>
      <p className='govuk-body'>{t('TRY_AGAIN_OR_REGISTER_ANOTHER_WAY')}</p>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('IF_YOU_ARE_SELF_EMPLOYED')}
      </Heading>

      <p className='govuk-body'>
        {t('GO_TO')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.tax.service.gov.uk/business-account' className='govuk-link'>
          {t('YOUR_BUSINESS_TAX_ACCOUNT')} {t('OPENS_IN_NEW_TAB')}
        </Link>{' '}
        {t('ADD_TAX_TO_ACCOUNT_FOR_ONLINE_ACCESS')}
      </p>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('IF_YOU_NEED_TO_REGISTER_FOR_ANOTHER_REASON')}
      </Heading>
      <p className='govuk-body'>
        <Link href='https://online.hmrc.gov.uk/shortforms/form/SA1' target='_blank' rel='noreferrer noopener'>
          {t('REGISTER_FOR_SELF_ASSESSMENT_IF_NOT_SELF_EMPLOYED')} {t('OPENS_IN_NEW_TAB')}.
        </Link>
      </p>

      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('WHAT_HAPPENS_NEXT')}
      </Heading>

      <p className='govuk-body'>{t('UTR_BY_POST_TIMELINE')}</p>
      <p className='govuk-body'>
        {t('YOU_WILL_GET_IT_SOONER_IN_YOUR')}{' '}
        <Link href='https://www.gov.uk/guidance/download-the-hmrc-app' target='_blank' rel='noreferrer noopener'>
          {t('HMRC_APP')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        .
      </p>

      <p className='govuk-body'>
        {t('IF_YOU_HAVE_NOT_RECEIVED_YOUR_UTR_WITHIN_15_OR_21_DAYS')}{' '}
        <Link href='https://www.gov.uk/guidance/check-when-you-can-expect-a-reply-from-hmrc' target='_blank' rel='noreferrer noopener'>
          {t('CHECK_WHEN_TO_EXPECT_IT')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        .
      </p>

      <AskHMRC />
    </MainWrapper>
  );
}
