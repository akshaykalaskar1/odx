// @ts-nocheck - TypeScript type checking to be added soon
import React, { FunctionComponent, useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import AppHeader from '../../components/AppComponents/AppHeader';
import AppFooter from '../../components/AppComponents/AppFooter';
import {
  initTimeout,
  staySignedIn,
  settingTimer
} from '../../components/AppComponents/TimeoutPopup/timeOutUtils';
import setPageTitle, { registerServiceName } from '../../components/helpers/setPageTitleHelpers';
import TimeoutPopup from '../../components/AppComponents/TimeoutPopup';
import ServiceFallbackPageWrapper from '../../components/AppComponents/ServiceFallbackPageWrapper';
import { getCurrentLanguage, scrollToTop } from '../../components/helpers/utils';
import { setJourneyName } from '../../components/helpers/journeyRegistry';
import { resumeOnRefresh, triggerLogout, closeContainer } from '../../components/helpers/utils';
import { TIMEOUT_115_SECONDS } from '../../components/helpers/constants';
import SummaryPage from '../../components/AppComponents/SummaryPage';
import { useAppLanguageToggle } from 'hmrc-odx-features-and-functions';
import i18n from 'i18next';
import languageToggle from '../../components/helpers/languageToggleHelper';
import LoadingWrapper from '../../components/AppComponents/LoadingSpinner/LoadingWrapper';
import Landing from '../../components/AppComponents/Landing';
import { useStartMashup } from '../../reuseables/PegaSetup';
import RegistrationServiceNotAvailable from './RegistrationServiceNotAvailable/RegistrationServiceNotAvailable';

const Registration: FunctionComponent<any> = ({ journeyName }) => {
  const serviceNameAndHeader = 'REGISTER_FOR_SELF_ASSESSMENT';
  const inProgressCaseCountEndPoint = 'D_RegistrantWorkAssignmentSACases';
  const createCaseApi = 'HMRC-SA-Work-Registration';
  const caseListApiParams = { CaseType: 'HMRC-SA-Work-Registration' };
  const summaryPageRef = useRef<HTMLDivElement>(null);
  const [pConnect, setPconnect] = useState<any>(null);
  const [pCoreReady, setPCoreReady] = useState(false);
  const [showLandingPage, setShowLandingPage] = useState<boolean>(true);
  const [pageContentReady, setPageContentReady] = useState(false);
  const [millisecondsTillSignout, setmillisecondsTillSignout] = useState(TIMEOUT_115_SECONDS);
  const [inprogressCaseDetail, setInprogressCaseDetail] = useState([]);
  const [loadingInProgressCaseDetail, setLoadingInProgressCaseDetail] = useState(true);
  const [showTimeoutModal, setShowTimeoutModal] = useState(false);
  const [showPortalBanner, setShowPortalBanner] = useState(false);
  const [isLogout, setIsLogout] = useState(false);
  const [summaryPageContent, setSummaryPageContent] = useState<any>({
    content: null,
    title: null,
    banner: null
  });
  const [currentDisplay, setCurrentDisplay] = useState<
    'pegapage' | 'resolutionpage' | 'servicenotavailable' | 'loading' | 'landingpage'
  >('pegapage');
  const { t } = useTranslation();

  useAppLanguageToggle(async (e: Event) => {
    const event = e as CustomEvent<{ language: string; }>;

    await languageToggle(event.detail.language, i18n);
  });

  useEffect(() => {
    initTimeout(setShowTimeoutModal, false, true, false);
  }, []);

  const {
    showPega,
    setShowPega,
    showResolutionPage,
    setShowResolutionPage,
    caseId,
    isLoading,
    serviceStatus,
    setServiceStatus,
    serviceNotAvailable,
    assignmentPConnect,
    assignmentCancelled,
    setAssignmentCancelled,
    containerClosed,
    renderRootComponent,
    rootProps
  } = useStartMashup({
    appBacklinkProps: {},
    serviceName: serviceNameAndHeader,
    appNameHeader: serviceNameAndHeader
  });

  const serviceName = t('REGISTER_FOR_SELF_ASSESSMENT');
  registerServiceName(serviceName);
  setJourneyName(journeyName);

  function createCase(pyClassName?: string) {
    const startingFields = {
      NotificationLanguage: getCurrentLanguage()
    };

    PCore.getMashupApi().createCase(pyClassName, PCore.getConstants().APP.APP, {
      startingFields,
      pageName: '',
      channelName: ''
    });
  }

  // Calls data page to fetch in progress registration,
  // This then sets inprogress registration state value to the registration details.
  // This function also sets 'isloading' value to true before making d_page calls
  async function fetchInProgressCaseDetailData() {
    // setLoadingInProgressRegistration(true);
    setLoadingInProgressCaseDetail(true);
    const pyAssignmentID = sessionStorage.getItem('assignmentID');
    if (
      !pyAssignmentID ||
      pyAssignmentID === 'undefined' ||
      pyAssignmentID.includes('MANUALINVESTIGATION') ||
      pyAssignmentID.includes('APIRETRY')
    ) {
      let inProgressRegData: any = [];
      const options = { invalidateCache: true };

      // @ts-ignore
      PCore.getDataPageUtils()
        .getDataAsync(
          inProgressCaseCountEndPoint,
          'root',
          { ...caseListApiParams },
          {},
          {},
          options
        )
        .then(resp => {
          if (resp?.data?.[0].InitiateCaseCreation) {
            createCase(resp?.data?.[0].pyClassName);
          } else {
            resp = resp.data.slice(0, 10);
            inProgressRegData = resp;
            setInprogressCaseDetail(inProgressRegData);
          }
          setLoadingInProgressCaseDetail(false);
          // setLoadingInProgressRegistration(false);
        });
    } else {
      const container = PCore.getContainerUtils().getActiveContainerItemName(`${PCore.getConstants().APP.APP}/primary`);
      const target = `${PCore.getConstants().APP.APP}/${container}`;
      const openAssignmentOptions = { containerName: container };
      const assignmentID = sessionStorage.getItem('assignmentID');
      PCore.getMashupApi()
        .openAssignment(assignmentID, target, openAssignmentOptions)
        .then(() => {
          scrollToTop();
        })
        .catch((err: Error) => console.log('Error : ', err));
      sessionStorage.removeItem('assignmentID');
    }
    sessionStorage.setItem('assignmentFinishedFlag', 'false');
  }

  function returnedToPortal(showBanner = false) {
    closeContainer();
    setShowPega(false);
    setShowLandingPage(true);
    setShowResolutionPage(false);
    setShowPortalBanner(showBanner);
    setAssignmentCancelled(false);
    setSummaryPageContent({
      content: null,
      title: null,
      banner: null
    });
  }
  useEffect(() => {
    if (assignmentCancelled) {
      // user clicked save and come back later link
      const showBanner = true;
      returnedToPortal(showBanner);
    }
  }, [assignmentCancelled]);

  useEffect(() => {
    if (assignmentPConnect) {
      setPconnect(assignmentPConnect);
    }
  }, [assignmentPConnect]);

  // Function to force re-render the pega Root component
  const forceRefreshRootComponent = () => {
    // eslint-disable-next-line @typescript-eslint/no-use-before-define
    renderRootComponent();
  };

  useEffect(() => {
    if (Object.keys(rootProps).length) {
      PCore.getPubSubUtils().subscribe('forceRefreshRootComponent', forceRefreshRootComponent, 'forceRefreshRootComponent');
    }
    return () => {
      PCore?.getPubSubUtils().unsubscribe('forceRefreshRootComponent', 'forceRefreshRootComponent');
    };
  }, [rootProps]);

  useEffect(() => {
    resumeOnRefresh(pConnect, pCoreReady, setShowLandingPage, setServiceStatus);
  }, [pCoreReady, pConnect]);

  useEffect(() => {
    if (currentDisplay !== 'loading') {
      setPageContentReady(true);
    } else {
      setPageContentReady(false);
    }
  }, [currentDisplay]);

  useEffect(() => {
    document.addEventListener('SdkConstellationReady', () => {
      PCore.onPCoreReady(() => {
        if (!pCoreReady) {
          setPCoreReady(true);
          PCore.getPubSubUtils().subscribe(
            PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
            () => {
              // console.log("SUBEVENT!!! showStartPageOnCloseContainerItem")
              setShowPega(false);
            },
            'showStartPageOnCloseContainerItem'
          );
          getSdkConfig().then(config => {
            if (config.timeoutConfig.secondsTilLogout) {
              setmillisecondsTillSignout(config.timeoutConfig.secondsTilLogout * 1000);
            }
          });

        }
      });
      settingTimer();
    });

    return () => {
      PCore?.getPubSubUtils().unsubscribe('CustomAssignmentFinished', 'CustomAssignmentFinished');
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );
    };
  }, []);

  // Application specific PCore subscriptions
  document.addEventListener('SdkConstellationReady', () => {
    PCore.onPCoreReady(() => {
      PCore.getPubSubUtils().subscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        () => {
          setShowPega(false);
        },
        'showStartPageOnCloseContainerItem'
      );
    });
    settingTimer();
    PCore.getStore().subscribe(() =>
      staySignedIn(
        setShowTimeoutModal,
        '',
        null,
        false,
        true,
        currentDisplay === 'resolutionpage',
        caseListApiParams
      )
    );

    PCore?.getPubSubUtils().subscribe(
      'CUSTOM_EVENT_BACK',
      () => {
        returnedToPortal(false);
      },
      'CUSTOM_EVENT_BACK'
    );
  });

  // And clean up

  useEffect(() => {
    return () => {
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );

      PCore.getPubSubUtils().unsubscribe('CUSTOM_EVENT_BACK', 'CUSTOM_EVENT_BACK');
    };
  }, []);

  useEffect(() => {
    if (isLoading) {
      setCurrentDisplay('loading');
      return;
    }
    if (showLandingPage && pCoreReady && !showResolutionPage && serviceStatus.isServiceHealthy) {
      setCurrentDisplay('landingpage');
    } else if (showPega) {
      setCurrentDisplay('pegapage');
    } else if (showResolutionPage) {
      setSummaryPageContent({
        content: null,
        title: null,
        banner: null
      });
      setCurrentDisplay('resolutionpage');
      setShowPega(false);
      getSdkConfig().then(config => {
        PCore.getRestClient()
          .invokeCustomRestApi(
            `${config.serverConfig.infinityRestServerUrl}/app/${config.serverConfig.appAlias}/api/application/v2/cases/${caseId}?pageName=SubmissionSummary`,
            {
              method: 'GET',
              body: '',
              headers: '',
              withoutDefaultHeaders: false
            },
            ''
          )
          .then(response => {
            PCore.getPubSubUtils().unsubscribe(
              'languageToggleTriggered',
              'summarypageLanguageChange'
            );
            const summaryData: any[] =
              response.data.data.caseInfo.content.ScreenContent.LocalisedContent;
            const currentLang =
              sessionStorage.getItem('rsdk_locale')?.slice(0, 2).toUpperCase() || 'EN';

            setSummaryPageContent(summaryData.find(data => data.Language === currentLang));

            PCore.getPubSubUtils().subscribe(
              'languageToggleTriggered',
              ({ language }) => {
                setSummaryPageContent(
                  summaryData.find(data => data.Language === language.toUpperCase())
                );
              },
              'summarypageLanguageChange'
            );
          })
          .catch(() => {
            return false;
          });
      });
    } else if (serviceNotAvailable) {
      setCurrentDisplay('servicenotavailable');
    } else {
      setCurrentDisplay('loading');
    }
    if (!showPega) {
      setPageTitle();
    }
  }, [
    showResolutionPage,
    showPega,
    serviceNotAvailable,
    pCoreReady,
    showLandingPage,
    containerClosed,
    isLoading,
    serviceStatus.isServiceHealthy
  ]);
  // One time (initialization) subscriptions and related unsubscribe

  function handleSignout(e?) {
    e?.preventDefault();
    triggerLogout(setIsLogout);
  }

  function handleServiceNameClick() {
    sessionStorage.setItem('assignmentID', 'disableRefresh');
    window.location.href = `${journeyName}`;
    returnedToPortal();
  }

  const handleCaseStart = () => {
    setShowLandingPage(false);
    setShowPega(true);
  };

  const renderContent = () => {
    if (serviceNotAvailable) {
      return <RegistrationServiceNotAvailable  />;
    } else if (currentDisplay === 'resolutionpage') {
      return (
        <SummaryPage
          summaryContent={summaryPageContent?.Content}
          summaryTitle={summaryPageContent?.Title}
          summaryBanner={summaryPageContent?.Banner}
          ref={summaryPageRef}
        />
      );
    } else {
      return (
        <ServiceFallbackPageWrapper serviceStatus={serviceStatus} CustomFallbackPage={<RegistrationServiceNotAvailable />}>
          <>
            <div id='pega-part-of-page' className={isLogout ? 'visibility-hidden' : ''}>
              <div id='pega-root'></div>
            </div>
            <LoadingWrapper
              pageIsLoading={!pageContentReady}
              spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}
            >
              {currentDisplay === 'landingpage' && pConnect && (
                <Landing
                  showPortalBanner={showPortalBanner}
                  isLogout={isLogout}
                  pConn={pConnect}
                  inProgressCaseCountEndPoint={inProgressCaseCountEndPoint}
                  createCaseEndpoint={createCaseApi}
                  buttonContent={t('CONTINUE_YOUR_REGISTRATION')}
                  title={t('YOUR_REGISTRATION')}
                  bannerContent={t('SA_PORTAL_NOTIFICATION_BANNER_CONTENT')}
                  handleCaseStart={handleCaseStart}
                  caseListApiParams={caseListApiParams}
                  setServiceStatus={setServiceStatus}
                  inprogressCaseDetail={inprogressCaseDetail}
                  loadingInProgressCaseDetail={loadingInProgressCaseDetail}
                  fetchInProgressCaseDetailData={fetchInProgressCaseDetailData}
                />
              )}
            </LoadingWrapper>
          </>
        </ServiceFallbackPageWrapper>
      );
    }
  };

  return (
    <>
      <TimeoutPopup
        show={showTimeoutModal}
        millisecondsTillSignout={millisecondsTillSignout}
        staySignedinHandler={() =>
          staySignedIn(
            setShowTimeoutModal,
            inProgressCaseCountEndPoint,
            null,
            false,
            true,
            currentDisplay === 'resolutionpage',
            caseListApiParams
          )
        }
        signoutHandler={(e?) => {
          e?.preventDefault();
          triggerLogout(setIsLogout);
        }}
        autoSignoutHandler={(e?) => {
          e?.preventDefault();
          triggerLogout(setIsLogout, true);
        }}
      />

      <AppHeader
        handleSignout={handleSignout}
        handleServiceNameClick={handleServiceNameClick}
        appname={t('REGISTER_FOR_SELF_ASSESSMENT')}
        hasLanguageToggle
        isPegaApp={showPega}
      />

      <div className='govuk-width-container'>{renderContent()}</div>

      <AppFooter />
    </>
  );
};

export default Registration;
