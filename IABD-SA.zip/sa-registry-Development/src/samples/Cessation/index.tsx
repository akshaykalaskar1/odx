import { FunctionComponent, useState, useEffect, useContext, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import setPageTitle, { registerServiceName } from '../../components/helpers/setPageTitleHelpers';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import AppFooter from '../../components/AppComponents/AppFooter';
import {
  getCurrentLanguage,
  resumeOnRefresh,
  triggerLogout,
  closeContainer
} from '../../components/helpers/utils';
import useHMRCExternalLinks from '../../components/helpers/hooks/HMRCExternalLinks';
import TimeoutPopup from '../../components/AppComponents/TimeoutPopup';
import SummaryPage from '../../components/AppComponents/SummaryPage';
import { initTimeout, settingTimer, staySignedIn } from '../../components/AppComponents/TimeoutPopup/timeOutUtils';
import AppHeader from '../../components/AppComponents/AppHeader';
import { useStartMashup } from '../../reuseables/PegaSetup';
import Landing from '../../components/AppComponents/Landing';
import AppContext from '../../reuseables/AppContext';
import { setJourneyName } from '../../components/helpers/journeyRegistry';
import { TIMEOUT_115_SECONDS } from '../../components/helpers/constants';
import ServiceFallbackPageWrapper from '../../components/AppComponents/ServiceFallbackPageWrapper';
import i18n from 'i18next';
import languageToggle from '../../components/helpers/languageToggleHelper';
import { useHeartBeat, useAppLanguageToggle } from 'hmrc-odx-features-and-functions';
import LoadingWrapper from '../../components/AppComponents/LoadingSpinner/LoadingWrapper';
import { getServiceStatus } from '../../components/helpers/getServiceStatus';
import CessationServiceNotAvailable from './CessationServiceNotAvailable/CessationServiceNotAvailable';

const Cessation: FunctionComponent<any> = ({ journeyName }) => {
  const { t } = useTranslation();

  // Adding hardcoded value as key to sort translation issue.
  const serviceNameAndHeader = 'TELL_HMRC_YOU_NO_LONGER_NEED_TO_SEND_A_TAX_RETURN';
  const inProgressCaseCountEndPoint = 'D_RegistrantWorkAssignmentSACases';
  const createCaseEndpoint = 'HMRC-SA-Work-Cessation';
  const caseListApiParams = { CaseType: 'HMRC-SA-Work-Cessation' };

  const summaryPageRef = useRef<HTMLDivElement>(null);
  const [inprogressCaseDetail, setInprogressCaseDetail] = useState([]);
  const [loadingInProgressCaseDetail, setLoadingInProgressCaseDetail] = useState(true);
  const [showLandingPage, setShowLandingPage] = useState<boolean>(true);
  const [pCoreReady, setPCoreReady] = useState(false);
  const { showLanguageToggle } = useContext(AppContext);
  const [showLanguageToggleState, setShowLanguageToggleState] = useState(showLanguageToggle);
  const [currentDisplay, setCurrentDisplay] = useState<'pegapage' | 'resolutionpage' | 'servicenotavailable' | 'loading' | 'landingpage'>('pegapage');
  const [summaryPageContent, setSummaryPageContent] = useState<any>({
    content: null,
    title: null,
    banner: null
  });
  const [showTimeoutModal, setShowTimeoutModal] = useState(false);
  const [showPortalBanner, setShowPortalBanner] = useState(false);
  const [pConnect, setPconnect] = useState(null);
  const [isLogout, setIsLogout] = useState(false);
  const [millisecondsTillSignout, setmillisecondsTillSignout] = useState(TIMEOUT_115_SECONDS);
  const [pageContentReady, setPageContentReady] = useState(false);
  const { hmrcURL } = useHMRCExternalLinks();

  registerServiceName(t('TELL_HMRC_YOU_NO_LONGER_NEED_TO_SEND_A_TAX_RETURN'));
  setJourneyName(journeyName);
  useHeartBeat(() => {
    staySignedIn(setShowTimeoutModal, inProgressCaseCountEndPoint, null, false, true, currentDisplay === 'resolutionpage', caseListApiParams);
  });

  useAppLanguageToggle(async (e: Event) => {
    const event = e as CustomEvent<{ language: string }>;

    await languageToggle(event.detail.language, i18n);
  });

  useEffect(() => {
    initTimeout(setShowTimeoutModal, false, true, false);
  }, []);

  const {
    showPega,
    setShowPega,
    showResolutionPage,
    setShowResolutionPage,
    caseId,
    isLoading,
    serviceStatus,
    setServiceStatus,
    serviceNotAvailable,
    assignmentPConnect,
    assignmentCancelled,
    setAssignmentCancelled,
    containerClosed,
    renderRootComponent,
    rootProps
  } = useStartMashup({
    appBacklinkProps: {},
    serviceName: serviceNameAndHeader,
    appNameHeader: serviceNameAndHeader
  });

  // Function to force re-render the pega Root component
  const forceRefreshRootComponent = () => {
    renderRootComponent();
  };

  useEffect(() => {
    if (Object.keys(rootProps).length) {
      PCore.getPubSubUtils().subscribe('forceRefreshRootComponent', forceRefreshRootComponent, 'forceRefreshRootComponent');
    }
    return () => {
      PCore?.getPubSubUtils().unsubscribe('forceRefreshRootComponent', 'forceRefreshRootComponent');
    };
  }, [rootProps]);

  useEffect(() => {
    if (assignmentPConnect) {
      setPconnect(assignmentPConnect);
    }
  }, [assignmentPConnect]);

  function handleSignout(e?) {
    e?.preventDefault();
    triggerLogout(setIsLogout);
  }

  const handleCaseStart = () => {
    setShowLandingPage(false);
    setShowPega(true);
  };

  function createCase() {
    const startingFields = {
      NotificationLanguage: getCurrentLanguage()
    };

    PCore.getMashupApi().createCase(createCaseEndpoint, PCore.getConstants().APP.APP, {
      // @ts-ignore
      startingFields,
      pageName: '',
      channelName: ''
    });

    handleCaseStart();
  }

  async function fetchInProgressCaseDetailData() {
    setLoadingInProgressCaseDetail(true);
    const serviceStatusResponse = await getServiceStatus();
    if (!serviceStatusResponse.isServiceHealthy) {
      setServiceStatus(serviceStatusResponse);
      return;
    }
    let inProgressRegData: any = [];
    const options = { invalidateCache: true };
    const context = pConnect.getContextName();

    PCore.getDataPageUtils()
      // @ts-ignore
      .getDataAsync(inProgressCaseCountEndPoint, context, { ...caseListApiParams }, {}, {}, options)
      .then(resp => {
        if (!resp.data || resp.data.length === 0) {
          createCase();
        } else {
          inProgressRegData = resp.data?.slice(0, 10);
          setInprogressCaseDetail(inProgressRegData);
        }
        setLoadingInProgressCaseDetail(false);
      });
    sessionStorage.setItem('assignmentFinishedFlag', 'false');
  }

  function returnedToPortal(showBanner = false) {
    closeContainer();
    setShowPega(false);
    setShowLandingPage(true);
    setShowResolutionPage(false);
    setShowPortalBanner(showBanner);
    setAssignmentCancelled(false);
    setSummaryPageContent({
      content: null,
      title: null,
      banner: null
    });
  }

  function handleServiceNameClick() {
    returnedToPortal();
  }

  useEffect(() => {
    if (assignmentCancelled) {
      // user clicked save and come back later link
      const showBanner = true;
      returnedToPortal(showBanner);
    }
  }, [assignmentCancelled]);

  useEffect(() => {
    function handleClick(e) {
      const targetId = e.target.id;
      if (targetId === 'homepage') {
        e.preventDefault();
        returnedToPortal(false);
        // setShowPortalPageDefault(true);
      }
    }

    const currentSummaryPageRef = summaryPageRef.current;
    if (currentSummaryPageRef) {
      currentSummaryPageRef.addEventListener('click', handleClick);
    }
    return () => {
      if (currentSummaryPageRef) {
        currentSummaryPageRef.removeEventListener('click', handleClick);
      }
    };
  }, [summaryPageContent]);

  useEffect(() => {
    if (isLoading) {
      setCurrentDisplay('loading');
      return;
    }

    if (showLandingPage && pCoreReady && !showResolutionPage && serviceStatus.isServiceHealthy) {
      setCurrentDisplay('landingpage');
    } else if (showPega) {
      setCurrentDisplay('pegapage');
    } else if (showResolutionPage) {
      setSummaryPageContent({
        content: null,
        title: null,
        banner: null
      });
      setCurrentDisplay('resolutionpage');
      setShowPega(false);
      getSdkConfig().then(config => {
        PCore.getRestClient()
          .invokeCustomRestApi(
            `${config.serverConfig.infinityRestServerUrl}/app/${config.serverConfig.appAlias}/api/application/v2/cases/${caseId}?pageName=SubmissionSummary`,
            {
              method: 'GET',
              body: {},
              headers: {},
              withoutDefaultHeaders: false
            },
            ''
          )
          .then((response: any) => {
              PCore.getPubSubUtils().unsubscribe(
              'languageToggleTriggered',
              'summarypageLanguageChange'
            );
            const summaryData = (response as SummaryResponse).data.data.caseInfo.content.ScreenContent.LocalisedContent;
            const currentLang = sessionStorage.getItem('rsdk_locale')?.slice(0, 2).toUpperCase() || 'EN';

            setSummaryPageContent(summaryData.find(data => data.Language === currentLang));

              PCore.getPubSubUtils().subscribe(
              'languageToggleTriggered',
              ({ language }) => {
                setSummaryPageContent(
                  summaryData.find(data => data.Language === language.toUpperCase())
                );
              },
              'summarypageLanguageChange'
            );
          })
          .catch(() => {
            return false;
          });
      });
    } else if (serviceNotAvailable) {
      setCurrentDisplay('servicenotavailable');
    } else {
      setCurrentDisplay('loading');
    }
    if (!showPega) {
      setPageTitle();
    }
  }, [showResolutionPage, showPega, serviceNotAvailable, pCoreReady, showLandingPage, containerClosed, isLoading, serviceStatus.isServiceHealthy]);

  useEffect(() => {
    resumeOnRefresh(pConnect, pCoreReady, setShowLandingPage, setServiceStatus);
  }, [pCoreReady, pConnect]);

  useEffect(() => {
    document.addEventListener('SdkConstellationReady', () => {
      PCore.onPCoreReady(() => {
        if (!pCoreReady) {
          setPCoreReady(true);
          PCore.getPubSubUtils().subscribe(
            PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
            () => {
              // console.log("SUBEVENT!!! showStartPageOnCloseContainerItem")
              setShowPega(false);
            },
            'showStartPageOnCloseContainerItem'
          );
          getSdkConfig().then(config => {
            if (config.timeoutConfig.secondsTilLogout) {
              setmillisecondsTillSignout(config.timeoutConfig.secondsTilLogout * 1000);
            }
          });
        }
      });
      settingTimer();
    });

    return () => {
      PCore?.getPubSubUtils().unsubscribe('CustomAssignmentFinished', 'CustomAssignmentFinished');
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );
    };
  }, []);

  /* ***
   * Application specific PCore subscriptions
   *
   * TODO Can this be made into a tidy helper? including its own clean up? A custom hook perhaps
   */
  document.addEventListener('SdkConstellationReady', () => {
    PCore.onPCoreReady(() => {
      PCore.getPubSubUtils().subscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        () => {
          setShowPega(false);
        },
        'showStartPageOnCloseContainerItem'
      );
    });
    settingTimer();
    PCore.getStore().subscribe(() =>
      staySignedIn(setShowTimeoutModal, '', null, false, true, currentDisplay === 'resolutionpage', caseListApiParams)
    );

    PCore?.getPubSubUtils().subscribe(
      'CUSTOM_EVENT_BACK',
      () => {
        returnedToPortal(false);
      },
      'CUSTOM_EVENT_BACK'
    );
  });

  // And clean up

  useEffect(() => {
    return () => {
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );

      PCore.getPubSubUtils().unsubscribe('CUSTOM_EVENT_BACK', 'CUSTOM_EVENT_BACK');
    };
  }, []);

  useEffect(() => {
    getSdkConfig().then(config => {
      setShowLanguageToggleState(config?.cessationConfig?.showLanguageToggle);
    });
  }, []);

  useEffect(() => {
    if (currentDisplay !== 'loading') {
      setPageContentReady(true);
    } else {
      setPageContentReady(false);
    }
  }, [currentDisplay]);

  function renderContent() {
    return (
      <ServiceFallbackPageWrapper serviceStatus={serviceStatus} CustomFallbackPage={<CessationServiceNotAvailable />}>
        <>
          <div id='pega-part-of-page'>
            <div id='pega-root' className={`${isLogout ? 'visibility-hidden' : ''}`}></div>
          </div>
          <LoadingWrapper pageIsLoading={!pageContentReady} spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}>
            {currentDisplay === 'landingpage' && pConnect && (
              <Landing
                showPortalBanner={showPortalBanner}
                isLogout={isLogout}
                pConn={pConnect}
                inProgressCaseCountEndPoint={inProgressCaseCountEndPoint}
                createCaseEndpoint={createCaseEndpoint}
                buttonContent={t('CONTINUE_YOUR_REQUEST')}
                title={t('YOUR_REQUEST')}
                bannerContent={t('CES_PORTAL_NOTIFICATION_BANNER_CONTENT')}
                handleCaseStart={handleCaseStart}
                caseListApiParams={caseListApiParams}
                setServiceStatus={setServiceStatus}
                inprogressCaseDetail={inprogressCaseDetail}
                loadingInProgressCaseDetail={loadingInProgressCaseDetail}
                fetchInProgressCaseDetailData={fetchInProgressCaseDetailData}
              />
            )}
          </LoadingWrapper>
          {currentDisplay === 'resolutionpage' && (
            <SummaryPage
              summaryContent={summaryPageContent?.Content}
              summaryTitle={summaryPageContent?.Title}
              summaryBanner={summaryPageContent?.Banner}
              ref={summaryPageRef}
            />
          )}
        </>
      </ServiceFallbackPageWrapper>
    );
  }

  if (currentDisplay === 'servicenotavailable') {
    return (
      <>
        <TimeoutPopup
          show={showTimeoutModal}
          millisecondsTillSignout={millisecondsTillSignout}
          staySignedinHandler={() => staySignedIn(setShowTimeoutModal, inProgressCaseCountEndPoint, null, false, true, false, caseListApiParams)}
          signoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout);
          }}
          autoSignoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout, true);
          }}
          isAuthorised
          staySignedInButtonText='Stay signed in'
          signoutButtonText='Sign out'
        />
        <AppHeader
          appname={t('TELL_HMRC_YOU_NO_LONGER_NEED_TO_SEND_A_TAX_RETURN')}
          hasLanguageToggle={showLanguageToggleState}
          handleSignout={handleSignout}
          handleServiceNameClick={handleServiceNameClick}
          betafeedbackurl={`${hmrcURL}contact/beta-feedback?service=claim-child-benefit-frontend&backUrl=/fill-online/claim-child-benefit/recently-claimed-child-benefit`}
        />
        <div className='govuk-width-container'>
          <CessationServiceNotAvailable />
        </div>
        <AppFooter />
      </>
    );
  } else {
    return (
      <AppContext.Provider
        value={{
          appBacklinkProps: {},
          showLanguageToggle,
          serviceName: serviceNameAndHeader,
          appNameHeader: serviceNameAndHeader
        }}
      >
        <TimeoutPopup
          show={showTimeoutModal}
          millisecondsTillSignout={millisecondsTillSignout}
          staySignedinHandler={() =>
            staySignedIn(setShowTimeoutModal, inProgressCaseCountEndPoint, null, false, true, currentDisplay === 'resolutionpage', caseListApiParams)
          }
          signoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout);
          }}
          autoSignoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout, true);
          }}
          isAuthorised
          staySignedInButtonText='Stay signed in'
          signoutButtonText='Sign out'
        />

        <>
          <AppHeader
            handleSignout={handleSignout}
            handleServiceNameClick={handleServiceNameClick}
            appname={t('TELL_HMRC_YOU_NO_LONGER_NEED_TO_SEND_A_TAX_RETURN')}
            hasLanguageToggle={showLanguageToggleState}
            isPegaApp={showPega}
            betafeedbackurl={`${hmrcURL}contact/beta-feedback?service=claim-child-benefit-frontend&backUrl=/fill-online/claim-child-benefit/recently-claimed-child-benefit`}
          />

          <div className='govuk-width-container'>{renderContent()}</div>

          <AppFooter />
        </>
      </AppContext.Provider>
    );
  }
};
export default Cessation;
