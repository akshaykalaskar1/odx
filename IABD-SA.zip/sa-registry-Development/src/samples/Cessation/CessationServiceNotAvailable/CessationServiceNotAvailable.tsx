import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import AskHMRC from '../../../components/AppComponents/AskHMRC';
import setPageTitle from '../../../components/helpers/setPageTitleHelpers';
import MainWrapper from '../../../components/BaseComponents/MainWrapper';
import { Heading, Link } from 'hmrc-gds-react-components';

export default function CessationServiceNotAvailable() {
  const { t } = useTranslation();
  const lang = sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';
  useEffect(() => {
    setPageTitle();
  }, [lang]);
  return (
    <MainWrapper showPageNotWorkingLink={false}>
      <Heading headingLevel={1} className='govuk-heading-l'>
        {t('SERVICE_NOT_AVAILABLE_CESSATION')}
      </Heading>

      <p className='govuk-body'>{t('TRY_AGAIN_OR_ANOTHER_WAY_CESSATION')}{'.'}</p>
      <p className='govuk-body'>
        {t('TO_TELL_HMRC')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.tax.service.gov.uk/digital-forms/form/self-assessment-stop-being-self-assessed/draft/guide' className='govuk-link'>
          {t('FILL_IN_AN_ONLINE_FORM')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {' '}{t('TO')}{':'}
      </p>
      <ul className='govuk-list govuk-list--bullet'>
        <li>{t('CLOSE_YOUR_SELF_ASSESSMENT_ACCOUNT')}</li>
        <li>{t('ASK_TO_BE_REMOVED_FROM_SELF_ASSESSMENT')}</li>
      </ul>
      <p className='govuk-body'>
        {t('NEED_TO_PROVIDE')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.gov.uk/find-national-insurance-number' className='govuk-link'>
          {t('YOUR_NATIONAL_INSURANCE_NUMBER')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {' '}{t('AND')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.gov.uk/find-utr-number' className='govuk-link'>
          {t('YOUR_UTR_NUMBER')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {'.'}
      </p>
      <p className='govuk-body'>
        {t('IF_YOU_CANNOT_FILL_IN_THE_ONLINE_FORM')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.gov.uk/government/organisations/hm-revenue-customs/contact/self-assessment' className='govuk-link'>
          {t('CONTACT_HMRC_BY_PHONE_OR_POST')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {'.'}
      </p>

      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('IF_YOU_ARE_NO_LONGER_SELF_EMPLOYED')}
      </Heading>

      <p className='govuk-body'>
        {t('YOU_MUST_ALSO')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://online.hmrc.gov.uk/shortforms/form/CeaseTrading' className='govuk-link'>
          {t('TELL_HMRC_YOU_STOPPED_BEING_SELF_EMPLOYED')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {'.'}
      </p>
      <p className='govuk-body'>
        {t('NEED_TO_PROVIDE')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.gov.uk/national-insurance/your-national-insurance-number' className='govuk-link'>
          {t('YOUR_NATIONAL_INSURANCE_NUMBER')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {' '}{t('AND')}{' '}
        <Link target='_blank' rel='noreferrer noopener' href='https://www.gov.uk/find-utr-number' className='govuk-link'>
          {t('YOUR_UTR_NUMBER')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {'.'}
      </p>

      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('WHAT_HAPPENS_NEXT')}
      </Heading>

      <p className='govuk-body'>
        {t('YOU_CAN_VIEW_PROGRESS')}{' '}
        <Link href='https://www.access.service.gov.uk/login/signin/creds' target='_blank' rel='noreferrer noopener'>
          {t('YOUR_HMRC_ONLINE_ACCOUNT')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        {'.'}
      </p>
      <p className='govuk-body'>{t('HMRC_WILL_WRITE_TO_YOU')}{'.'}</p>

      <AskHMRC />
    </MainWrapper>
  );
}
