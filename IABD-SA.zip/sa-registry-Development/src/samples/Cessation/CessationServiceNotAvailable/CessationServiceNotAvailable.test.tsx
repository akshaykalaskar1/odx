import React from 'react';
import { render, screen } from '@testing-library/react';
import CessationServiceNotAvailable from './CessationServiceNotAvailable';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../components/helpers/setPageTitleHelpers', () => jest.fn());

jest.mock('../../../components/BaseComponents/MainWrapper', () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode; }) => (
    <div data-testid="main-wrapper">{children}</div>
  )
}));

jest.mock('../../../components/AppComponents/AskHMRC', () => ({
  __esModule: true,
  default: () => <div data-testid="ask-hmrc">Ask HMRC</div>
}));



describe('Given the CessationServiceNotAvailable component is rendered', () => {
  beforeEach(() => {
    jest.spyOn(Storage.prototype, 'getItem').mockReturnValue('en');
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.restoreAllMocks();
  });


  it('then matches the snapshot', () => {
    const { asFragment } = render(<CessationServiceNotAvailable />);

    expect(asFragment()).toMatchSnapshot();
  });

  it('then renders the service unavailable heading', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('SERVICE_NOT_AVAILABLE_CESSATION')
    ).toBeInTheDocument();
  });

  it('then renders the service unavailable message', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('TRY_AGAIN_OR_ANOTHER_WAY_CESSATION.')
    ).toBeInTheDocument();
  });

  it('then renders the fill in an online form link', () => {
    render(<CessationServiceNotAvailable />);

    const link = screen.getByRole('link', {
      name: /FILL_IN_AN_ONLINE_FORM/i
    });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute(
      'href',
      'https://www.tax.service.gov.uk/digital-forms/form/self-assessment-stop-being-self-assessed/draft/guide'
    );
  });

  it('then renders the close your self-assessment account section', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('CLOSE_YOUR_SELF_ASSESSMENT_ACCOUNT')
    ).toBeInTheDocument();
  });

  it('then renders the ask to be removed from self-assessment section', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('ASK_TO_BE_REMOVED_FROM_SELF_ASSESSMENT')
    ).toBeInTheDocument();
  });

  it('then renders the contact hmrc link', () => {
    render(<CessationServiceNotAvailable />);
    const link = screen.getByRole('link', {
      name: /CONTACT_HMRC_BY_PHONE_OR_POST/i
    });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute(
      'href',
      'https://www.gov.uk/government/organisations/hm-revenue-customs/contact/self-assessment'
    );
  });

  it('then renders the no longer self employed section', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('IF_YOU_ARE_NO_LONGER_SELF_EMPLOYED')
    ).toBeInTheDocument();
  });

  it('then renders the tell hmrc you no longer employed link', () => {
    render(<CessationServiceNotAvailable />);
    const link = screen.getByRole('link', {
      name: /TELL_HMRC_YOU_STOPPED_BEING_SELF_EMPLOYED/i
    });
    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute(
      'href',
      'https://online.hmrc.gov.uk/shortforms/form/CeaseTrading'
    );
  });

  it('then renders the what happens next section', () => {
    render(<CessationServiceNotAvailable />);

    expect(
      screen.getByText('WHAT_HAPPENS_NEXT')
    ).toBeInTheDocument();

    expect(
      screen.getByText('HMRC_WILL_WRITE_TO_YOU.')
    ).toBeInTheDocument();
  });

  it('then renders the hmrc online account link', () => {
    render(<CessationServiceNotAvailable />);

    const link = screen.getByRole('link', {
      name: /YOUR_HMRC_ONLINE_ACCOUNT/i
    });

    expect(link).toHaveAttribute(
      'href',
      'https://www.access.service.gov.uk/login/signin/creds'
    );
  });

  it('then renders the AskHMRC component', () => {
    render(<CessationServiceNotAvailable />);

    expect(screen.getByText('Ask HMRC')).toBeInTheDocument();
  });

});
