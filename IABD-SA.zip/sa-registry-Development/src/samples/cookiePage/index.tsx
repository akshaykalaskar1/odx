import { useTranslation } from 'react-i18next';
import { CookiesPage } from 'hmrc-gds-react-components';
import GenericCookieJson from '../../data/cookies/genericCookies.json';

export default function Cookies() {
  const { t } = useTranslation();
  const FIND_OUT_MORE_URL = 'https://www.tax.service.gov.uk/help/cookie-details';

  return (
    <>
      <CookiesPage
        onPreferenceSet={() => {}}
        config={[
          {
            Name: t('ESSENTIAL_COOKIES'),
            category: 'essential',

            CookieDetails: GenericCookieJson.map(cookie => ({
              Name: cookie.name,
              Purpose: t(cookie.description),
              Expires: t(cookie.expires)
            })),
            DescriptionHeading: t('ESSENTIAL_COOKIES'),
            PostTableInformation: t('ESSENTIAL_COOKIES_P1')
          }
        ]}
        headingText={t('COOKIES')}
        cookiesParagraphDescription={[t('COOKIES_PAGE_P1'), t('COOKIES_PAGE_P2')]}
        bannerMessageText=''
        columnHeaders={{
          name: t('COOKIE_NAME'),
          purpose: t('COOKIE_PURPOSE'),
          expires: t('COOKIE_EXPIRES')
        }}
      />
      <p className='govuk-body'>
        <a href={FIND_OUT_MORE_URL} className='govuk-link govuk-link--no-visited-state'>
          {t('COOKIE_FIND_OUT_MORE')}
        </a>
      </p>
    </>
  );
}
