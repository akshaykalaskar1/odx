import { act } from 'react';
import { cleanup, render } from '@testing-library/react';
import { I18nextProvider, useTranslation } from 'react-i18next';
import { renderHook } from '@testing-library/react-hooks';
import { CookiesPage } from 'hmrc-gds-react-components';
import { mockGetSdkConfigWithBasepath } from '../../../tests/mocks/getSdkConfigMock';
import GenericCookieJson from '../../data/cookies/genericCookies.json';

const FIND_OUT_MORE_URL = 'https://www.tax.service.gov.uk/help/cookie-details';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

describe('should render CookiePage component.', () => {
  let t;
  afterEach(cleanup);

  beforeEach(async () => {
    mockGetSdkConfigWithBasepath();
    t = renderHook(() => useTranslation());

    await act(async () => {
      t.result.current.i18n.changeLanguage('en');
    });
  });

  const renderCookiePage = async () => {
    let asFragment: () => DocumentFragment = () => document.createDocumentFragment();

     await act(async () => {
      const component = render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <CookiesPage onPreferenceSet={() => {}}
          config={[
            {
              Name: t.result.current.t('ESSENTIAL_COOKIES'),
              category: 'essential',
              CookieDetails: GenericCookieJson.map(cookie => ({
                Name: cookie.name,
                Purpose: t.result.current.t(cookie.description),
                Expires: t.result.current.t(cookie.expires)
              })),
              DescriptionHeading: t.result.current.t('ESSENTIAL_COOKIES'),
              PostTableInformation: t.result.current.t('ESSENTIAL_COOKIES_P1')
            },
          ]}
          bannerMessageText={''}
          cookiesParagraphDescription={[t.result.current.t('COOKIES_PAGE_P1'), t.result.current.t('COOKIES_PAGE_P2')]}
          headingText={t.result.current.t('COOKIES')}
          columnHeaders={{
            name: t.result.current.t('COOKIE_NAME'),
            purpose: t.result.current.t('COOKIE_PURPOSE'),
            expires: t.result.current.t('COOKIE_EXPIRES')
          }}
          />
          <p className='govuk-body'>
            <a href={FIND_OUT_MORE_URL} className='govuk-link govuk-link--no-visited-state'>
              {t.result.current.t('COOKIE_FIND_OUT_MORE')}
            </a>
          </p>
        </I18nextProvider>
      );
      asFragment = component.asFragment;
    });

    return asFragment;
  };

  it('should render CookiePage content in English.', async () => {
    const asFragment = await renderCookiePage();
    expect(asFragment()).toMatchSnapshot();
  });

  it('should render CookiePage content in Welsh.', async () => {
    await act(async () => {
     t.result.current.i18n.changeLanguage('cy');
    });
    const asFragment = await renderCookiePage();
    expect(asFragment()).toMatchSnapshot();
  });
});
