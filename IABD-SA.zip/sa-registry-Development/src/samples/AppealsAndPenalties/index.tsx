import { FunctionComponent, useState, useEffect, useContext, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import setPageTitle, { registerServiceName } from '../../components/helpers/setPageTitleHelpers';
import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import AppFooter from '../../components/AppComponents/AppFooter';
import { resumeOnRefresh, triggerLogout, closeContainer } from '../../components/helpers/utils';
import useHMRCExternalLinks from '../../components/helpers/hooks/HMRCExternalLinks';
import TimeoutPopup from '../../components/AppComponents/TimeoutPopup';
import ServiceFallbackPageWrapper from '../../components/AppComponents/ServiceFallbackPageWrapper';
import SummaryPage from '../../components/AppComponents/SummaryPage';
import { initTimeout, settingTimer, staySignedIn } from '../../components/AppComponents/TimeoutPopup/timeOutUtils';
import AppHeader from '../../components/AppComponents/AppHeader';
import ApiServiceNotAvailable from '../../components/AppComponents/ApiErrorServiceNotAvailable';
import { useStartMashup } from '../../reuseables/PegaSetup';
import AppContext from '../../reuseables/AppContext';
import { setJourneyName } from '../../components/helpers/journeyRegistry';
import { TIMEOUT_115_SECONDS } from '../../components/helpers/constants';
import AppealsAndPenaltiesLanding from './AppealsAndPenaltiesLanding';
import languageToggle from '../../components/helpers/languageToggleHelper';
import { useAppLanguageToggle } from 'hmrc-odx-features-and-functions';
import LoadingWrapper from '../../components/AppComponents/LoadingSpinner/LoadingWrapper';
import i18n from 'i18next';

const AppealsAndPenalties: FunctionComponent<{ journeyName: string }> = ({ journeyName }) => {
  const { t } = useTranslation();
  const summaryPageRef = useRef<HTMLDivElement>(null);

  // Adding dynamic value as key.
  const serviceNameAndHeader = 'APPEAL_A_SELF_ASSESSMENT_PENALTY';
  const penaltyDataEndpoint = 'D_GetChargesForPastFourTaxYears';
  const penaltyDataEndpointParams = { LocalisedContent: true };
  const createCaseApi = 'HMRC-SA-Work-Appeal';

  const [showLandingPage, setShowLandingPage] = useState<boolean>(true);
  const [pCoreReady, setPCoreReady] = useState(false);
  const { showLanguageToggle } = useContext(AppContext);
  const [showLanguageToggleState, setShowLanguageToggleState] = useState(showLanguageToggle);
  const [currentDisplay, setCurrentDisplay] = useState<'pegapage' | 'resolutionpage' | 'servicenotavailable' | 'loading' | 'landingpage'>('pegapage');
  const [summaryPageContent, setSummaryPageContent] = useState<any>({
    content: null,
    title: null,
    banner: null
  });
  const [showTimeoutModal, setShowTimeoutModal] = useState(false);
  const [pConnect, setPconnect] = useState(null);
  const [isLogout, setIsLogout] = useState(false);
  const [millisecondsTillSignout, setmillisecondsTillSignout] = useState(TIMEOUT_115_SECONDS);

  const { hmrcURL } = useHMRCExternalLinks();

  const {
    showPega,
    setShowPega,
    serviceStatus,
    setServiceStatus,
    showResolutionPage,
    setShowResolutionPage,
    caseId,
    serviceNotAvailable,
    setServiceNotAvailable,
    assignmentPConnect,
    assignmentCancelled,
    setAssignmentCancelled,
    containerClosed,
    isLoading,
    renderRootComponent,
    rootProps
  } = useStartMashup({
    appBacklinkProps: {},
    serviceName: serviceNameAndHeader,
    appNameHeader: serviceNameAndHeader
  });

  useAppLanguageToggle(async (e: Event) => {
    const event = e as CustomEvent<{ language: string }>;

    await languageToggle(event.detail.language, i18n);
  });

  registerServiceName(t('APPEAL_A_SELF_ASSESSMENT_PENALTY'));
  setJourneyName(journeyName);

  useEffect(() => {
    initTimeout(setShowTimeoutModal, false, true, false);
  }, []);

  // Function to force re-render the pega Root component
  const forceRefreshRootComponent = () => {
    renderRootComponent();
  };

  useEffect(() => {
    if (Object.keys(rootProps).length) {
      PCore.getPubSubUtils().subscribe('forceRefreshRootComponent', forceRefreshRootComponent, 'forceRefreshRootComponent');
    }
    return () => {
      PCore?.getPubSubUtils().unsubscribe('forceRefreshRootComponent', 'forceRefreshRootComponent');
    };
  }, [rootProps]);

  useEffect(() => {
    if (assignmentPConnect) {
      setPconnect(assignmentPConnect);
    }
  }, [assignmentPConnect]);

  function handleSignout(e?) {
    e?.preventDefault();
    triggerLogout(setIsLogout);
  }

  const handleCaseStart = () => {
    setShowLandingPage(false);
    setShowPega(true);
  };

  const handleApiError = () => {
    setServiceNotAvailable(true);
    setShowPega(false);
    setShowLandingPage(false);
  };

  function returnedToPortal() {
    closeContainer();
    setShowPega(false);
    setShowResolutionPage(false);
    setShowLandingPage(true);
    setAssignmentCancelled(false);
    setSummaryPageContent({
      content: null,
      title: null,
      banner: null
    });
  }

  function handleServiceNameClick() {
    returnedToPortal();
  }

  useEffect(() => {
    function handleClick(e) {
      const targetId = e.target.id;
      if (targetId === 'homepage') {
        e.preventDefault();
        returnedToPortal();
      }
    }

    const currentSummaryPageRef = summaryPageRef.current;
    if (currentSummaryPageRef) {
      currentSummaryPageRef.addEventListener('click', handleClick);
    }
    return () => {
      if (currentSummaryPageRef) {
        currentSummaryPageRef.removeEventListener('click', handleClick);
      }
    };
  }, [summaryPageContent]);

  useEffect(() => {
    if (assignmentCancelled) {
      // user clicked save and come back later link
      returnedToPortal();
    }
  }, [assignmentCancelled]);

  useEffect(() => {
    if (isLoading) {
      setCurrentDisplay('loading');
      return;
    }
    if (showLandingPage && pCoreReady && !showResolutionPage && serviceStatus.isServiceHealthy) {
      setCurrentDisplay('landingpage');
    } else if (showPega) {
      setCurrentDisplay('pegapage');
    } else if (showResolutionPage) {
      setSummaryPageContent({
        content: null,
        title: null,
        banner: null
      });
      setCurrentDisplay('resolutionpage');
      setShowPega(false);
      getSdkConfig().then(config => {
        PCore.getRestClient()
          .invokeCustomRestApi(
            `${config.serverConfig.infinityRestServerUrl}/app/${config.serverConfig.appAlias}/api/application/v2/cases/${caseId}?pageName=SubmissionSummary`,
            {
              method: 'GET',
              body: {},
              headers: {},
              withoutDefaultHeaders: false
            },
            ''
          )
          .then((response: any) => {
              PCore.getPubSubUtils().unsubscribe(
              'languageToggleTriggered',
              'summarypageLanguageChange'
            );
            const summaryData = (response as SummaryResponse).data.data.caseInfo.content.ScreenContent.LocalisedContent;
            const currentLang = sessionStorage.getItem('rsdk_locale')?.slice(0, 2).toUpperCase() || 'EN';

            setSummaryPageContent(summaryData.find(data => data.Language === currentLang));
              PCore.getPubSubUtils().subscribe(
              'languageToggleTriggered',
              ({ language }) => {
                setSummaryPageContent(
                  summaryData.find(data => data.Language === language.toUpperCase())
                );
              },
              'summarypageLanguageChange'
            );
          })
          .catch(() => {
            return false;
          });
      });
    } else if (serviceNotAvailable) {
      setCurrentDisplay('servicenotavailable');
    } else {
      setCurrentDisplay('loading');
    }
    if (!showPega) {
      setPageTitle();
    }
  }, [showResolutionPage, showPega, serviceNotAvailable, pCoreReady, showLandingPage, containerClosed, isLoading, serviceStatus.isServiceHealthy]);

  useEffect(() => {
    resumeOnRefresh(pConnect, pCoreReady, setShowLandingPage, setServiceStatus);
  }, [pCoreReady, pConnect]);

  useEffect(() => {
    document.addEventListener('SdkConstellationReady', () => {
      PCore.onPCoreReady(() => {
        if (!pCoreReady) {
          setPCoreReady(true);
          PCore.getPubSubUtils().subscribe(
            PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
            () => {
              setShowPega(false);
            },
            'showStartPageOnCloseContainerItem'
          );
          getSdkConfig().then(config => {
            if (config.timeoutConfig.secondsTilLogout) {
              setmillisecondsTillSignout(config.timeoutConfig.secondsTilLogout * 1000);
            }
          });
        }
      });
      settingTimer();
    });

    return () => {
      PCore?.getPubSubUtils().unsubscribe('CustomAssignmentFinished', 'CustomAssignmentFinished');
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );
    };
  }, []);

  /* ***
   * Application specific PCore subscriptions
   *
   * TODO Can this be made into a tidy helper? including its own clean up? A custom hook perhaps
   */
  document.addEventListener('SdkConstellationReady', () => {
    PCore.onPCoreReady(() => {
      PCore.getPubSubUtils().subscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        () => {
          setShowPega(false);
        },
        'showStartPageOnCloseContainerItem'
      );
    });
    settingTimer();
    PCore.getStore().subscribe(() =>
      staySignedIn(setShowTimeoutModal, '', null, false, true, currentDisplay === 'resolutionpage', penaltyDataEndpointParams)
    );

    PCore?.getPubSubUtils().subscribe(
      'CUSTOM_EVENT_BACK',
      () => {
        returnedToPortal();
      },
      'CUSTOM_EVENT_BACK'
    );
  });

  useEffect(() => {
    return () => {
      PCore.getPubSubUtils().unsubscribe(
        PCore.getConstants().PUB_SUB_EVENTS.CONTAINER_EVENTS.CLOSE_CONTAINER_ITEM,
        'showStartPageOnCloseContainerItem'
      );
    };
  }, []);

  useEffect(() => {
    getSdkConfig().then(config => {
      setShowLanguageToggleState(config?.cessationConfig?.showLanguageToggle);
    });
  }, []);

  if (currentDisplay === 'servicenotavailable') {
    return (
      <>
        <TimeoutPopup
          show={showTimeoutModal}
          millisecondsTillSignout={millisecondsTillSignout}
          staySignedinHandler={() => staySignedIn(setShowTimeoutModal, penaltyDataEndpoint, null, false, true, false, penaltyDataEndpointParams)}
          signoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout);
          }}
          autoSignoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout, true);
          }}
          isAuthorised
          staySignedInButtonText='Stay signed in'
          signoutButtonText='Sign out'
        />
        <AppHeader
          appname={t('APPEAL_A_SELF_ASSESSMENT_PENALTY')}
          hasLanguageToggle={showLanguageToggleState}
          handleSignout={handleSignout}
          handleServiceNameClick={handleServiceNameClick}
          betafeedbackurl={`${hmrcURL}contact/beta-feedback?service=claim-child-benefit-frontend&backUrl=/fill-online/claim-child-benefit/recently-claimed-child-benefit`}
        />
        <div className='govuk-width-container'>
          <LoadingWrapper pageIsLoading={isLoading} spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}>
            <ApiServiceNotAvailable />
          </LoadingWrapper>
        </div>
        <AppFooter />
      </>
    );
  } else {
    return (
      <AppContext.Provider
        value={{
          appBacklinkProps: {},
          showLanguageToggle,
          serviceName: serviceNameAndHeader,
          appNameHeader: serviceNameAndHeader
        }}
      >
        <TimeoutPopup
          show={showTimeoutModal}
          millisecondsTillSignout={millisecondsTillSignout}
          staySignedinHandler={() =>
            staySignedIn(setShowTimeoutModal, penaltyDataEndpoint, null, false, true, currentDisplay === 'resolutionpage', penaltyDataEndpointParams)
          }
          signoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout);
          }}
          autoSignoutHandler={(e?) => {
            e?.preventDefault();
            triggerLogout(setIsLogout, true);
          }}
          isAuthorised
          staySignedInButtonText='Stay signed in'
          signoutButtonText='Sign out'
        />
        <AppHeader
          handleSignout={handleSignout}
          handleServiceNameClick={handleServiceNameClick}
          appname={t('APPEAL_A_SELF_ASSESSMENT_PENALTY')}
          hasLanguageToggle={showLanguageToggleState}
          isPegaApp={showPega}
          betafeedbackurl={`${hmrcURL}contact/beta-feedback?service=claim-child-benefit-frontend&backUrl=/fill-online/claim-child-benefit/recently-claimed-child-benefit`}
        />
        <div className='govuk-width-container'>
          {pCoreReady && (
            <ServiceFallbackPageWrapper serviceStatus={serviceStatus}>
              <>
                <div id='pega-part-of-page'>
                  <div id='pega-root' className={`${isLogout ? 'visibility-hidden' : ''}`}></div>
                </div>
                <LoadingWrapper pageIsLoading={!pConnect} spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}>
                  <>
                    {currentDisplay === 'landingpage' && pConnect && (
                      <AppealsAndPenaltiesLanding
                        isLogout={isLogout}
                        pConn={pConnect}
                        penaltyDataEndpoint={penaltyDataEndpoint}
                        createCaseEndpoint={createCaseApi}
                        handleCaseStart={handleCaseStart}
                        penaltyDataEndpointParams={penaltyDataEndpointParams}
                        handleApiError={handleApiError}
                        setServiceStatus={setServiceStatus}
                      ></AppealsAndPenaltiesLanding>
                    )}

                    {currentDisplay === 'resolutionpage' && (
                      <SummaryPage
                        summaryContent={summaryPageContent?.Content}
                        summaryTitle={summaryPageContent?.Title}
                        summaryBanner={summaryPageContent?.Banner}
                        ref={summaryPageRef}
                      />
                    )}
                  </>
                </LoadingWrapper>
              </>
            </ServiceFallbackPageWrapper>
          )}
        </div>

        <AppFooter />
      </AppContext.Provider>
    );
  }
};
export default AppealsAndPenalties;
