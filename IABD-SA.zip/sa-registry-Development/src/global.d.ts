declare module 'hmrc-gds-react-components/styles.css';
declare module '*.scss';
declare const PCore: any;
declare type C11nEnv = any;
interface Window {
  dataLayer: any[];
  PCore: any;
  C11nEnv: any;
}

interface LocalisedContent {
  Language: string;
  // Add other properties your content has
}

interface SummaryResponse {
  data: {
    data: {
      caseInfo: {
        content: {
          ScreenContent: {
            LocalisedContent: LocalisedContent[];
          };
        };
      };
    };
  };
}
