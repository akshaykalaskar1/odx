
// from react_root.js
import React from 'react';
import { createRoot } from 'react-dom/client';
import TopLevelApp from './samples/TopLevelApp';
import '../assets/css/appStyles.scss';

const outletElement = document.getElementById('outlet');
const root = createRoot(outletElement);

if (outletElement) {
  // const root = render(outletElement);
  root.render(
    <>
      <span className='govuk-visually-hidden' id='titleAlert' role='alert' aria-live='polite'></span>
      <TopLevelApp />
    </>
  );
}
