// Statically load all "local" components that aren't yet in the npm package

import FieldCheckbox from './src/components/override-sdk/field/Checkbox/';
import FieldTextArea from './src/components/override-sdk/field/TextArea/';
import FieldDate from './src/components/override-sdk/field/Date/';
import CheckAnswers from './src/components/custom-sdk/template/CheckAnswers/';
import ChangeLink from './src/components/custom-sdk/field/ChangeLink/';
import TemplateDefaultForm from './src/components/override-sdk/template/DefaultForm/';
import InfraAssignmentCard from './src/components/override-sdk/infra/AssignmentCard/';
import InfraActionButtons from './src/components/override-sdk/infra/ActionButtons/';
import InfraAssignment from './src/components/override-sdk/infra/Assignment/';
import InfraFlowContainer from './src/components/override-sdk/infra/FlowContainer/';
import FieldPhone from './src/components/override-sdk/field/Phone/';
import InfraView from './src/components/override-sdk/infra/View/';
import TemplateCaseView from './src/components/override-sdk/template/CaseView/';
import FieldDropdown from './src/components/override-sdk/field/Dropdown/';
import TemplateFieldGroupTemplate from './src/components/override-sdk/template/FieldGroupTemplate/';
import TemplateDetails from './src/components/override-sdk/template/Details/';
import InfraViewContainer from './src/components/override-sdk/infra/ViewContainer/';
import MimicASentence from './src/components/custom-sdk/template/MimicASentence/';
import HmrcOdxGdsInfoPanel from './src/components/custom-sdk/template/HMRC_ODX_GDSInfoPanel/';
import HmrcOdxGdsSummaryCard from './src/components/custom-sdk/template/HMRC_ODX_GDSSummaryCard/';
import HmrcOdxGdsButton from './src/components/custom-sdk/field/HMRC_ODX_GDSButton/';
import HmrcOdxComplexQuestionExplanation from './src/components/custom-sdk/field/HMRC_ODX_ComplexQuestionExplanation/';
import HmrcOdxGdsTaskListTemplate from './src/components/custom-sdk/template/HMRC_ODX_GDSTaskListTemplate/';
import HmrcOdxGdsTextPresentation from './src/components/custom-sdk/field/HMRC_ODX_GDSTextPresentation/';
import HmrcOdxGdsCheckAnswersPage from './src/components/custom-sdk/template/HMRC_ODX_GDSCheckAnswersPage/';
import HmrcOdxGoBackGoBack from './src/components/custom-sdk/field/HMRC_ODXGoBack_GoBack/';
import { HmrcOdxExtendedDate,AutocompleteWrapper,TextInputWrapper,RadioButtonGroupWrapper } from 'hmrc-dxapi-components-package';
import useIsOnlyField from './src/components/helpers/hooks/QuestionDisplayHooks';
import {
  ReadOnlyDefaultFormContext,
  DefaultFormContext,
  ErrorMsgContext
} from './src/components/helpers/HMRCAppContext';
import i18n from './src/components/helpers/hooks/i18n';
/* import end - DO NOT REMOVE */

// localSdkComponentMap is the JSON object where we'll store the components that are
// found locally. If not found here, we'll look in the Pega-provided component map

const localSdkComponentMap = {
  Checkbox: FieldCheckbox,
  TextInput: TextInputWrapper({
    readOnlyDefaultFormContext: ReadOnlyDefaultFormContext,
    errorsContext: ErrorMsgContext,
    isOnlyFieldHook: useIsOnlyField,
  }),


  TextArea: FieldTextArea,
  Date: FieldDate,
  HMRC_ODX_CheckAnswers: CheckAnswers,
  HMRC_ODX_ChangeLink: ChangeLink,
  HMRC_ODX_MimicASentence: MimicASentence,
  RadioButtons: RadioButtonGroupWrapper({
    isOnlyFieldHook: useIsOnlyField,
    readOnlyDefaultFormContext: ReadOnlyDefaultFormContext,
    defaultFormContext: DefaultFormContext
  }),
  DefaultForm: TemplateDefaultForm,
  Assignment: InfraAssignment,
  AssignmentCard: InfraAssignmentCard,
  ActionButtons: InfraActionButtons,
  FlowContainer: InfraFlowContainer,
  HMRC_ODX_PhoneNumber: FieldPhone,
  View: InfraView,
  CaseView: TemplateCaseView,
  Dropdown: FieldDropdown,
  Group: TemplateFieldGroupTemplate,
  Details: TemplateDetails,
  ViewContainer: InfraViewContainer,
  HMRC_ODX_GDSInfoPanel: HmrcOdxGdsInfoPanel,
  HMRC_ODX_GDSSummaryCard: HmrcOdxGdsSummaryCard,
  HMRC_ODX_GDSButton: HmrcOdxGdsButton,
  HMRC_ODX_ComplexQuestionExplanation: HmrcOdxComplexQuestionExplanation,
  HMRC_ODX_GDSTextPresentation: HmrcOdxGdsTextPresentation,
  HMRC_ODX_GDSTaskListTemplate: HmrcOdxGdsTaskListTemplate,
  HMRC_ODXGoBack_GoBack: HmrcOdxGoBackGoBack,
  HMRC_ODX_GDSCheckAnswersPage: HmrcOdxGdsCheckAnswersPage,
  HMRC_ODX_ExtendedDate: HmrcOdxExtendedDate,
  AutoComplete: AutocompleteWrapper({
    readOnlyDefaultFormContext: ReadOnlyDefaultFormContext,
    errorsContext: ErrorMsgContext,
    isOnlyFieldHook: useIsOnlyField,
    translationConfig: {
      translator: i18n.t.bind(i18n),
      keys: {
        ASSISTIVE_HINT: 'ASSISTIVE_HINT',
        NO_RESULTS: 'NO_RESULTS',
        NO_RESULTS_STATUS: 'NO_RESULTS_STATUS',
        GDS_ACTION_CHANGE: 'GDS_ACTION_CHANGE',
        ERROR: 'ERROR'
      }
    }
  })
  /* map end - DO NOT REMOVE */
};

export default localSdkComponentMap;
