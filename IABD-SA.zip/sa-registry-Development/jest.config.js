module.exports = {
  testEnvironment: 'jsdom',
  roots: ['<rootDir>/src'],
  preset: 'ts-jest',
  transform: {
    '^.+\\.(t|j)sx?$': 'ts-jest'
  },
  testMatch: ['**/?(*.)+(test).[jt]s?(x)'],
  setupFilesAfterEnv: ['<rootDir>/tests/setupTests.ts'],
  coverageDirectory: 'tests/coverage',
  transformIgnorePatterns: ['/node_modules/(?!@pega/auth|hmrc-gds-react-components|hmrc-odx-features-and-functions)'],
  setupFiles: ['<rootDir>/tests/govukFrontendSupport.ts'],
   moduleNameMapper: {
    '\\.(css|less|scss|sass)$': 'identity-obj-proxy',
    '^hmrc-gds-react-components$': '<rootDir>/node_modules/hmrc-gds-react-components/dist/entry.js'
  }
};
