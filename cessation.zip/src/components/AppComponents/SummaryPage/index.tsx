import SummaryPage from './SummaryPage';

export default SummaryPage;
