# The **custom-constellation/template** directory

The **src/components/custom-constellation/template** directory contains the code for the Constellation-based associated component for any custom **template** component you have created for use with the **React SDK**.

For each component in the **src/components/custom-constellation/template** directory, there will be a matching component in the **src/components/custom-sdk/template** directory.
