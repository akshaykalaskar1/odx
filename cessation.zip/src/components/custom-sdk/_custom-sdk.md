# The **components/custom-sdk** directory

The **src/components/custom-sdk** directory contains the code for custom components that you create and use with the **React SDK**.

When you run the **npm run  create** command to create new components, the generated code that you can use as a starting point for your component development will be placed in type-specific and component-specific folders in **src/components/custom-sdk**.
