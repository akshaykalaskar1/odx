import { fetchDataAndError } from '../../../../../components/helpers/utils';

import { EmploymentTaxData as EmploymentTaxDataType } from '../../../../AppSelector/type/routeTypes';

const EmploymentTaxData = (setEmploymentTaxData: (data: EmploymentTaxDataType | null) => void) => {
  const fetchEmploymentTaxData = async () => {
    try {
      const { Customer, MDTPURLVALUE } = await fetchDataAndError();

      const newData =
        Customer !== null && Customer !== undefined ? { Customer, MDTPURLVALUE } : null;

      setEmploymentTaxData(newData);
    } catch (error) {
      console.error(error); // eslint-disable-line no-console
    }
  };

  return { fetchEmploymentTaxData };
};

export default EmploymentTaxData;
