import React, { useEffect } from 'react';
import PAYE_ROUTES from '../../../AppSelector/payeRoutes';
import useCustomNavigate from '../../../../components/helpers/hooks/useCustomNavigate';
import { clearCaseFlag } from '../../../../components/helpers/utils';

const PegaCaseInitiated: React.FC<{
  initiatePegaCase: (caseType: string) => void;
  caseType: string;
  employmentTaxData?: any;
  resetAppDisplay: () => void;
  getShutteredService: () => Promise<boolean>;
}> = ({ initiatePegaCase, caseType, employmentTaxData, resetAppDisplay, getShutteredService }) => {
  const goTo = useCustomNavigate();

  function closeContainer() {
    if (PCore.getContainerUtils().getActiveContainerItemName('app/primary')) {
      PCore.getContainerUtils().closeContainerItem(PCore.getContainerUtils().getActiveContainerItemContext('app/primary'), { skipDirtyCheck: true });
    }
  }

  useEffect(() => {
    PCore?.getPubSubUtils()?.subscribe(
      'CUSTOM_EVENT_BACK',
      () => {
        clearCaseFlag();
        if (caseType === 'addEmployee') {
          goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_EMPLOYMENT);
        } else if (caseType === 'updateEmployee') {
          goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_EMPLOYMENT);
        } else if (caseType === 'addPension') {
          goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_PENSION);
        } else if (caseType === 'updatePension') {
          goTo(PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_PENSION);
        }
        closeContainer();
        resetAppDisplay();
      },
      'CUSTOM_EVENT_BACK'
    );

    return function cleanup() {
      PCore.getPubSubUtils().unsubscribe('CUSTOM_EVENT_BACK', '');
    };
  }, []);

  useEffect(() => {
    const key = `case-created-${caseType}`;
    if (sessionStorage.getItem(key)) {
      return;
    }
    sessionStorage.setItem(key, 'true');

    const runEffect = async () => {
      initiatePegaCase(caseType);

      const currentEmpList = employmentTaxData?.Customer?.TaxSummaryList[0]?.CurrentEmploymentList;
      const currentPenList = employmentTaxData?.Customer?.TaxSummaryList[0]?.CurrentPensionList;

      const filterList = (list: any[]) =>
        list.map(emp => ({
          AssignedTaxCode: emp.AssignedTaxCode,
          EmployerName: emp.EmployerName,
          EstimatedPay: emp.EstimatedPay,
          PAYENumber: emp.PAYENumber,
          PayRollID: emp.PayRollID,
          StartDate: emp.StartDate
        }));

      const createCase = async () => {
        const filteredEmploymentList = currentEmpList?.length > 0 ? filterList(currentEmpList) : [];
        const filteredPensionList = currentPenList?.length > 0 ? filterList(currentPenList) : [];

        const startingFields = {
          ...(caseType === 'updateEmployee' && {
            CurrentEmploymentList: filteredEmploymentList
          }),
          ...(caseType === 'updatePension' && {
            CurrentPensionList: filteredPensionList
          }),
          NotificationLanguage: sessionStorage.getItem('rsdk_locale')?.slice(0, 2) || 'en'
        };

        const caseTypes: Record<string, string> = {
          addEmployee: 'HMRC-PAYE-Work-IABD-MissingEmp',
          updateEmployee: 'HMRC-PAYE-Work-IABD-UpdateEmpLeavingDate',
          addPension: 'HMRC-PAYE-Work-IABD-AddPension',
          updatePension: 'HMRC-PAYE-Work-IABD-RemovePension'
        };

        const openCaseID = caseTypes[caseType];

        if (openCaseID) {
          await PCore.getMashupApi().createCase(openCaseID, PCore.getConstants().APP.APP, {
            startingFields
          } as any);
        }
      };

      const isServiceShuttered = await getShutteredService();

      if (!isServiceShuttered) {
        await createCase();
      }
    };

    runEffect();
  }, []);

  return null;
};

export default PegaCaseInitiated;
