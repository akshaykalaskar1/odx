import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import ShutteredServiceWrapper from '../../../../../components/AppComponents/ShutterService/ShutteredServiceWrapper';
import LoadingWrapper from '../../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import useServiceShuttered from '../../../../../components/helpers/hooks/useServiceShuttered';
import setPageTitle from '../../../../../components/helpers/setPageTitleHelpers';
import i18next from 'i18next';
import { TimeLineEvent } from '../../../../../reuseables/Types/TimeLineEvents';
import P2ExplainerDetails from './P2ExplainerDetails';
import type { ExplainerData } from './typings';
import ErrorMessage from '../../ErrorPage/errorMessage';

interface P2ExplainerProps {
  redirectCurrentYearPage: () => void;
  redirecLatestEventPage: (s: string) => void;
  redirectToViewTimelineDetailsPage: () => void;
  timelineDetails: Partial<TimeLineEvent>;
  eventType: string;
}

export default function P2Explainer({
  redirectCurrentYearPage,
  redirecLatestEventPage,
  redirectToViewTimelineDetailsPage,
  timelineDetails,
  eventType
}: P2ExplainerProps) {
  const { t } = useTranslation();
  const { serviceShuttered, isLoading: isShutteredServiceLoading } = useServiceShuttered();
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [fetchedData, setFetchedData] = useState<ExplainerData | null>(null);
  const [errorMsgArr, setErrorMsgArr] = useState<string[]>([]);
  const [hasFetched, setHasFetched] = useState(false);

  const {
    EmploymentType,
    EmploymentSequenceNumber,
    NetCodedAllowance,
    ActiveOccupationalPension,
    EmployerName,
    IntegerSortingHolder,
    issuedtaxCode
  } = timelineDetails;

  useEffect(() => {
    setPageTitle();
  }, [i18next.language]);

  useEffect(() => {
    if (isShutteredServiceLoading) return;
    if (serviceShuttered) {
      setIsPageLoading(false);
      return;
    }
    if (hasFetched) return;

    setHasFetched(true);
    setIsPageLoading(true);
    setErrorMsgArr([]);
    setFetchedData(null);

    const parameters: any = {
      EmploymentRecordType: EmploymentType,
      ESN: EmploymentSequenceNumber,
      NetCodedAllowance,
      ActiveOccupationalPension,
      EmployerName,
      taxCodeIdentifier: IntegerSortingHolder,
      issuedtaxCode
    };

    const fetchData = async () => {
      try {
        const response = await PCore.getDataPageUtils().getDataAsync('D_P2Explainer', 'root', parameters, {}, {}, { invalidateCache: true });

        const data = response?.data?.[0];
        const errorMsg = data?.pyErrors?.pyMessages?.[0]?.pyErrorMessage;

        if (Array.isArray(errorMsg) && errorMsg.length > 0) {
          setErrorMsgArr(errorMsg);
        } else {
          const taxSummary = data?.Customer?.TaxSummaryList?.[0] ?? null;
          setFetchedData(taxSummary);
        }
      } catch {
        setErrorMsgArr(['ERROR']);
        console.log('Error: D_P2Explainer failed');
      } finally {
        setIsPageLoading(false);
      }
    };

    fetchData();
  }, [
    isShutteredServiceLoading,
    serviceShuttered,
    hasFetched,
    EmploymentType,
    EmploymentSequenceNumber,
    NetCodedAllowance,
    ActiveOccupationalPension,
    EmployerName,
    IntegerSortingHolder,
    issuedtaxCode
  ]);

  return (
    <ShutteredServiceWrapper serviceIsShuttered={serviceShuttered}>
      <LoadingWrapper
        pageIsLoading={isPageLoading || isShutteredServiceLoading}
        spinnerProps={{ bottomText: t('LOADING'), size: '30px', label: t('LOADING') }}
      >
        {errorMsgArr.length > 0 ? (
          <ErrorMessage />
        ) : (
          <P2ExplainerDetails
            redirecLatestEventPage={redirecLatestEventPage}
            redirectCurrentYearPage={redirectCurrentYearPage}
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
            timelineDetails={timelineDetails}
            eventType={eventType}
            explainerData={fetchedData}
            pageName={fetchedData?.pyTemplateDataField}
          />
        )}
      </LoadingWrapper>
    </ShutteredServiceWrapper>
  );
}
