export interface EmploymentOrPension {
  AssignedTaxCode?: string;
  EmployerName?: string;
  EstimatedPay?: string;
  PAYENumber?: string;
  PayRollID?: string;
  StartDate?: string;
}

export interface TaxSummary {
  CurrentEmploymentList?: EmploymentOrPension[];
  CurrentPensionList?: EmploymentOrPension[];
  TaxYearStartDate?: string;
}

export interface Customer {
  pyFullName?: string;
  TaxSummaryList?: TaxSummary[];
}

export interface EmploymentTaxData {
  Customer: Customer;
  MDTPURLVALUE?: string;
}

export type PayeRouteState = {
  details?: any;
  comingFromPage?: string;
  timelineDetails?: any;
  eventType?: string;
  componentName?: string;
  understandYourTaxDetails?: any;
  fromPage?: string;
  templateValue?: string;
  pageName?: string;
  sourceAmount?: string;
  employmentSequenceNumber?: number;
  previousPage?: string;
  backOverride?: string;
  caseType?: string;
};

export type IabdOutletContext = {
  employmentTaxData: EmploymentTaxData | null;
  setEmploymentTaxData: React.Dispatch<React.SetStateAction<EmploymentTaxData | null>>;
  setAnnualCodingData: React.Dispatch<React.SetStateAction<any>>;
  setTaxYearStartDate: React.Dispatch<React.SetStateAction<string>>;
  dynamicIABDVals: any;
  dynamicDisabledIABDDetails: boolean;
  annualCodingData: any;
  taxYearStartDate: string;
  handleLinkClick: (...args: any[]) => void;
  beginClaim: () => void;
  beginIntrruptionPage: (...args: any[]) => void;
  beginUpdateClaim: () => void;
  beginAddPensionClaim: () => void;
  beginUpdatePensionClaim: () => void;
  redirectLandingPage: () => void;
  redirectCurrentYearPage: () => void;
  redirectToAllIABDLandingPage: (fromPage: string) => void;
  redirecLatestEventPage: (fromPage: string) => void;
  redirectToUnderstandYourTaxPage: () => void;
  redirectToViewTimelineDetailsPage: (fromPage?: string) => void;
  redirectAnnualCodingTemplatePage: (args: { templateValue: string; pageName: string }) => void;
  redirectToDeductionExplainerpage: (
    comingFrom: string,
    explainerPage: string,
    sourceAmount: string
  ) => void;
  handleViewAllDetailsClick: (detail: any) => void;
  handleViewDetailsClick: (timeline: any, event: string) => void;
  handleUnderstandYourTaxCodeClick: (
    understandYourTax: any,
    taxCode: string,
    fromPage: string
  ) => void;
  handleDetailExplainerLinkClick: (e, componentName: string) => void;
  handleMoreInformationClick: (componentName: string) => void;
  goBack: () => void;
  navClickHandler: any;
  startNow: (e: React.MouseEvent<HTMLAnchorElement>, caseType: string) => void;
  setComingFromPage: React.Dispatch<React.SetStateAction<string>>;
  setCustomerDetails: React.Dispatch<React.SetStateAction<string>>;
  customerDetails: any;
  setAccessGroup: React.Dispatch<React.SetStateAction<string>>;
  accessGroup: any;
  initiatePegaCase: (caseType: string) => void;
  resetAppDisplay: () => void;
  getShutteredService: () => Promise<boolean>;
  caseId: string;
};
