import { getSdkConfig } from '@pega/auth/lib/sdk-auth-manager';
import { clearCaseFlag } from './utils';

export default async function fetchSubmissionSummary({ PCore, caseId, currentLang }: { PCore: any; caseId: string; currentLang: string }) {
  try {
    const config = await getSdkConfig();

    const response = await PCore.getRestClient().invokeCustomRestApi(
      `${config.serverConfig.infinityRestServerUrl}/app/${config.serverConfig.appAlias}/api/application/v2/cases/${caseId}?pageName=SubmissionSummary`,
      {
        method: 'GET',
        body: '',
        headers: '',
        withoutDefaultHeaders: false
      },
      ''
    );

    const summaryData = response.data.data.caseInfo.content.ScreenContent.LocalisedContent;

    const filteredData = summaryData.find((d: any) => d.Language === currentLang.toUpperCase());
    clearCaseFlag();
    return {
      summaryData,
      filteredData
    };
  } catch (error) {
    console.error('Error fetching submission summary:', error); // eslint-disable-line no-console
    throw error;
  }
}
