import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import PAYE_ROUTES from '../../../samples/AppSelector/payeRoutes';

const useRouteInvalidRequestHandler = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const restrictedRedirections = Object.values(PAYE_ROUTES.RESTRICTED_REDIRECTION) as string[];
  const isRestrictedRedirect = restrictedRedirections.includes(location.pathname);
  if ((!location.state || Object.keys(location.state).length === 0) && isRestrictedRedirect) {
    navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING);
  }

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const error = params.get('error');
    const PEGA_CLIENT_REGISTRATION_MISSING = 'invalid_request';

    if (error === PEGA_CLIENT_REGISTRATION_MISSING) {
      navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING, { replace: true });
      // eslint-disable-next-line no-console
      console.log('Error: invalid_request', location.pathname + location.search + location.hash);
    }
  }, [location]);
};

export default useRouteInvalidRequestHandler;
