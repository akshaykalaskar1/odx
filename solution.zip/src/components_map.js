// import loadable from "@loadable/component";

export default {
  // Currency: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Currency" */ "./components/forms/Currency")
  //     )
  //   ],
  //   scripts: []
  // },
  // DeferLoad: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "DeferLoad" */ "./components/DeferLoad")
  //     )
  //   ]
  // },
  // ViewContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ViewContainer" */
  //         "./components/ViewContainer"
  //       )
  //     )
  //   ]
  // },
  // PreviewViewContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "PreviewViewContainer" */
  //         "./components/PreviewViewContainer"
  //       )
  //     )
  //   ]
  // },
  // RootContainer: {
  //   modules: [
  //     loadable(() =>
  //     {
  //       import(
  //         /* webpackChunkName: "RootContainer" */
  //         "./components/RootContainer/index.tsx"
  //       )
  //     }
  //     )
  //   ]
  // },
  // HybridViewContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "HybridViewContainer" */
  //         "./components/HybridViewContainer"
  //       )
  //     )
  //   ]
  // },
  // ModalViewContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ModalViewContainer" */
  //         "./components/ModalViewContainer"
  //       )
  //     )
  //   ]
  // },
  // LoadingComponent: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Loading" */
  //         "./components/Loading"
  //       )
  //     )
  //   ]
  // },
  // FlowContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "FlowContainer" */
  //         "./components/FlowContainer"
  //       )
  //     )
  //   ]
  // },
  // CaseCreateStage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CaseCreateStage" */
  //         "./components/CaseCreateStage"
  //       )
  //     )
  //   ]
  // },
  // Todo: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Todo" */ "./components/Widgets/Todo")
  //     )
  //   ]
  // },
  // Assignment: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Assignment" */
  //         "./components/Assignment"
  //       )
  //     )
  //   ]
  // },
  // Panel: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Panel" */ "./components/Panel")
  //     )
  //   ]
  // },
  // TextInput: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TextInput" */ "./components/forms/TextInput"
  //       )
  //     )
  //   ]
  // },
  // Phone: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Phone" */ "./components/forms/Phone")
  //     )
  //   ]
  // },
  // Percentage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Percentage" */ "./components/forms/Percentage"
  //       )
  //     )
  //   ]
  // },
  // Email: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Email" */ "./components/forms/Email")
  //     )
  //   ]
  // },
  // Integer: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Integer" */ "./components/forms/Integer")
  //     )
  //   ]
  // },
  // Decimal: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Decimal" */ "./components/forms/Decimal")
  //     )
  //   ]
  // },
  // URL: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "URL" */ "./components/forms/URL")
  //     )
  //   ]
  // },
  // SemanticLink: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "SemanticLink" */ "./components/forms/SemanticLink"
  //       )
  //     )
  //   ]
  // },
  // View: {
  //   modules: [
  //     loadable(() => import(/* webpackChunkName: "View" */ "./components/View"))
  //   ]
  // },
  // Region: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Region" */ "./components/Region")
  //     )
  //   ]
  // },
  // Checkbox: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Checkbox" */ "./components/forms/Checkbox")
  //     )
  //   ]
  // },
  // RadioButtons: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "RadioButtons" */
  //         "./components/forms/RadioButtons"
  //       )
  //     )
  //   ]
  // },
  // DateTime: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "DateTime" */ "./components/forms/DateTime")
  //     )
  //   ]
  // },
  // Date: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Date" */ "./components/forms/Date")
  //     )
  //   ]
  // },
  // Time: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Time" */ "./components/forms/Time")
  //     )
  //   ]
  // },
  // Text: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Text" */ "./components/forms/Text")
  //     )
  //   ]
  // },
  // TextArea: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "TextArea" */ "./components/forms/TextArea")
  //     )
  //   ]
  // },
  // TextContent: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TextContent" */ "./components/forms/TextContent"
  //       )
  //     )
  //   ]
  // },
  // RichText: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "RichText" */ "./components/forms/RichText")
  //     )
  //   ]
  // },
  // Pulse: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Pulse" */ "./components/FeedContainer")
  //     )
  //   ]
  // },
  // Activity: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Activity" */
  //         "./components/Activity/Activity"
  //       )
  //     )
  //   ]
  // },
  // ListView: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ListView" */
  //         "./components/Templates/ListView"
  //       )
  //     )
  //   ]
  // },
  // SimpleTable: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "SimpleTable" */
  //         "./components/Templates/SimpleTable"
  //       )
  //     )
  //   ]
  // },
  // DataReference: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DataReference" */
  //         "./components/Templates/DataReference"
  //       )
  //     )
  //   ]
  // },
  // ListPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ListPage" */
  //         "./components/Templates/ListPage"
  //       )
  //     )
  //   ]
  // },
  // OneColumnPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "OneColumnPage" */
  //         "./components/Templates/PageLayout/OneColumnPage"
  //       )
  //     )
  //   ]
  // },
  // TwoColumnPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TwoColumnPage" */
  //         "./components/Templates/PageLayout/TwoColumnPage"
  //       )
  //     )
  //   ]
  // },
  // ThreeColumnPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ThreeColumnPage" */
  //         "./components/Templates/PageLayout/ThreeColumnPage"
  //       )
  //     )
  //   ]
  // },
  // NarrowWidePage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "NarrowWidePage" */
  //         "./components/Templates/PageLayout/NarrowWidePage"
  //       )
  //     )
  //   ]
  // },
  // WideNarrowPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "WideNarrowPage" */
  //         "./components/Templates/PageLayout/WideNarrowPage"
  //       )
  //     )
  //   ]
  // },
  // Page: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Page" */ "./components/Templates/Page")
  //     )
  //   ]
  // },
  // TabbedPage: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TabbedPage" */ "./components/Templates/TabbedPage"
  //       )
  //     )
  //   ]
  // },
  // OneColumn: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "OneColumn" */
  //         "./components/Templates/Forms/OneColumn"
  //       )
  //     )
  //   ]
  // },
  // TwoColumn: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TwoColumn" */
  //         "./components/Templates/Forms/TwoColumn"
  //       )
  //     )
  //   ]
  // },
  // NarrowWideForm: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "NarrowWideForm" */
  //         "./components/Templates/Forms/NarrowWide"
  //       )
  //     )
  //   ]
  // },
  // WideNarrowForm: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "WideNarrowForm" */
  //         "./components/Templates/Forms/WideNarrow"
  //       )
  //     )
  //   ]
  // },
  // DefaultForm: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DefaultForm" */
  //         "./components/Templates/Forms/DefaultForm"
  //       )
  //     )
  //   ]
  // },
  // OneColumnTab: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "OneColumnTab" */
  //         "./components/Templates/Tab"
  //       )
  //     )
  //   ]
  // },
  // TwoColumnTab: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "TwoColumnTab" */
  //         "./components/Templates/Tab"
  //       )
  //     )
  //   ]
  // },
  // ThreeColumnTab: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ThreeColumnTab" */
  //         "./components/Templates/Tab"
  //       )
  //     )
  //   ]
  // },
  // WideNarrowTab: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "WideNarrowTab" */
  //         "./components/Templates/Tab"
  //       )
  //     )
  //   ]
  // },
  // NarrowWideTab: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "NarrowWideTab" */
  //         "./components/Templates/Tab"
  //       )
  //     )
  //   ]
  // },
  // RepeatingTemplate: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "RepeatingTemplate" */
  //         "./components/Templates/RepeatingTemplate"
  //       )
  //     )
  //   ]
  // },
  // AppShell: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "AppShell" */
  //         "./components/Templates/AppShell"
  //       )
  //     )
  //   ]
  // },
  // SubTabs: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "SubTabs" */
  //         "./components/Templates/Tab/SubTabs"
  //       )
  //     )
  //   ]
  // },
  // CaseView: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CaseView" */
  //         "./components/Templates/CaseView"
  //       )
  //     )
  //   ]
  // },
  // CasePreview: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CasePreview" */
  //         "./components/Templates/CasePreview"
  //       )
  //     )
  //   ]
  // },
  // CaseSummary: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CaseSummary" */
  //         "./components/Templates/CaseSummary"
  //       )
  //     )
  //   ]
  // },
  // Details: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Details" */
  //         "./components/Templates/Details"
  //       )
  //     )
  //   ]
  // },
  // DetailsTwoColumn: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DetailsTwoColumn" */
  //         "./components/Templates/Details"
  //       )
  //     )
  //   ]
  // },
  // DetailsThreeColumn: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DetailsThreeColumn" */
  //         "./components/Templates/Details"
  //       )
  //     )
  //   ]
  // },
  // DetailsSubTabs: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DetailsSubTabs" */
  //         "./components/Templates/Details/SubTabs"
  //       )
  //     )
  //   ]
  // },
  // NarrowWideDetails: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "NarrowWideDetails" */
  //         "./components/Templates/Details"
  //       )
  //     )
  //   ]
  // },
  // WideNarrowDetails: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "WideNarrowDetails" */
  //         "./components/Templates/Details"
  //       )
  //     )
  //   ]
  // },
  // Dropdown: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Dropdown" */ "./components/forms/Dropdown")
  //     )
  //   ]
  // },
  // DataExplorer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DataExplorer" */ "./components/Analytics/DataExplorer"
  //       )
  //     )
  //   ]
  // },
  // Insight: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Insight" */ "./components/Analytics/Insight"
  //       )
  //     )
  //   ]
  // },
  // Search: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Search" */ "./components/Search")
  //     )
  //   ]
  // },
  // AppAnnouncement: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "AppAnnouncement" */ "./components/Widgets/AppAnnouncement"
  //       )
  //     )
  //   ]
  // },
  // CaseHistory: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CaseHistory" */ "./components/Widgets/CaseHistory"
  //       )
  //     )
  //   ]
  // },
  // PropertyPanel: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "PropertyPanel" */
  //         "./components/Authoring/PropertyPanel"
  //       )
  //     )
  //   ]
  // },
  // EditView: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "EditView" */
  //         "./components/Authoring/EditView"
  //       )
  //     )
  //   ]
  // },
  // AddViewButton: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "AddViewButton" */
  //         "./components/Authoring/AddViewButton"
  //       )
  //     )
  //   ]
  // },
  // UIViews: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "UIViews" */
  //         "./components/Authoring/UIViews"
  //       )
  //     )
  //   ]
  // },
  // ErrorBoundary: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ErrorBoundary" */
  //         "./components/Authoring/ErrorBoundary"
  //       )
  //     )
  //   ]
  // },
  // ThemePalette: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "ThemePalette" */
  //         "./components/Authoring/ThemePalette"
  //       )
  //     )
  //   ]
  // },
  // Stages: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Stages" */ "./components/Stages")
  //     )
  //   ]
  // },
  // Location: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Location" */ "./components/forms/Location")
  //     )
  //   ]
  // },
  // Attachment: {
  //   modules: [
  //     loadable(() =>
  //       import(/* webpackChunkName: "Attachment" */ "./components/Attachment")
  //     )
  //   ]
  // },
  // FileUtility: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "FileUtility" */ "./components/Widgets/FileUtility"
  //       )
  //     )
  //   ]
  // },
  // Followers: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "Followers" */ "./components/Widgets/Followers"
  //       )
  //     )
  //   ]
  // },
  // AutoComplete: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "AutoComplete" */
  //         "./components/forms/AutoComplete"
  //       )
  //     )
  //   ]
  // },
  // FeedMessageContent: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "FeedMessageContent" */
  //         "./components/Activity/FeedMessageContent"
  //       )
  //     )
  //   ]
  // },
  // PersonaAccessContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "PersonaAccessContainer" */
  //         "./components/Authoring/PersonaAccessContainer"
  //       )
  //     )
  //   ]
  // },
  // DecisionTableContainer: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "DecisionTableContainer" */
  //         "./components/Authoring/DecisionTable"
  //       )
  //     )
  //   ]
  // },
  // UserReference: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "UserReference" */
  //         "./components/forms/UserReference"
  //       )
  //     )
  //   ]
  // },
  // CaseOperator: {
  //   modules: [
  //     loadable(() =>
  //       import(
  //         /* webpackChunkName: "CaseOperator" */
  //         "./components/Widgets/CaseOperator"
  //       )
  //     )
  //   ]
  // }
};

export const LazyMap = {};
