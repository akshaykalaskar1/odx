# The **components/custom-constellation** directory

The **src/components/custom-constellation** directory contains the code for Constellation-related _associated_ components of custom components that you create and use with the **React SDK**.
These _associated_ components are used to show the preview of the custom component in App Studio when you are authoring your application and App Studio needs to use the Constellation
design system version of your custom component.
