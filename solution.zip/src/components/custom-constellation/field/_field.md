# The **custom-constellation/field** directory

The **src/components/custom-constellation/field** directory contains the code for the Constellation-based associated component for any custom **field** component you have created for use with the **React SDK**.

For each component in the **src/components/custom-constellation/field** directory, there will be a matching component in the **src/components/custom-sdk/field** directory.
