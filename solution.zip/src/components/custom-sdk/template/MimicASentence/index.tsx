export { default } from './MimicASentence';
