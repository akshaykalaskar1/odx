export { default } from './Details';
