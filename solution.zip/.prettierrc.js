module.exports = {
  ...require('@pega/prettier-config'),
  ignore: ['package.json', 'sdk-config.json']
};