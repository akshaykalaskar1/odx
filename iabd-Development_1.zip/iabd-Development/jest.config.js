module.exports = {
  testEnvironment: 'jsdom',
  roots: ['<rootDir>/src'],
  preset: 'ts-jest',
  transform: {
    '^.+\\.(t|j)sx?$': 'ts-jest'
  },
  testMatch: ['**/?(*.)+(test).[jt]s?(x)'],
  setupFilesAfterEnv: ['<rootDir>/tests/setupTests.ts'],
  coverageDirectory: 'tests/coverage',
  transformIgnorePatterns: [
    '/node_modules/(?!hmrc-odx-features-and-functions)/' // <-- allow this module
  ],
  moduleNameMapper: { '\\.scss$': '<rootDir>/scssMock.js' },
  collectCoverageFrom: ['src/**/*.{ts,tsx,js,jsx}', '!test/**']
};
