declare const PCore: any;
declare type C11nEnv = any;

interface Window {
  PCore: any;
  C11nEnv: any;
  dataLayer: any[];
}
