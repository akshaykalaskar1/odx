import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import dayjs from 'dayjs';
import 'dayjs/locale/cy';
import setPageTitle from '../../helpers/setPageTitleHelpers';
import { WelshLanguageToggle } from 'hmrc-gds-react-components';
import { convertLanguageCodeToString } from '../../helpers/utils';

declare const PCore: any;

const LanguageToggle = () => {
  const { i18n } = useTranslation();
  let lang = sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';
  const [selectedLang, setSelectedLang] = useState(lang);

  const changeLanguage = e => {
    e.preventDefault();
    document.body.focus();
    lang = e.currentTarget.getAttribute('lang');
    setSelectedLang(lang);
    sessionStorage.setItem('rsdk_locale', `${lang}_GB`);
    dayjs.locale(lang);
    i18n.changeLanguage(lang).then(() => {
      setPageTitle();
    });
    if (typeof PCore !== 'undefined') {
      PCore.getEnvironmentInfo().setLocale(`${lang}_GB`);
      PCore.getPubSubUtils().publish('languageToggleTriggered');
    }
  };

  // Initialises language value in session storage, and for dayjs
  useEffect(() => {
    if (!sessionStorage.getItem('rsdk_locale')) {
      sessionStorage.setItem('rsdk_locale', `en_GB`);
      dayjs.locale('en');
    } else {
      const currentLang = sessionStorage.getItem('rsdk_locale').slice(0, 2).toLowerCase();
      dayjs.locale(currentLang);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = selectedLang;
  }, [selectedLang]);

  return (
    <WelshLanguageToggle 
        currentLanguage={convertLanguageCodeToString(selectedLang)}
        en={{ handleOnClick: changeLanguage }}
        cy={{ handleOnClick: changeLanguage }}
        inServiceNavigation={false}/>
  );
};

export default LanguageToggle;
