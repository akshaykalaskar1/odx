import { ReactElement, useEffect, useState } from 'react';
import LoadingSpinner, { LoadingSpinnerProps } from './LoadingSpinner';
import { useTranslation } from 'react-i18next';

interface LoadingWrapperProps {
  pageIsLoading: boolean;
  spinnerProps: LoadingSpinnerProps;
  children: ReactElement;
}

const LoadingWrapper = ({ pageIsLoading, spinnerProps, children }: LoadingWrapperProps) => {
  const [statusMessage, setStatusMessage] = useState('');
  const { t } = useTranslation();

  useEffect(() => {
    if (pageIsLoading) {
      // Brief delay to ensure the live region is in the DOM before the message is set.
      const timeout = setTimeout(() => {
        setStatusMessage(t('LOADING'));
      }, 100);
      return () => clearTimeout(timeout);
    } else {
      setStatusMessage('');
    }
  }, [pageIsLoading, t]);

  return (
    <div className='govuk-main-wrapper govuk-main-wrapper--l'>
      {/* Always in DOM so screen readers can detect changes */}
      <div
        role='status'
        aria-live='polite'
        aria-atomic='true'
        aria-relevant='additions text'
        className='govuk-visually-hidden'
      >
        {statusMessage}
      </div>

      {pageIsLoading ? <LoadingSpinner {...spinnerProps} /> : children}
    </div>
  );
};

export default LoadingWrapper;
