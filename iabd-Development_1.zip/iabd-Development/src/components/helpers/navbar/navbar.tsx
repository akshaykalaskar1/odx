import React from 'react';
import { useTranslation } from 'react-i18next';
import LanguageToggle from '../../AppComponents/LanguageToggle';

const NavBar = props => {
  const { handleSignout, handleLinkClick, hasLanguageToggle, signoutOnly = false } = props;
  const { t } = useTranslation();

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, path: string) => {
    e.preventDefault();
    handleLinkClick(path);
  };

  return (
    <div className='govuk-width-container'>
      <nav id='secondary-nav' className='govuk-link hmrc-account-menu' aria-label='Account' data-module='hmrc-account-menu'>
        {!signoutOnly && (
          <a
            href='#'
            data-tracking-type='Outbound'
            data-tracking-target='/personal-account'
            className='govuk-link hmrc-account-menu__link hmrc-account-menu__link--home'
            id='PersonalAccountLink'
            onClick={e => handleNavClick(e, '/personal-account')}
          >
            <span className='hmrc-account-icon hmrc-account-icon--home'>{t('ACCOUNT_HOME')}</span>
          </a>
        )}

        <ul className='hmrc-account-menu__main'>
          {!signoutOnly && (
            <>
              <li>
                <a
                  href='#'
                  data-tracking-type='Outbound'
                  data-tracking-target='/personal-account/messages'
                  className='govuk-link hmrc-account-menu__link'
                  id='MessagesLink'
                  onClick={e => handleNavClick(e, '/personal-account/messages')}
                >
                  {t('MESSAGES')}
                </a>
              </li>
              <li>
                <a
                  href='#'
                  className='govuk-link hmrc-account-menu__link'
                  id='TrackerLink'
                  data-tracking-type='Outbound'
                  data-tracking-target='/track'
                  onClick={e => handleNavClick(e, '/track')}
                >
                  {t('FORM_TRACKER')}
                </a>
              </li>
              <li>
                <a
                  href='#'
                  className='govuk-link hmrc-account-menu__link'
                  id='ProfileSettingsLink'
                  data-tracking-type='Outbound'
                  data-tracking-target='/personal-account/profile-and-settings'
                  onClick={e => handleNavClick(e, '/personal-account/profile-and-settings')}
                >
                  {t('PROFILE_AND_SETTINGS')}
                </a>
              </li>
            </>
          )}
          {handleSignout && (
            <li>
              <a href='#' data-tracking-type='Signout' id='signout-btn' className='govuk-link hmrc-account-menu__link' onClick={handleSignout}>
                {t('SIGN_OUT')}
              </a>
            </li>
          )}
        </ul>
      </nav>
      {hasLanguageToggle && <LanguageToggle />}
    </div>
  );
};

export default NavBar;
