import { render, screen } from '@testing-library/react';
import SecondaryText from './SecondaryText';

describe('SecondaryText', () => {
  describe('Given the SecondaryText component is rendered', () => {
    describe('When children content is provided', () => {
      it('Then the children are displayed in the paragraph element', () => {
        render(<SecondaryText>Test content</SecondaryText>);
        expect(screen.getByText('Test content')).toBeInTheDocument();
      });

      it('Then the paragraph has the correct CSS classes applied', () => {
        render(<SecondaryText>Test content</SecondaryText>);
        const paragraph = screen.getByText('Test content');
        expect(paragraph).toHaveClass('govuk-body', 'custom-secondary-text');
      });

      it('Then the content is rendered as a paragraph element', () => {
        render(<SecondaryText>Test content</SecondaryText>);
        const paragraph = screen.getByText('Test content');
        expect(paragraph.tagName).toBe('P');
      });
    });

    describe('When no children are provided', () => {
      it('Then an empty paragraph is rendered', () => {
        const { container } = render(<SecondaryText />);
        const paragraph = container.querySelector('p.govuk-body.custom-secondary-text');
        expect(paragraph).toBeInTheDocument();
        expect(paragraph).toHaveTextContent('');
      });
    });

    describe('When complex children content is provided', () => {
      it('Then the complex content is rendered correctly', () => {
        render(
          <SecondaryText>
            <span>Complex</span> content
          </SecondaryText>
        );
        expect(screen.getByText('Complex')).toBeInTheDocument();
        expect(screen.getByText(/content/)).toBeInTheDocument();
      });
    });
  });
});