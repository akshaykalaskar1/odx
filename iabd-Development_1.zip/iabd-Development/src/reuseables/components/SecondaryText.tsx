interface SecondaryTextProps {
  children?: React.ReactNode;
}

export default function SecondaryText({ children }: SecondaryTextProps) {
  return (
      <p className={'govuk-body custom-secondary-text'}>{children}</p>
  );
}
