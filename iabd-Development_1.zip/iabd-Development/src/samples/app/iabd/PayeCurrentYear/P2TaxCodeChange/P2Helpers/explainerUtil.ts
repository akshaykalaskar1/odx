import { getCurrentLang } from '../../../../../../components/helpers/utils';
import { ExplainerContent } from '../types/P2TaxCodeChangeTypes';

export const getDescription = (content?: ExplainerContent[]) => {
  const language = getCurrentLang() === 'cy' ? 'CY' : 'EN';

  return content?.find(item => item.Language === language)?.Description ?? '';
};
