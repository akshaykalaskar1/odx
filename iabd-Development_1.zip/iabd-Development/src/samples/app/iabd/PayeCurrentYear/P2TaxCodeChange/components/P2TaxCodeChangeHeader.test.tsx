import { render, screen } from '@testing-library/react';
import P2TaxCodeChangeHeader from './P2TaxCodeChangeHeader';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <h1>{children}</h1>,
  InsetText: ({ children }: any) => <div>{children}</div>
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  formatDate: jest.fn((date: string) => `formatted-${date}`)
}));

describe('P2TaxCodeChangeHeader', () => {
  describe('Given employer details exist', () => {
    describe('When the component renders', () => {
      it('Then the heading and formatted date are displayed', () => {
        render(<P2TaxCodeChangeHeader employerName='Pension Alpha' displayDate='2026-10-22' />);

        expect(screen.getByText('WE_HAVE_CHANGED_YOUR_TAX_CODE_FOR Pension Alpha')).toBeInTheDocument();

        expect(screen.getByText('formatted-2026-10-22')).toBeInTheDocument();
      });
    });
  });

  describe('Given budget coding is applicable', () => {
    describe('When the component renders', () => {
      it('Then the budget announcement message is displayed', () => {
        render(<P2TaxCodeChangeHeader employerName='Pension Alpha' displayDate='2026-10-22' budgetCodingApplicable />);

        expect(screen.getByText('YOUR_TAX_CODE_HAS_CHANGED_RECENT_BUDGET_ANNOUNCEMENT')).toBeInTheDocument();
      });
    });
  });

  describe('Given budget coding is not applicable', () => {
    describe('When the component renders', () => {
      it('Then the budget announcement message is not displayed', () => {
        render(<P2TaxCodeChangeHeader employerName='Pension Alpha' displayDate='2026-10-22' budgetCodingApplicable={false} />);

        expect(screen.queryByText('YOUR_TAX_CODE_HAS_CHANGED_RECENT_BUDGET_ANNOUNCEMENT')).not.toBeInTheDocument();
      });
    });
  });

  describe('Given display date is not provided', () => {
    describe('When the component renders', () => {
      it('Then no date is displayed', () => {
        render(<P2TaxCodeChangeHeader employerName='Pension Alpha' />);
        expect(screen.queryByText('formatted-')).not.toBeInTheDocument();
      });
    });
  });
});
