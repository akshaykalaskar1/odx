import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import LoadingWrapper from '../../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import setPageTitle from '../../../../../components/helpers/setPageTitleHelpers';
import i18next from 'i18next';

import ErrorMessage from '../../ErrorPage/errorMessage';

import P2StrategicPage from './components/P2TaxCodeChangePage';

interface P2TaxCodeChangeExplainerProps {
  redirectCurrentYearPage: () => void;
  redirecLatestEventPage: (s: string) => void;
  redirectToViewTimelineDetailsPage: () => void;
  taxCodeIdentifier: string;
  eventType: string;
}

export default function P2TaxCodeChangeExplainer({ taxCodeIdentifier, eventType, redirectToViewTimelineDetailsPage }: P2TaxCodeChangeExplainerProps) {
  const { t } = useTranslation();

  const [isPageLoading, setIsPageLoading] = useState(true);

  const [fetchedData, setFetchedData] = useState(null);

  const [errorMsgArr, setErrorMsgArr] = useState<string[]>([]);

  const [hasFetched, setHasFetched] = useState(false);

  useEffect(() => {
    setPageTitle();
  }, [i18next.language]);

  useEffect(() => {
    if (hasFetched) return;

    setHasFetched(true);
    setIsPageLoading(true);
    setErrorMsgArr([]);
    setFetchedData(null);

    const parameters = {
      taxCodeIdentifier: taxCodeIdentifier
    };

    const fetchData = async () => {
      try {
        const response = await PCore.getDataPageUtils().getDataAsync(
          'D_P2Digital',
          'root',
          parameters,
          {},
          {},
          {
            invalidateCache: true
          }
        );

        const data = response?.data?.[0];

        const errorMsg = data?.pyErrors?.pyMessages?.[0]?.pyErrorMessage;

        if (Array.isArray(errorMsg) && errorMsg.length > 0) {
          setErrorMsgArr(errorMsg);
          return;
        }

        const taxSummary = data?.Customer?.TaxSummaryList?.[0] ?? null;

        setFetchedData(taxSummary);
      } catch {
        setErrorMsgArr(['ERROR']);

        console.log('Error: D_P2TaxCodeChange failed');
      } finally {
        setIsPageLoading(false);
      }
    };

    fetchData();
  }, [hasFetched]);

  return (
    <LoadingWrapper
      pageIsLoading={isPageLoading}
      spinnerProps={{
        bottomText: t('LOADING'),
        size: '30px',
        label: t('LOADING')
      }}
    >
      {errorMsgArr.length > 0 ? (
        <ErrorMessage />
      ) : (
        <P2StrategicPage
          explainerData={fetchedData}
          pageName={fetchedData?.pyTemplateDataField}
          eventType={eventType}
          redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
        />
      )}
    </LoadingWrapper>
  );
}
