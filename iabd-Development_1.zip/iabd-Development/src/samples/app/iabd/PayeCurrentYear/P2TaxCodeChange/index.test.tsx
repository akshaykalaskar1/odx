import { render, screen, waitFor } from '@testing-library/react';
import P2TaxCodeChangeExplainer from './index';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../components/helpers/setPageTitleHelpers', () => jest.fn());

jest.mock('../../ErrorPage/errorMessage', () => ({
  __esModule: true,
  default: () => <div>ErrorMessage</div>
}));

jest.mock('./components/P2TaxCodeChangePage', () => ({
  __esModule: true,
  default: (props: any) => (
    <div>
      TaxCodeChangePage
      <div>{JSON.stringify(props)}</div>
    </div>
  )
}));

jest.mock('../../../../../components/helpers/LoadingSpinner/LoadingWrapper', () => ({
  __esModule: true,
  default: ({ children }: any) => <>{children}</>
}));

describe('P2TaxCodeChangeExplainer', () => {
  const getDataAsync = jest.fn();

  const timelineDetails = {
    IntegerSortingHolder: 123
  };

  beforeEach(() => {
    jest.clearAllMocks();

    (globalThis as any).PCore = {
      getDataPageUtils: () => ({
        getDataAsync
      })
    };
  });

  describe('Given D_P2Digital returns valid data', () => {
    describe('When the component loads', () => {
      it('Then tax code change explainer page is displayed', async () => {
        getDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [
                  {
                    pyTemplateDataField: 'P2'
                  }
                ]
              }
            }
          ]
        });

        render(
          <P2TaxCodeChangeExplainer
            taxCodeIdentifier='123'
            eventType='LatestEvent'
            redirectCurrentYearPage={jest.fn()}
            redirecLatestEventPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
          />
        );

        await waitFor(() => {
          expect(screen.getByText('TaxCodeChangePage')).toBeInTheDocument();
        });
      });
    });
  });

  describe('Given D_P2Digital returns pega errors', () => {
    describe('When the component loads', () => {
      it('Then error message is displayed', async () => {
        getDataAsync.mockResolvedValue({
          data: [
            {
              pyErrors: {
                pyMessages: [
                  {
                    pyErrorMessage: ['ERROR']
                  }
                ]
              }
            }
          ]
        });

        render(
          <P2TaxCodeChangeExplainer
            taxCodeIdentifier='123'
            eventType='LatestEvent'
            redirectCurrentYearPage={jest.fn()}
            redirecLatestEventPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
          />
        );

        await waitFor(() => {
          expect(screen.getByText('ErrorMessage')).toBeInTheDocument();
        });
      });
    });
  });

  describe('Given D_P2Digital throws an exception', () => {
    describe('When the component loads', () => {
      it('Then error message is displayed', async () => {
        getDataAsync.mockRejectedValue(new Error('failure'));

        render(
          <P2TaxCodeChangeExplainer
            taxCodeIdentifier='123'
            eventType='LatestEvent'
            redirectCurrentYearPage={jest.fn()}
            redirecLatestEventPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
          />
        );

        await waitFor(() => {
          expect(screen.getByText('ErrorMessage')).toBeInTheDocument();
        });
      });
    });
  });

  describe('Given timeline details contain a tax code identifier', () => {
    describe('When data is requested', () => {
      it('Then D_P2Digital is called with the correct parameters', async () => {
        getDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [{}]
              }
            }
          ]
        });

        render(
          <P2TaxCodeChangeExplainer
            taxCodeIdentifier='123'
            eventType='LatestEvent'
            redirectCurrentYearPage={jest.fn()}
            redirecLatestEventPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
          />
        );

        await waitFor(() => {
          expect(getDataAsync).toHaveBeenCalled();
        });

        expect(getDataAsync).toHaveBeenCalledWith(
          'D_P2Digital',
          'root',
          {
            taxCodeIdentifier: '123'
          },
          {},
          {},
          {
            invalidateCache: true
          }
        );
      });
    });
  });
});
