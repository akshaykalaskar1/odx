import { render, screen } from '@testing-library/react';
import P2TaxCodeChangeFooter from './P2TaxCodeChangeFooter';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <h2>{children}</h2>
}));

describe('P2TaxCodeChangeFooter', () => {
  describe('Given the footer is rendered', () => {
    describe('When the component loads', () => {
      it('Then the What happens next heading is displayed', () => {
        render(<P2TaxCodeChangeFooter />);
        expect(screen.getByText('WHAT_HAPPENS_NEXT')).toBeInTheDocument();
      });

      it('Then the informational body content is displayed', () => {
        render(<P2TaxCodeChangeFooter />);

        expect(screen.getByText('THIS_IS_FOR_INFO_ONLY_NOT_DO_ANYTHING_UNLESS_CHANGED')).toBeInTheDocument();
      });
    });
  });
});
