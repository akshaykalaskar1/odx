export interface ExplainerContent {
  Language: string;
  Description: string;
}

export interface ExplainerSection {
  Content: ExplainerContent[];
}

export interface TaxDetail {
  DisplayDate: string;
  EmployerName: string;
  issuedtaxCode?: string;
  NetCodedAllowance?: string;
  EmploymentType?: string;
  isBudgetCodingApplicable?: boolean;
  ActiveOccupationalPension?: boolean;
  EmploymentSequenceNumber?: number;
  taxCodeIdentifier?: number;
}

export interface P2TaxCodeChangeData {
  WhyExplainer?: ExplainerSection[];
  WhatExplainer?: ExplainerSection[];
  HowExplainer?: ExplainerSection[];
  TaxDetails?: TaxDetail[];
  pyTemplateDataField?: string;
}
