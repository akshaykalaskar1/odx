import { useTranslation } from 'react-i18next';
import { Heading, InsetText } from 'hmrc-gds-react-components';
import { formatDate } from '../../../../../../components/helpers/utils';
import SecondaryText from '../../../../../../reuseables/components/SecondaryText';


interface P2TaxCodeChangeHeaderProps {
  employerName?: string;
  displayDate?: string;
  budgetCodingApplicable?: boolean;
}

export default function P2TaxCodeChangeHeader({ employerName, displayDate, budgetCodingApplicable }: P2TaxCodeChangeHeaderProps) {
  const { t } = useTranslation();

  return (
    <>
      <Heading headingLevel={1} className='govuk-heading-l govuk-!-margin-bottom-2'>
        {t('WE_HAVE_CHANGED_YOUR_TAX_CODE_FOR')} {employerName}
      </Heading>
      {budgetCodingApplicable && <InsetText>{t('YOUR_TAX_CODE_HAS_CHANGED_RECENT_BUDGET_ANNOUNCEMENT')}</InsetText>}
      {displayDate && <SecondaryText>{formatDate(displayDate)}</SecondaryText>}
    </>
  );
}
