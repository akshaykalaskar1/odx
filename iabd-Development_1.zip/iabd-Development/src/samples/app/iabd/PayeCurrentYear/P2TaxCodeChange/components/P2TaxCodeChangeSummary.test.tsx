import { render, screen, fireEvent } from '@testing-library/react';
import P2TaxCodeChangeSummary from './P2TaxCodeChangeSummary';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../P2Helpers/explainerUtil', () => ({
  getDescription: jest.fn(content => content)
}));

jest.mock('react-markdown', () => ({
  __esModule: true,
  default: ({ children, components }: any) => {
    const Link = components.a;

    if (typeof children === 'string' && children.includes('/paye/summary/account-activity-details')) {
      return <Link href='/paye/summary/account-activity-details'>Check how we worked out your new code and tax-free amount.</Link>;
    }

    return <>{children}</>;
  }
}));

jest.mock('hmrc-gds-react-components', () => ({
  SummaryList: ({ children }: any) => <div>{children}</div>,
  SummaryListRow: ({ label, value }: any) => (
    <div>
      <div>{label}</div>
      <div>{value}</div>
    </div>
  )
}));

jest.mock('../../../../../AppSelector/payeRoutes', () => ({
  __esModule: true,
  default: {
    RESTRICTED_REDIRECTION: {
      VIEW_TIMELINE_DETAILS: '/paye/summary/account-activity-details'
    }
  }
}));

describe('P2TaxCodeChangeSummary', () => {
  const redirectToViewTimelineDetailsPage = jest.fn();

  const timelineDetails = {
    pyTemplateDataField: 'P2'
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Given explainer content exists', () => {
    describe('When the component renders', () => {
      it('Then all summary rows are displayed', () => {
        render(
          <P2TaxCodeChangeSummary
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
            eventType='event'
            explainerData={
              {
                WhyExplainer: [
                  {
                    Content: 'Why Content'
                  }
                ],
                WhatExplainer: [
                  {
                    Content: 'What Content'
                  }
                ],
                HowExplainer: [
                  {
                    Content: 'How Content'
                  }
                ]
              } as any
            }
          />
        );

        expect(screen.getByText('WHY_IT_CHANGED')).toBeInTheDocument();
        expect(screen.getByText('WHAT_THIS_MEANS_FOR_YOU')).toBeInTheDocument();
        expect(screen.getByText('HOW_WE_WILL_COLLECT_IT')).toBeInTheDocument();
      });
    });
  });

  describe('Given how explainer content is not available', () => {
    describe('When the component renders', () => {
      it('Then How we will collect it row is not displayed', () => {
        render(
          <P2TaxCodeChangeSummary
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
            eventType='event'
            explainerData={
              {
                WhyExplainer: [{ Content: 'Why Content' }],
                WhatExplainer: [{ Content: 'What Content' }]
              } as any
            }
          />
        );

        expect(screen.queryByText('HOW_WE_WILL_COLLECT_IT')).not.toBeInTheDocument();
      });
    });
  });

  describe('Given the WIMTC markdown link exists', () => {
    describe('When the user clicks the link', () => {
      it('Then redirectToViewTimelineDetailsPage is called with the mapped timeline event', () => {
        const redirectToViewTimelineDetailsPage = jest.fn();

        render(
          <P2TaxCodeChangeSummary
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
            eventType='LatestEvent'
            explainerData={
              {
                TaxDetails: [
                  {
                    DisplayDate: '2026-12-22',
                    EmployerName: 'Pension Alpha',
                    EmploymentType: 'PRIMARY',
                    ActiveOccupationalPension: true,
                    EmploymentSequenceNumber: 7,
                    taxCodeIdentifier: 2,
                    NetCodedAllowance: '12570',
                    issuedtaxCode: '1250L'
                  }
                ],
                WhyExplainer: [
                  {
                    Content: '/paye/summary/account-activity-details'
                  }
                ],
                WhatExplainer: []
              } as any
            }
          />
        );

        fireEvent.click(
          screen.getAllByRole('link', {
            name: 'Check how we worked out your new code and tax-free amount.'
          })[0]
        );

        expect(redirectToViewTimelineDetailsPage).toHaveBeenCalledWith(
          '',
          expect.objectContaining({
            DisplayDate: '2026-12-22',
            EmployerName: 'Pension Alpha',
            EmploymentType: 'PRIMARY',
            ActiveOccupationalPension: true,
            EmploymentSequenceNumber: 7,
            IntegerSortingHolder: 2,
            NetCodedAllowance: '12570',
            issuedtaxCode: '1250L',
            pyTemplateDataField: 'TAXCODE'
          }),
          'LatestEvent'
        );
      });
    });
  });
});
