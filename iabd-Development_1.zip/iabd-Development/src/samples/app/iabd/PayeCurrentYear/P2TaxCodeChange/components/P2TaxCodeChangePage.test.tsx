import { render, screen, fireEvent } from '@testing-library/react';
import P2StrategicPage from './P2TaxCodeChangePage';
import { mockNavigate } from '../../../../../../../tests/mocks/routerMocks';
import P2TaxCodeChangePage from './P2TaxCodeChangePage';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  withPageTracking: (Comp: any) => Comp
}));

jest.mock('../../../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ onClick }: any) => <button onClick={onClick}>Back</button>
}));

jest.mock('../../../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children, title }: any) => (
    <>
      <div>{title}</div>
      {children}
    </>
  )
}));

jest.mock('./P2TaxCodeChangeHeader', () => ({
  __esModule: true,
  default: (props: any) => <div>{JSON.stringify(props)}</div>
}));

jest.mock('./P2TaxCodeChangeSummary', () => ({
  __esModule: true,
  default: (props: any) => <div>{JSON.stringify(props)}</div>
}));

jest.mock('./P2TaxCodeChangeFooter', () => ({
  __esModule: true,
  default: () => <div>Footer</div>
}));

describe('P2TaxCodeChangePage', () => {
  const redirectToViewTimelineDetailsPage = jest.fn();

  const explainerData = {
    TaxDetails: [
      {
        EmployerName: 'Pension Alpha',
        DisplayDate: '2026-12-22',
        isBudgetCodingApplicable: true
      }
    ]
  } as any;

  const timelineDetails = {
    pyTemplateDataField: 'P2'
  } as any;

  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('Given valid explainer data exists', () => {
    describe('When the component renders', () => {
      it('Then header, summary and footer are displayed', () => {
        render(
          <P2TaxCodeChangePage
            explainerData={explainerData}
            eventType='LatestEvent'
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
          />
        );

        expect(screen.getByText('Footer')).toBeInTheDocument();

        expect(screen.getByText(/"budgetCodingApplicable":true/)).toBeInTheDocument();

        expect(screen.getByText(/"eventType":"LatestEvent"/)).toBeInTheDocument();
      });

      it('Then the page title is constructed correctly', () => {
        render(
          <P2TaxCodeChangePage
            explainerData={explainerData}
            eventType='LatestEvent'
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
          />
        );

        expect(screen.getByText('WE_HAVE_CHANGED_YOUR_TAX_CODE_FOR Pension Alpha')).toBeInTheDocument();
      });

      it('Then the correct props are passed to the header', () => {
        render(
          <P2TaxCodeChangePage
            explainerData={explainerData}
            eventType='LatestEvent'
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
          />
        );

        expect(screen.getByText(/"employerName":"Pension Alpha"/)).toBeInTheDocument();

        expect(screen.getByText(/"displayDate":"2026-12-22"/)).toBeInTheDocument();
      });
    });
  });

  describe('Given the user clicks back', () => {
    describe('When the backlink is selected', () => {
      it('Then navigation returns to the previous page', () => {
        render(
          <P2TaxCodeChangePage
            explainerData={explainerData}
            eventType='LatestEvent'
            redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
          />
        );

        fireEvent.click(screen.getByText('Back'));

        expect(mockNavigate).toHaveBeenCalledWith(-1);
      });
    });
  });
});
