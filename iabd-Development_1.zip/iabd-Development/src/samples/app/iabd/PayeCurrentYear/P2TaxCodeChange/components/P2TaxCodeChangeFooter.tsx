import { useTranslation } from 'react-i18next';
import { Heading } from 'hmrc-gds-react-components';

export default function P2TaxCodeChangeFooter() {
  const { t } = useTranslation();

  return (
    <>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('WHAT_HAPPENS_NEXT')}
      </Heading>

      <p className='govuk-body'>{t('THIS_IS_FOR_INFO_ONLY_NOT_DO_ANYTHING_UNLESS_CHANGED')}</p>
    </>
  );
}
