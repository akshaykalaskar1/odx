import { SummaryList, SummaryListRow } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import ReactMarkdown from 'react-markdown';
import { TimeLineEvent } from '../../../../../../reuseables/Types/TimeLineEvents';
import PAYE_ROUTES from '../../../../../AppSelector/payeRoutes';

import { P2TaxCodeChangeData } from '../types/P2TaxCodeChangeTypes';
import { getDescription } from '../P2Helpers/explainerUtil';

interface Props {
  explainerData?: P2TaxCodeChangeData;
  eventType?: string;
  redirectToViewTimelineDetailsPage: (fromPage?: string, wimtcTimelineEvent?: TimeLineEvent, eventType?: string) => void;
}

interface SummaryRow {
  key: string;
  value: string;
}

export default function P2TaxCodeChangeSummary({ explainerData, eventType, redirectToViewTimelineDetailsPage }: Props) {
  const { t } = useTranslation();
  const taxDetails = explainerData?.TaxDetails?.[0];

  const wimtcTimelineEvent = {
    DisplayDate: taxDetails?.DisplayDate,
    EmployerName: taxDetails?.EmployerName,
    EmploymentType: taxDetails?.EmploymentType,
    ActiveOccupationalPension: taxDetails?.ActiveOccupationalPension,
    EmploymentSequenceNumber: taxDetails?.EmploymentSequenceNumber,
    IntegerSortingHolder: taxDetails?.taxCodeIdentifier,
    NetCodedAllowance: taxDetails?.NetCodedAllowance,
    issuedtaxCode: taxDetails?.issuedtaxCode,
    pyTemplateDataField: 'TAXCODE'
  } as TimeLineEvent;

  const summaryRows: SummaryRow[] = [
    {
      key: 'WHY_IT_CHANGED',
      value: getDescription(explainerData?.WhyExplainer?.[0]?.Content)
    },
    {
      key: 'WHAT_THIS_MEANS_FOR_YOU',
      value: getDescription(explainerData?.WhatExplainer?.[0]?.Content)
    }
  ];

  const howExplainerDescription = getDescription(explainerData?.HowExplainer?.[0]?.Content);

  if (howExplainerDescription) {
    summaryRows.push({
      key: 'HOW_WE_WILL_COLLECT_IT',
      value: howExplainerDescription
    });
  }

  const onWIMTCLinkClick = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, href?: string) => {
    e.preventDefault();
    e.stopPropagation();

    if (href === PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS) {
      redirectToViewTimelineDetailsPage('', wimtcTimelineEvent, eventType);
    }
  };

  return (
    <SummaryList>
      {summaryRows.map(({ key, value }) => (
        <SummaryListRow
          key={key}
          label={t(key)}
          value={
            <ReactMarkdown
              components={{
                ol: ({ children }) => <ol className='govuk-list govuk-list--number govuk-list--spaced'>{children}</ol>,
                p: ({ children }) => <p className='govuk-body'>{children}</p>,
                a: ({ href, children }) => {
                  return (
                    <a href={href} className='govuk-link' onClick={e => onWIMTCLinkClick(e, href)}>
                      {children}
                    </a>
                  );
                }
              }}
            >
              {value}
            </ReactMarkdown>
          }
        />
      ))}
    </SummaryList>
  );
}
