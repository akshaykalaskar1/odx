import Button from '../../../../../../components/BaseComponents/Button/Button';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { P2TaxCodeChangeData } from '../types/P2TaxCodeChangeTypes';
import MainWrapperFull from '../../../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { TimeLineEvent } from '../../../../../../reuseables/Types/TimeLineEvents';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import P2TaxCodeChangeHeader from './P2TaxCodeChangeHeader';
import P2TaxCodeChangeSummary from './P2TaxCodeChangeSummary';
import P2TaxCodeChangeFooter from './P2TaxCodeChangeFooter';

interface Props {
  explainerData?: P2TaxCodeChangeData;
  pageName?: string;
  eventType?: string;
  redirectToViewTimelineDetailsPage: (fromPage?: string, timelineDetails?: TimeLineEvent, eventType?: string) => void;
}

const P2TaxCodeChangePage = ({ explainerData, eventType, redirectToViewTimelineDetailsPage }: Props) => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const taxDetails = explainerData?.TaxDetails?.[0];

  const onBackButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    navigate(-1);
  };

  return (
    <>
      <Button variant='backlink' attributes={{ type: 'link' }} onClick={onBackButtonClick} />

      <MainWrapperFull title={`${t('WE_HAVE_CHANGED_YOUR_TAX_CODE_FOR', { lng: 'en' })} ${taxDetails?.EmployerName}`}>
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-two-thirds'>
            <P2TaxCodeChangeHeader
              employerName={taxDetails?.EmployerName}
              displayDate={taxDetails?.DisplayDate}
              budgetCodingApplicable={taxDetails?.isBudgetCodingApplicable}
            />

            <P2TaxCodeChangeSummary
              explainerData={explainerData}
              eventType={eventType}
              redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
            />

            <P2TaxCodeChangeFooter />
          </div>
        </div>
      </MainWrapperFull>
    </>
  );
};

export default withPageTracking(P2TaxCodeChangePage);
