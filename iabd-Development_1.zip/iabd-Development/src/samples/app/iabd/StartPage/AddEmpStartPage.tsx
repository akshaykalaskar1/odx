import React, { useEffect } from 'react';
import Button from '../../../../components/BaseComponents/Button/Button';
import { StartButton as GDSStartButton } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import MainWrapperFull from '../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import { useNavigate } from 'react-router-dom';
import PAYE_ROUTES from '../../../AppSelector/payeRoutes';

const AddEmpStartPage: React.FC<{
  dynamicEmpPayPeriod: any;
}> = ({ dynamicEmpPayPeriod }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const handleStart = e => {
    e.preventDefault();

    navigate(PAYE_ROUTES.ADD_MISSING_EMPLOYMENT, {
      state: {
        caseType: 'HMRC-PAYE-Work-IABD-MissingEmp',
        redirectPath: PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_EMPLOYMENT
      }
    });
  };

  useEffect(() => {
    setPageTitle();
  }, []);

  return (
    <>
      <Button
        variant='backlink'
        onClick={e => {
          e.preventDefault();
          navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.SUMMARY);
        }}
        key='StartPageBacklink'
        attributes={{ type: 'link' }}
      />
      <MainWrapperFull title={t('TELL_US_ABOUT_A_MISSING_EMPLOYMENT', { lng: 'en' })}>
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-two-thirds'>
            <h1 className='govuk-heading-l'>{t('TELL_US_ABOUT_A_MISSING_EMPLOYMENT')}</h1>
            <p className='govuk-body'>{t('USE_THIS_SERVICE_TO_TELL')}</p>

            <p className='govuk-body'>
              {t('DONOT_USE_THIS_SERVICE_IF')} {dynamicEmpPayPeriod}
              {t('DAYS_SINCE_YOU_RECEIVED_YOUR_FIRST_PAYMENT')}
            </p>

            <h2 className='govuk-heading-m'>{t('BEFORE_YOU_START')}</h2>
            <p className='govuk-body'>{t('YOU_WILL_NEED_TO_PROVIDE_US')}</p>

            <ul className='govuk-list govuk-list--bullet govuk-!-margin-bottom-6'>
              <li>{t('NAME_OF_YOUR_EMPLOYER')}</li>
              <li>{t('DATE_YOU_STARTED')}</li>
              <li>{t('DATE_YOU_RECEIVED_YOUR_FIRST_PAYMENT')}</li>
            </ul>
            <p className='govuk-body'>{t('PROVIDE_DETAILS_FROM_YOUR_PAYSLIP')}</p>
            <ul className='govuk-list govuk-list--bullet govuk-!-margin-bottom-6'>
              <li>{t('EMPLOYERS_PAYE_REFERENCE')}</li>
              <li>{t('PAYROLL_NUMBER_IF_YOU_KNOW_IT')}</li>
            </ul>
            <GDSStartButton href='#' onClick={handleStart} text={t('START_NOW')} />
          </div>
        </div>
      </MainWrapperFull>
    </>
  );
};

export default withPageTracking(AddEmpStartPage);
