import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import AppHeader from '../../../../components/AppComponents/AppHeader';
import MainWrapperFull from '../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import AppFooter from '../../../../components/AppComponents/AppFooter';
import useHMRCExternalLinks from '../../../../components/helpers/hooks/HMRCExternalLinks';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import LanguageToggle from '../../../../components/AppComponents/LanguageToggle';

const NoP45PensionInfo = () => {
  const { t } = useTranslation();
  const { referrerURL } = useHMRCExternalLinks();

  useEffect(() => {
    setPageTitle();
  }, [t]);

  return (
    <>
      <AppHeader />

      <div className='govuk-width-container'>
        <LanguageToggle />
        <MainWrapperFull title={t('MY_P45_DOES_NOT_HAVE_THE_INFORMATION', { lng: 'en' })}>
          <div className='govuk-grid-row'>
            <div className='govuk-grid-column-two-thirds'>
              <h1 className='govuk-heading-l'>{t('MY_P45_DOES_NOT_HAVE_THE_INFORMATION')}</h1>

              <p className='govuk-body'>
                {t('IF_THE_INFORMATION_WE_ASKED_FOR_IS_NOT_SHOWING')}
                {t('WE_NEED_CERTAIN_DETAILS_FROM_YOUR_P45_PENSION')}
              </p>

              <p className='govuk-body'>{t('YOU_CAN_CONTACT_YOUR_PENSION_TO_GET_AN_UPDATED')}</p>

              <p className='govuk-body'>
                {t('IF_YOU_HAVE_LOST_CONTACT_WITH_YOUR_PENSION')}
                {t('WE_WILL_THEN_UPDATE_YOUR_PENSION_FOR_YOU')}
              </p>

              <p className='govuk-body'>
                <a className='govuk-link' href={`${referrerURL}`}>
                  {t('RETURN_TO_PAYE_INCOME_TAX_SUMMARY')}
                </a>
                .
              </p>
            </div>
          </div>
        </MainWrapperFull>
      </div>
      <AppFooter />
    </>
  );
};

export default NoP45PensionInfo;
