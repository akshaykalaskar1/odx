import checkAuthAndRedirectByActionType from './checkAuthAndRedirectByActionType';
import { getSdkConfig, logout } from '@pega/auth/lib/sdk-auth-manager';
import { appendLangParam } from '../../../../components/helpers/utils';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn(),
  logout: jest.fn()
}));

jest.mock('../../../../components/helpers/utils', () => ({
  appendLangParam: jest.fn()
}));

describe('Feature: Authentication Action Type Check', () => {
  const mockGetPageDataAsync = jest.fn();
  const mockRedirect = jest.fn();

  const currentPageURL = 'www.currentPageUrl.com';

  beforeEach(() => {
    // Mocking PCore.getDataPageUtils().getPageDataAsync
    (window as any).PCore = {
      getDataPageUtils: jest.fn(() => ({
        getPageDataAsync: mockGetPageDataAsync
      }))
    };

    // Mocking window.location.replace
    Object.defineProperty(window, 'location', {
      value: { replace: mockRedirect, href: currentPageURL },
      writable: true
    });

    (getSdkConfig as jest.Mock).mockResolvedValue({
      serverConfig: {
        sdkHmrcQAURL: 'https://www.qa.tax.service.gov.uk/'
      }
    });

    (appendLangParam as jest.Mock).mockImplementation((url: string) => `${url}&lang=en`);
  });

  afterEach(() => {
    jest.clearAllMocks(); // Clear mocks after each test
  });

  describe('Scenario: TENS Authentication Required', () => {
    it('should handle TENS authentication flow', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false,
        PostAuthAction: 'TENS'
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(appendLangParam).toHaveBeenCalledWith(`https://www.qa.tax.service.gov.uk/protect-tax-info?redirectUrl=${currentPageURL}`);
      expect(mockRedirect).toHaveBeenCalledWith(`https://www.qa.tax.service.gov.uk/protect-tax-info?redirectUrl=${currentPageURL}&lang=en`);
      expect(getSdkConfig).toHaveBeenCalled();
      expect(logout).toHaveBeenCalled();
      expect(result).toBe('TENS');
    });
  });

  describe('Scenario: ROLE Authentication Required', () => {
    it('should handle ROLE authentication flow', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false,
        PostAuthAction: 'ROLE'
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBe('ROLE');
    });
  });

  describe('Scenario: Other Authentication Action', () => {
    it('should handle other authentication actions', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false,
        PostAuthAction: 'Other'
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBe('Other');
    });
  });

  describe('Scenario: Empty PostAuthAction', () => {
    it('should handle empty string PostAuthAction', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false,
        PostAuthAction: ''
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });
  });

  describe('Scenario: Null/Undefined PostAuthAction', () => {
    it('should handle undefined PostAuthAction', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });

    it('should handle null PostAuthAction', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: false,
        PostAuthAction: null
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });
  });

  describe('Scenario: Normal Authentication', () => {
    it('should handle normal authentication', async () => {
      // Given
      mockGetPageDataAsync.mockResolvedValue({
        IsNormalAuthentication: true
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });
  });

  describe('Scenario: Error in Data Page', () => {
    it('should handle data page errors', async () => {
      // Given
      mockGetPageDataAsync.mockRejectedValue({
        Error: true
      });

      // When
      const result = await checkAuthAndRedirectByActionType();

      // Then
      expect(mockRedirect).not.toHaveBeenCalled();
      expect(logout).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });
  });
});
