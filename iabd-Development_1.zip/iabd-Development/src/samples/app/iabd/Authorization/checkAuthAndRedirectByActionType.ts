/**
 * @packageDocumentation
 *
 * Utilities to determine post-authentication action types and perform
 * any necessary redirects. These helpers read the `D_PostCitizenAuthAction`
 * data page via PCore and handle logout/redirect flows for special action types.
 */

import { getSdkConfig, logout } from '@pega/auth/lib/sdk-auth-manager';
import { appendLangParam } from '../../../../components/helpers/utils';

/**
 * Response interface for the PostCitizenAuthAction data page
 * @interface DataPageResponse
 */
interface DataPageResponse {
  /** Indicates if normal authentication is required */
  IsNormalAuthentication: boolean;
  /** Type of post-authentication action required */
  PostAuthAction?: string;
}

/**
 * Retrieves the authentication action type from the data page
 * @returns {Promise<string | null>} The authentication action type or null if normal authentication
 * @throws {Error} When data page request fails
 */
const getAuthActionType = async (): Promise<string | null> => {
  const dataPage: Promise<DataPageResponse> = PCore.getDataPageUtils().getPageDataAsync(
    'D_PostCitizenAuthAction',
    'root'
  ) as Promise<DataPageResponse>;
  try {
    const dataResponse: DataPageResponse = await dataPage;
    if (!dataResponse?.IsNormalAuthentication && typeof dataResponse?.PostAuthAction === 'string' && dataResponse.PostAuthAction.length > 0) {
      return dataResponse.PostAuthAction;
    }
    return null;
  } catch (error) {
    console.error('Error fetching authentication action type:', error);
    return null;
  }
};

/**
 * Checks authentication type and performs appropriate redirect action
 *
 * Behavior:
 * - If the action type is `null`, nothing is performed and `null` is returned.
 * - If an action type exists, the user is logged out via `logout()`.
 *   - If the action type (case-insensitive) is `'TENS'`, the user is redirected to
 *     the GOV.UK protect-tax-info page with a redirectUrl back to the current page.
 *   - For other action types, the function returns the action type (after logout)
 *     so callers can handle any further logic.
 *
 * @returns {Promise<string | null>} The action type returned when applicable, or null
 */
async function checkAuthAndRedirectByActionType(): Promise<string | null> {
  const actionType = await getAuthActionType();
  if (actionType !== null) {
    if (actionType?.toUpperCase() !== 'TENS') {
      return actionType;
    }
    await logout();
    const {
      serverConfig: { sdkHmrcQAURL: hmrcQAURL }
    } = await getSdkConfig();
    const currentPage: string = window.location.href;
    window.location.replace(appendLangParam(`${hmrcQAURL}protect-tax-info?redirectUrl=${currentPage}`));
  }
  return actionType;
}

export default checkAuthAndRedirectByActionType;
