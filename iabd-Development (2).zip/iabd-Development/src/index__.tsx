// from react_root.js
import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import TopLevelApp from '../src/samples/TopLevelApp';

const outletElement = document.getElementById('outlet');
const root = createRoot(outletElement);

if (outletElement) {
  root.render(
    <BrowserRouter>
      <TopLevelApp />
    </BrowserRouter>,
  );
}
