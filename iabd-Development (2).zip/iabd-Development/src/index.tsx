// from react_root.js
import React from 'react';
import { createRoot } from 'react-dom/client';
import TopLevelApp from './samples/TopLevelApp';
import '../assets/css/appStyles.scss';

const outletElement = document.getElementById('outlet');
const root = createRoot(outletElement);

if (outletElement) {
  root.render(<TopLevelApp />);
}
