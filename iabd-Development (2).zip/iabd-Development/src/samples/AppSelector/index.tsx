import { Navigate, Route, Routes } from 'react-router-dom';
import Iabd from '../app/iabd/index';
import CookiePage from '../app/iabd/cookiePage/index';
import Accessibility from '../app/iabd/AccessibilityPage';
import ErrorMessage from '../app/iabd/ErrorPage/errorMessage';
import NoP45InfoPage from '../app/iabd/NoP45InfoPage/NoP45InfoPage';
import ProtectedRoute from '../../components/HOC/ProtectedRoute';
import NoP45PensionInfo from '../app/iabd/NoP45InfoPage/NoP45PensionInfo';
import SignoutConfirmationPage from '../../components/AppComponents/Signout';
import {
  ViewTimelineDetailsRoute,
  DetailExplainerRoute,
  UnderstandYourTaxRoute,
  UnderstandYourTaxSpecialRoute,
  WinterFuelPaymentRoute,
  UntaxedSavingsInterestRoute,
  WinterFuelPaymentChargeRoute,
  InterruptionRoute,
  UpdateEstimatedTaxableIncomeRoute,
  AddEmploymentRoute,
  AddPensionRoute,
  AnnualCodingRoute,
  LatestEventsRoute,
  OtherIncomeRoute,
  PayeLandingRoute,
  PayeSummaryRoute,
  UpdateEmploymentRoute,
  UpdatePensionRoute,
  ViewAllDetailsRoute,
  P2ExplainerRoute,
  PegaCaseInitiatedRoute,
  SummaryPageRoute,
  AboutUntaxedSavingsInterestRoute
} from './payeRoutesWrapper';
import PAYE_ROUTES from './payeRoutes';
import useRouteInvalidRequestHandler from '../../components/helpers/hooks/useRouteInvalidRequestHandler';
import useInitI18n from '../../components/helpers/hooks/useInitI18n';
import ShutterServicePage from '../../components/AppComponents/ShutterService/ShutterServicePage';
import MCI from '../app/iabd/Authorization/MCI';

const AppSelector = () => {
  useRouteInvalidRequestHandler();
  const i18nLoaded = useInitI18n();

  if (!i18nLoaded) return null;

  return (
    <Routes>
      <Route path='/' element={<Navigate to={PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING} replace />} />

      <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING} element={<ProtectedRoute component={Iabd} />}>
        <Route index element={<PayeLandingRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.SUMMARY} element={<PayeSummaryRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.OTHER_INCOME_ALLOWANCES} element={<OtherIncomeRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.LATEST_EVENTS} element={<LatestEventsRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_ALL_DETAILS} element={<ViewAllDetailsRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS} element={<ViewTimelineDetailsRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.P2_EXPLAINER} element={<P2ExplainerRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.DETAIL_EXPLAINER} element={<DetailExplainerRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.UNDERSTAND_YOUR_TAX} element={<UnderstandYourTaxRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.UNDERSTAND_YOUR_TAX_SPECIAL} element={<UnderstandYourTaxSpecialRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.ANNUAL_CODING} element={<AnnualCodingRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.WINTER_FUEL_PAYMENT} element={<WinterFuelPaymentRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.UNTAXED_SAVINGS_INTEREST} element={<UntaxedSavingsInterestRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.ABOUT_UNTAXED_SAVINGS_INTEREST} element={<AboutUntaxedSavingsInterestRoute />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.WINTER_FUEL_PAYMENT_CHARGE} element={<WinterFuelPaymentChargeRoute />} />
        {/* Landing routes who triggers Pega journey */}
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_EMPLOYMENT} element={<AddEmploymentRoute />} />
        <Route path={PAYE_ROUTES.ADD_MISSING_EMPLOYMENT} element={<PegaCaseInitiatedRoute />} />
        <Route path={PAYE_ROUTES.START_EMP_UPDATE} element={<PegaCaseInitiatedRoute />} />
        <Route path={PAYE_ROUTES.START_PENSION} element={<PegaCaseInitiatedRoute />} />
        <Route path={PAYE_ROUTES.START_PEN_UPDATE} element={<PegaCaseInitiatedRoute />} />
        <Route path={PAYE_ROUTES.SUBMISSION_SUMMARY_START_EMP} element={<SummaryPageRoute />} />
        <Route path={PAYE_ROUTES.SUBMISSION_SUMMARY_START_EMP_UPDATE} element={<SummaryPageRoute />} />
        <Route path={PAYE_ROUTES.SUBMISSION_SUMMARY_START_PENSION} element={<SummaryPageRoute />} />
        <Route path={PAYE_ROUTES.SUBMISSION_SUMMARY_START_PEN_UPDATE} element={<SummaryPageRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_EMPLOYMENT} element={<UpdateEmploymentRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_EMPLOYMENT} element={<AddEmploymentRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_EMPLOYMENT} element={<UpdateEmploymentRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.ADD_PENSION} element={<AddPensionRoute />} />
        <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.UPDATE_PENSION} element={<UpdatePensionRoute />} />
        {/* Landing routes who triggers Pega journey */}
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.INTERRUPTION} element={<InterruptionRoute />} />
        <Route path={PAYE_ROUTES.SHUTTER} element={<ShutterServicePage />} />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.UPDATE_ESTIMATED_TAXABLE_INCOME} element={<UpdateEstimatedTaxableIncomeRoute />} />
        <Route
          path={PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_ALL_DETAILS_UPDATE_ESTIMATED_TAXABLE_INCOME}
          element={<UpdateEstimatedTaxableIncomeRoute />}
        />
        <Route path={PAYE_ROUTES.RESTRICTED_REDIRECTION.CANNOT_ACCESS_ACCOUNT} element={<MCI />} />
      </Route>

      <Route path={PAYE_ROUTES.COOKIES} element={<CookiePage />} />
      <Route path={PAYE_ROUTES.ACCESSIBILITY} element={<Accessibility />} />
      <Route path={PAYE_ROUTES.ERROR} element={<ErrorMessage />} />
      <Route path={PAYE_ROUTES.NO_INFORMATION} element={<NoP45InfoPage />} />
      <Route path={PAYE_ROUTES.NO_PENSION_INFO} element={<NoP45PensionInfo />} />
      <Route path={PAYE_ROUTES.ALLOWED_REDIRECTION.SIGNOUT} element={<SignoutConfirmationPage />} />
      <Route path='*' element={<Navigate to={PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING} replace />} />
    </Routes>
  );
};

export default AppSelector;
