import React from 'react';
import useRouteRedirectRestriction from '../../components/helpers/hooks/useRouteRedirectRestriction';
import { IabdOutletContext, PayeRouteState } from './type/routeTypes';

type MapProps<TProps> = (args: { outlet: IabdOutletContext; state: PayeRouteState }) => TProps;
const withIabdRoute = <TProps extends object>(
  Component: React.ComponentType<TProps>,
  mapProps: MapProps<TProps>
) => {
  const WrappedComponent = () => {
    const props = useRouteRedirectRestriction(mapProps);
    return <Component {...props} />;
  };

  WrappedComponent.displayName = `withIabdRoute(${Component.displayName || Component.name})`;
  return WrappedComponent;
};

export default withIabdRoute;
