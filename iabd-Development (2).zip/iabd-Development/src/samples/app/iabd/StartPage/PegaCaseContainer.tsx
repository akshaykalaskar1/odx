import { useEffect } from 'react';
import useCustomNavigate from '../../../../components/helpers/hooks/useCustomNavigate';
import { useLocation } from 'react-router-dom';

type Props = {
  caseType: string;
  redirectPath: string;
  employmentTaxData?: any;
  showPegaView: () => void;
  resetAppDisplay: () => void;
  getShutteredService: () => Promise<boolean>;
  showResolutionPage: boolean;
};

const PegaCaseContainer: React.FC<Props> = ({ caseType, redirectPath, showPegaView, resetAppDisplay, showResolutionPage }) => {
  const goTo = useCustomNavigate();
  const location = useLocation();

  const closeContainer = () => {
    const PCoreUtils = PCore.getContainerUtils();
    if (PCoreUtils.getActiveContainerItemName('app/primary')) {
      PCoreUtils.closeContainerItem(PCoreUtils.getActiveContainerItemContext('app/primary'), { skipDirtyCheck: true });
    }
  };

  useEffect(() => {
    const handler = () => {
      goTo(redirectPath);
      closeContainer();
      resetAppDisplay();
    };

    PCore.getPubSubUtils().subscribe('CUSTOM_EVENT_BACK', handler);
    return () => PCore.getPubSubUtils().unsubscribe('CUSTOM_EVENT_BACK', 'handler');
  }, []);

  useEffect(() => {
    const run = async () => {
      try {
        await PCore.getMashupApi().createCase(caseType, PCore.getConstants().APP.APP, { startingFields: location.state.startingFields });
        showPegaView();
      } catch (e) {
        console.log('Error at start of case: ', e);
      }
    };

    if (!showResolutionPage) run();
  }, []);

  return null;
};
export default PegaCaseContainer;
