import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import Accessibility from './index';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (k) => k }),
}));

jest.mock('../../../../components/AppComponents/AppHeader', () => ({
  __esModule: true,
  default: () => <div>AppHeader</div>,
}));

jest.mock('../../../../components/AppComponents/AppFooter', () => ({
  __esModule: true,
  default: () => <div>AppFooter</div>,
}));

jest.mock('../../../../components/AppComponents/LanguageToggle', () => ({
  __esModule: true,
  default: () => <div>LanguageToggle</div>,
}));

jest.mock('../../../../components/BaseComponents/MainWrapper', () => ({
  __esModule: true,
  default: ({ title, children }) => (
    <div className="govuk-width-container">
      <div data-test-id="MainWrapper-title">{String(title)}</div>
      {children}
    </div>
  ),
}));

jest.mock('../../../../components/helpers/hooks/HMRCExternalLinks', () => ({
  __esModule: true,
  default: () => ({
    referrerURL: 'test-referrer',
    hmrcURL: 'https://test.hmrc.gov.uk/',
  }),
}));

describe('Accessibility Page (BDD Style)', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('Given the user opens the Accessibility page', () => {
    describe('When the page loads', () => {
      it('Then it shows header, footer, language toggle, title and key content', () => {
        render(<Accessibility />);

        // Layout
        expect(screen.getByText('AppHeader')).toBeInTheDocument();
        expect(screen.getByText('AppFooter')).toBeInTheDocument();
        expect(screen.getByText('LanguageToggle')).toBeInTheDocument();

        // Main content
        expect(
          screen.getByRole('heading', {
            name: 'ACCESSIBLITY_STATEMENT_FOR_IABD_SERVICE',
            level: 1,
          })
        ).toBeInTheDocument();

        expect(screen.getByText('THIS_AS_EXPLAINS_HOW')).toBeInTheDocument();
        
        expect(
        screen.getByText(/THIS_SERVICE_IS_A_PART_GOVUK_WEBSITE/i)
        ).toBeInTheDocument();

      });
    });
  });

  describe('Given accessibility bullet list is present', () => {
    describe('When list items are generated', () => {
      it('Then all list entries are rendered', () => {
        render(<Accessibility />);

        for (let i = 0; i < 5; i += 1) {
          expect(
            screen.getByText(`ACCESSIBILITY_LIST_1_${i}`)
          ).toBeInTheDocument();
        }
      });
    });
  });

  describe('Given external HMRC link exists', () => {
    describe('When it is rendered', () => {
      it('Then it contains correct URL parameters', () => {
        render(<Accessibility />);

        const link = screen.getByRole('link', {
        name: /REPORT_THE_ACCESSIBILITY_PROBLEM/i,
    });

        expect(link).toBeInTheDocument();
        expect(link).toHaveAttribute(
        'href',
        expect.stringContaining('https://test.hmrc.gov.uk/')
        );

        expect(link).toHaveAttribute(
          'href',
          expect.stringContaining('referrerUrl=test-referrer')
        );
      });
    });
  });

  describe('Given key sections exist', () => {
    describe('When page renders fully', () => {
      it('Then important sections are visible', () => {
        render(<Accessibility />);

        expect(screen.getByText('HOW_ACCESSIBLE_THIS_SERVICE_IS')).toBeInTheDocument();
        expect(screen.getByText('WHAT_TO_DO_IF_YOU_HAVE_DIFFICULTY_USING_THIS')).toBeInTheDocument();
        expect(screen.getByText('REPORTING_ACCESSIBILITY_PROBLEMS_WITH_THIS_SERVICE')).toBeInTheDocument();
        expect(screen.getByText('TECHNICAL_INFO_ABOUT_THIS_SERVICE')).toBeInTheDocument();
      });
    });
  });
});