import React from 'react';
import { render, screen, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom';
import { act } from 'react';
import { renderHook } from '@testing-library/react-hooks';
import { I18nextProvider, useTranslation } from 'react-i18next';
import { mockGetSdkConfigWithBasepath } from '../../../../../tests/mocks/getSdkConfigMock';
import MCI from './MCI';

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

describe('MCI component', () => {
  let t;

  afterEach(cleanup);

  beforeEach(() => {
    t = renderHook(() => useTranslation());
    mockGetSdkConfigWithBasepath();
  });

  test('Given an MCI customer, when the page is displayed, then the MCI heading is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('We cannot show this information right now')).toBeInTheDocument();
  });

  test('Given an MCI customer, when the page is displayed, then the customer is informed additional checks are required', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('We need to check some details with you before you can use HMRC services again.')).toBeInTheDocument();
  });

  test('Given an MCI customer, when the page is displayed, then guidance on what to do next is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('What you need to do')).toBeInTheDocument();
  });

  test('Given an MCI customer, when the page is displayed, then a link to the Income Tax Helpline is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(
      screen.getByRole('link', {
        name: 'Contact the Income Tax Helpline (opens in new tab)'
      })
    ).toBeInTheDocument();
  });

  test('Given an MCI customer, when the page is displayed, then the Income Tax Helpline link points to the correct URL', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    const helplineLink = screen.getByRole('link', {
      name: 'Contact the Income Tax Helpline (opens in new tab)'
    });

    expect(helplineLink).toHaveAttribute('href', 'https://www.gov.uk/find-hmrc-contacts/income-tax-enquiries');

    expect(helplineLink).toHaveAttribute('target', '_blank');
  });

  test('Given an MCI customer, when the page is displayed, then guidance to say MCI is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('en');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('and say "MCI" when asked why you are calling. The helpline will explain what to do next.')).toBeInTheDocument();
  });

  test('Given a Welsh user, when the MCI page is displayed, then the Welsh heading is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('cy');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('Ni allwn ddangos yr wybodaeth hon ar hyn o bryd')).toBeInTheDocument();
  });

  test('Given a Welsh user, when the MCI page is displayed, then Welsh guidance is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('cy');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('Mae angen i ni wirio rhai manylion â chi, cyn y gallwch ddefnyddio gwasanaethau CThEF eto.')).toBeInTheDocument();
  });

  test('Given a Welsh user, when the MCI page is displayed, then the Welsh section heading is shown', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('cy');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(screen.getByText('Yr hyn y mae angen i chi ei wneud')).toBeInTheDocument();
  });

  test('Given a Welsh user, when the MCI page is displayed, then guidance to say MCI is shown in Welsh', async () => {
    await act(async () => {
      t.result.current.i18n?.changeLanguage('cy');

      render(
        <I18nextProvider i18n={t.result.current.i18n}>
          <MCI />
        </I18nextProvider>
      );
    });

    expect(
      screen.getByText('a dywedwch ‘MCI’ pan ofynnir i chi pam yr ydych yn ffonio. Bydd y llinell gymorth yn esbonio beth i’w wneud nesaf.')
    ).toBeInTheDocument();
  });
});
