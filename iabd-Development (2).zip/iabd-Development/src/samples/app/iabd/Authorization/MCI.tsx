import MainWrapperFull from '../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { useEffect } from 'react';
import setPageTitle from '../../../../components/helpers/setPageTitleHelpers';
import i18next from 'i18next';
import { useTranslation } from 'react-i18next';
const MCI = () => {
  const { t } = useTranslation();
  useEffect(() => {
    setPageTitle();
  }, [i18next.language]);
  return (
    <main className='govuk-main-wrapper govuk-main-wrapper--l' id='main-content' role='main'>
      <MainWrapperFull title={t('WE_CANNOT_SHOW_THIS_INFORMATION_RIGHT_NOW', { lng: 'en' })}>
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-two-thirds'>
            <h1 className='govuk-heading-l'>{t('WE_CANNOT_SHOW_THIS_INFORMATION_RIGHT_NOW')}</h1>
            <p className='govuk-body'>{t('WE_NEED_TO_CHECK_SOME_DETAILS_MCI')}</p>

            <h2 className='govuk-heading-m'>{t('WHAT_YOU_NEED_TO_DO')}</h2>
            <p className='govuk-body'>
              <a
                href='https://www.gov.uk/find-hmrc-contacts/income-tax-enquiries'
                className='govuk-link'
                target='_blank'
                rel='noopener noreferrer'
                data-tracking-type='Outbound'
                data-tracking-target='https://www.gov.uk/find-hmrc-contacts/income-tax-enquiries'
              >
                {t('CONTACT_THE_INCOME_TAX_HELPLINE')} {t('OPENS_IN_NEW_TAB')}
              </a>{' '}
              {t('SAY_MCI')}
            </p>
          </div>
        </div>
      </MainWrapperFull>
    </main>
  );
};

export default MCI;
