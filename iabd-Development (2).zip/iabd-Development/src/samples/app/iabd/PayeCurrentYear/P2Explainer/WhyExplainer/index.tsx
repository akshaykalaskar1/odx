import { getCurrentLang } from '../../../../../../components/helpers/utils';
import { WhyExplainerItem, WhyExplainerItemCategory } from '../typings';
import WhyTemplate from './WhyTemplate';

interface WhyExplainerProps {
  items: WhyExplainerItem[] | null;
  lang?: string;
}

const REACT: WhyExplainerItemCategory = 'React';
const PEGA: WhyExplainerItemCategory = 'Pega';

const WhyExplainer: React.FC<WhyExplainerProps> = ({ items }) => {
  const currentLang = getCurrentLang().toUpperCase();
  const itemList = items ?? [];

  const renderContent = (item: WhyExplainerItem): string | React.ReactNode | null => {
    if (!item) return null;

    if (item.Category === PEGA) {
      const content = item.Content ?? [];
      const selectedContent = content.find(cont => cont.Language === currentLang);

      return selectedContent?.Description ?? null;
    }

    if (item.Category === REACT) {
      return <WhyTemplate referenceId={item.ReferenceID} pyActionType={item.pyActionType} {...item} />;
    }

    return null;
  };

  if (itemList.length === 1) {
    const body = renderContent(itemList[0]);

    return body && <>{body}</>;
  }

  return (
    <ol className='govuk-list govuk-list--number govuk-list--spaced'>
      {itemList.map(item => {
        return <li key={item.ReferenceID}>{renderContent(item)}</li>;
      })}
    </ol>
  );
};

export default WhyExplainer;
