import React from 'react';
import { screen, fireEvent } from '@testing-library/react';
import WhatExplainer from '.';
import { TaxDetail } from '../typings';
import mockGoTo from '../../../../../../../tests/mocks/routerMocks';
import renderWithRouter from '../../../../../../../tests/utils/renderWithRouter';
import PAYE_ROUTES from '../../../../../AppSelector/payeRoutes';

jest.mock('../../../../../../components/helpers/hooks/useCustomNavigate', () => ({
  __esModule: true,
  default: () => mockGoTo
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  currencyFormatter: (value: number) => `£${value.toFixed(2)}`,
  formatTaxCode: (code: string) => code
}));

jest.mock('hmrc-gds-react-components', () => ({
  Link: ({ onClick, children }: any) => (
    <a href='#' onClick={onClick}>
      {children}
    </a>
  )
}));

describe('WhatExplainer component', () => {
  const redirectMock = jest.fn();
  const defaultTaxDetails: TaxDetail[] = [
    { pyNote: 'Now' as TaxDetail['pyNote'], AssignedTaxCode: 'NOWCODE' },
    { pyNote: 'Before' as TaxDetail['pyNote'], AssignedTaxCode: 'BEFORECODE' }
  ];

  const renderComponent = (props: Partial<React.ComponentProps<typeof WhatExplainer>> = {}) => {
    const defaultProps: React.ComponentProps<typeof WhatExplainer> = {
      monthlyEarnings: 200,
      isActivePension: false,
      redirectToViewTimelineDetailsPage: redirectMock,
      taxDetails: defaultTaxDetails
    };

    return renderWithRouter(<WhatExplainer {...defaultProps} {...props} />, {
      state: { some: 'state' }
    });
  };

  beforeEach(() => jest.clearAllMocks());

  describe.each([null, 0])('Given monthlyEarnings is %p', monthlyEarnings => {
    describe('When the component renders', () => {
      beforeEach(() => {
        renderComponent({ monthlyEarnings: monthlyEarnings as number | null });
      });

      it('Then it shows the tax code change statement', () => {
        expect(screen.getByText(/YOUR_TAX_CODE_WILL_CHANGE_FROM/)).toBeInTheDocument();
        expect(screen.getByText(/BEFORECODE/)).toBeInTheDocument();
        expect(screen.getByText(/NOWCODE/)).toBeInTheDocument();
      });

      it('Then it shows the link for checking tax code calculation', () => {
        expect(
          screen.getByRole('link', {
            name: /CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA/
          })
        ).toBeInTheDocument();
      });

      it('Then clicking the link navigates to view timeline details', () => {
        fireEvent.click(
          screen.getByRole('link', {
            name: /CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA/
          })
        );

        expect(mockGoTo).toHaveBeenCalledWith(PAYE_ROUTES.RESTRICTED_REDIRECTION.VIEW_TIMELINE_DETAILS, { some: 'state' });
      });

      it('Then it does not show earnings estimate text', () => {
        expect(screen.queryByText(/WE_ESTIMATE_YOU_PAY/)).not.toBeInTheDocument();
      });
    });

    describe('When isActivePension is true', () => {
      beforeEach(() => {
        renderComponent({
          monthlyEarnings: monthlyEarnings as number | null,
          isActivePension: true
        });
      });

      it('Then it uses INCOME in the tax code change text', () => {
        expect(screen.getByText(/INCOME_WE_ESTIMATE_AMOUT_TAX_YOU_NOT_CHANGE/)).toBeInTheDocument();
      });
    });

    describe('When isActivePension is false', () => {
      beforeEach(() => {
        renderComponent({
          monthlyEarnings: monthlyEarnings as number | null,
          isActivePension: false
        });
      });

      it('Then it uses EARNINGS in the tax code change text', () => {
        expect(screen.getByText(/EARNINGS_WE_ESTIMATE_AMOUT_TAX_YOU_NOT_CHANGE/)).toBeInTheDocument();
      });
    });
  });

  describe('Given monthlyEarnings is positive', () => {
    describe('When the component renders', () => {
      beforeEach(() => {
        renderComponent({ monthlyEarnings: 250 });
      });

      it('Then it displays LESS with the formatted amount', () => {
        expect(screen.getByText(/£250\.00 LESS EVERY_MONTH/)).toBeInTheDocument();
      });

      it('Then it displays the explanatory paragraph', () => {
        expect(screen.getByText(/THIS_AMOUNT_IS_AN_ESTIMATE/)).toBeInTheDocument();
        expect(screen.getByText(/COULD_CHANGE_IN_FUTURE/)).toBeInTheDocument();
      });

      it('Then it uses the EARNING label', () => {
        expect(screen.getByText(/BASED_ON_CURRENT EARNING WE_ESTIMATE_YOU_PAY/)).toBeInTheDocument();
      });
    });
  });

  describe('Given monthlyEarnings is negative', () => {
    describe('When the component renders', () => {
      beforeEach(() => {
        renderComponent({ monthlyEarnings: -50 });
      });

      it('Then it displays MORE with the absolute value', () => {
        expect(screen.getByText(/£50\.00 MORE EVERY_MONTH/)).toBeInTheDocument();
      });

      it('Then it displays the explanatory paragraph', () => {
        expect(screen.getByText(/THIS_AMOUNT_IS_AN_ESTIMATE/)).toBeInTheDocument();
      });
    });
  });

  describe('Given isActivePension is true', () => {
    describe('When the component renders', () => {
      beforeEach(() => {
        renderComponent({ monthlyEarnings: 300, isActivePension: true });
      });

      it('Then it uses INCOME as the label', () => {
        expect(screen.getByText(/BASED_ON_CURRENT INCOME WE_ESTIMATE_YOU_PAY/)).toBeInTheDocument();
      });

      it('Then the secondary paragraph uses INCOME', () => {
        expect(screen.getByText(/THIS_AMOUNT_IS_AN_ESTIMATE INCOME COULD_CHANGE_IN_FUTURE/)).toBeInTheDocument();
      });
    });
  });

  describe('Given isActivePension is false', () => {
    describe('When the component renders', () => {
      beforeEach(() => {
        renderComponent({ monthlyEarnings: 200, isActivePension: false });
      });

      it('Then it uses EARNING as the label', () => {
        expect(screen.getByText(/BASED_ON_CURRENT EARNING WE_ESTIMATE_YOU_PAY/)).toBeInTheDocument();
      });
    });
  });
});
