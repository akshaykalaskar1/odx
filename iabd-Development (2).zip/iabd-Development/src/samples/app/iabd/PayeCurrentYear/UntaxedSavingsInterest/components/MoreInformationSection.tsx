import { Heading, Link } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { useLocation } from 'react-router-dom';
import PAYE_ROUTES from '../../../../../AppSelector/payeRoutes';
import useCustomNavigate from '../../../../../../components/helpers/hooks/useCustomNavigate';

const MoreInformationSection = () => {
  const location = useLocation();
  const goTo = useCustomNavigate();
  const { t } = useTranslation();

  return (
    <>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {t('USI_MORE_INFORMATION_HEADING')}
      </Heading>

      <p className='govuk-body'>
        <Link
          href='#'
          onClick={e => {
            e.preventDefault();
            goTo(PAYE_ROUTES.RESTRICTED_REDIRECTION.ABOUT_UNTAXED_SAVINGS_INTEREST, {
              ...location.state,
              pageName: 'What untaxed savings interest means'
            });
          }}
        >
          {t('USI_MORE_INFORMATION_LINK')}
        </Link>
      </p>
    </>
  );
};

export default MoreInformationSection;
