import { Link } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { currencyFormatter } from '../../../../../../components/helpers/utils';

interface Props {
  savingsInterestThreshold: number;
}

const GenericSavingsInterestDetails = ({ savingsInterestThreshold }: Props) => {
  const { t } = useTranslation();

  return (
    <>
      <h2 className='govuk-heading-m'>{t('USI_GENERIC_DETAILS_HEADING')}</h2>

      <p className='govuk-body'>
        {t('USI_GENERIC_DETAILS_P1', {
          savingsInterestThreshold: currencyFormatter(savingsInterestThreshold.toLocaleString('en-GB'))
        })}{' '}
        <Link
          href='https://www.gov.uk/log-in-file-self-assessment-tax-return'
          target='_blank'
          rel='noreferrer noopener'
          data-tracking-type='Outbound'
          data-tracking-target='https://www.gov.uk/log-in-file-self-assessment-tax-return'
        >
          {t('USI_DETAILS_LINK')}
        </Link>
        .
      </p>
    </>
  );
};

export default GenericSavingsInterestDetails;
