import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import UntaxedSavingsInterestLanding from './UntaxedSavingsInterestLanding';

const mockNavigate = jest.fn();
const mockMap = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
  useLocation: () => ({ pathname: '/' })
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../components/helpers/setPageTitleHelpers', () => jest.fn());

jest.mock('../../../../../components/helpers/LoadingSpinner/LoadingWrapper', () => ({ children }: any) => <div>{children}</div>);

jest.mock('../../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({ children }: any) => <div>{children}</div>);

jest.mock('../../../../../components/BaseComponents/Button/Button', () => ({ onClick }: any) => <button onClick={onClick}>Back</button>);

jest.mock('./components/UntaxedSavingsInterestPage', () => (props: any) => <div>{props.viewModel?.title}</div>);

jest.mock('./mappers/untaxedSavingsInterestMapper', () => ({
  mapUntaxedSavingsInterest: (...args: any[]) => mockMap(...args)
}));

jest.mock('../../ErrorPage/errorMessage', () => () => <div>Error</div>);

describe('UntaxedSavingsInterestLanding', () => {
  const props = {
    CurrentTaxYear: 2025,
    NextTaxStartYear: 2026,
    savingsInterestThreshold: '10000',
    startingRateForSavings: '5000',
    genericUntaxedSavingsInterest: false
  };

  const mappedViewModel = {
    title: 'USI_TITLE',
    CIP_EventID: 'BASIC'
  };

  beforeEach(() => {
    jest.clearAllMocks();

    (globalThis as any).PCore = {
      getDataPageUtils: () => ({
        getDataAsync: jest.fn().mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: []
              }
            }
          ]
        })
      })
    };

    mockMap.mockReturnValue(mappedViewModel);
  });

  test('renders page when API returns data', async () => {
    // mockNavigate.mockClear();
    render(<UntaxedSavingsInterestLanding {...props} />);

    await waitFor(() => {
      expect(mockMap).toHaveBeenCalled();
    });

    expect(screen.getByText('USI_TITLE')).toBeInTheDocument();
  });

  test('calls mapper with dynamic values', async () => {
    render(<UntaxedSavingsInterestLanding {...props} />);

    await waitFor(() => {
      expect(mockMap).toHaveBeenCalledWith(expect.any(Object), {
        CurrentTaxYear: 2025,
        NextTaxStartYear: 2026,
        savingsInterestThreshold: '10000',
        startingRateForSavings: '5000'
      });
    });
  });

  test('renders error page when pyErrors are returned', async () => {
    (globalThis as any).PCore = {
      getDataPageUtils: () => ({
        getDataAsync: jest.fn().mockResolvedValue({
          data: [
            {
              pyErrors: [{}]
            }
          ]
        })
      })
    };

    render(<UntaxedSavingsInterestLanding {...props} />);

    expect(await screen.findByText('Error')).toBeInTheDocument();
  });

  test('navigates back when backlink is clicked', async () => {
    render(<UntaxedSavingsInterestLanding {...props} />);

    const backButton = await screen.findByRole('button', {
      name: 'Back'
    });

    fireEvent.click(backButton);

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  test('handles API exception', async () => {
    (globalThis as any).PCore = {
      getDataPageUtils: () => ({
        getDataAsync: jest.fn().mockRejectedValue(new Error('API Failure'))
      })
    };

    const consoleSpy = jest.spyOn(console, 'error').mockImplementation(() => {});

    render(<UntaxedSavingsInterestLanding {...props} />);

    await waitFor(() => {
      expect(consoleSpy).toHaveBeenCalled();
    });

    consoleSpy.mockRestore();
  });
});
