import { Link } from 'hmrc-gds-react-components';
interface Props {
  message: string;
  linkText: string;
  linkUrl: string;
}

const ContactUsSection = ({ message, linkText, linkUrl }: Props) => {
  return (
    <p className='govuk-body'>
      {message}{' '}
      <Link href={linkUrl} target='_blank' rel='noreferrer noopener' data-tracking-type='Outbound' data-tracking-target={linkUrl}>
        {linkText}
      </Link>
      .
    </p>
  );
};

export default ContactUsSection;
