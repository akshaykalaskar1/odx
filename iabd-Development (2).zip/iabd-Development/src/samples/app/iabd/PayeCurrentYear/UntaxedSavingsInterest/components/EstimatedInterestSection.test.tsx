import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import EstimatedInterestSection from './EstimatedInterestSection';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string, options?: any) => (options ? `${key}-${JSON.stringify(options)}` : key)
  })
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  currencyFormatter: jest.fn((value: string) => `£${value}`)
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <h2>{children}</h2>,
  SummaryList: ({ children }: any) => <div data-testid='summary-list'>{children}</div>,
  SummaryListRow: ({ label, value }: any) => (
    <div data-testid='summary-row'>
      <span>{label}</span>
      <span>{value}</span>
    </div>
  )
}));

describe('EstimatedInterestSection', () => {
  const defaultProps = {
    EstimatedUSI: '200',
    PSA: '1000',
    TaxToPay: '50',
    CurrentTaxYear: 2025,
    NextTaxStartYear: 2026
  };

  test('renders summary table when showSummaryTable is true', () => {
    render(<EstimatedInterestSection {...defaultProps} showSummaryTable />);

    expect(screen.getByText('USI_ESTIMATED_HEADING')).toBeInTheDocument();

    expect(screen.getByText('USI_PSA_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_ESTIMATED_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_TAX_TO_PAY_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_WITHIN_PSA')).toBeInTheDocument();

    expect(screen.getByText('USI_PSA_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_ESTIMATED_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_TAX_TO_PAY_ROW')).toBeInTheDocument();

    expect(screen.getByText('USI_WITHIN_PSA')).toBeInTheDocument();
  });

  test('renders estimated interest message when showSummaryTable is false', () => {
    render(<EstimatedInterestSection {...defaultProps} showSummaryTable={false} />);

    expect(screen.getByText(/USI_ESTIMATED_AMOUNT/)).toBeInTheDocument();

    expect(screen.getByText('USI_NO_TAX')).toBeInTheDocument();

    expect(screen.queryByTestId('summary-list')).not.toBeInTheDocument();
  });

  test('renders tax year message', () => {
    render(<EstimatedInterestSection {...defaultProps} showSummaryTable={false} />);

    expect(screen.getByText(/USI_ESTIMATED_MESSAGE/)).toBeInTheDocument();
  });
});
