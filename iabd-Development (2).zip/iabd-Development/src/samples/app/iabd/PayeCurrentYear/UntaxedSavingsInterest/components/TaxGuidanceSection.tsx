import { Heading, Link } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
interface Props {
  heading: string;
  paragraphs: readonly string[];
  bullets: readonly string[];
  showAllowanceGuidance?: boolean;
}

const TaxGuidanceSection = ({ heading, paragraphs, bullets, showAllowanceGuidance = false }: Props) => {
  const { t } = useTranslation();

  return (
    <>
      <Heading headingLevel={2} className='govuk-heading-m'>
        {heading}
      </Heading>

      {showAllowanceGuidance && (
        <>
          <p className='govuk-body'>
            {t('USI_ALLOWANCE_GUIDANCE_P1')}{' '}
            <Link
              target='_blank'
              rel='noreferrer noopener'
              href='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
              data-tracking-type='Outbound'
              data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
            >
              {t('USI_ALLOWANCE_GUIDANCE_PSA_LINK')} {t('OPENS_IN_NEW_TAB')}
            </Link>
            .
          </p>

          <p className='govuk-body'>
            {t('USI_ALLOWANCE_GUIDANCE_P2')}{' '}
            <Link
              target='_blank'
              rel='noreferrer noopener'
              href='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
              data-tracking-type='Outbound'
              data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
            >
              {t('USI_ALLOWANCE_GUIDANCE_STARTING_RATE_LINK')}
            </Link>
            .
          </p>
        </>
      )}

      {paragraphs.map(paragraph => (
        <p key={paragraph} className='govuk-body'>
          {paragraph}
        </p>
      ))}

      {bullets.length > 0 && (
        <ul className='govuk-list govuk-list--bullet'>
          {bullets.map(bullet => (
            <li key={bullet}>{bullet}</li>
          ))}
        </ul>
      )}
    </>
  );
};

export default TaxGuidanceSection;
