import { TAX_BAND_CONFIG } from '../config/taxBandConfig';
import { UntaxedSavingsInterestApiResponse } from '../models/UntaxedSavingsInterestApiResponse';
import { UntaxedSavingsInterestViewModel } from '../models/UntaxedSavingsInterestViewModel';

export const mapUntaxedSavingsInterest = (
  response: UntaxedSavingsInterestApiResponse,
  dynamicValues: {
    CurrentTaxYear: number;
    NextTaxStartYear: number;
    savingsInterestThreshold: string;
    startingRateForSavings: string;
  }
): UntaxedSavingsInterestViewModel => {
  const taxSummary = response.data?.[0]?.Customer?.TaxSummaryList?.[0];

  const templateType = taxSummary?.pyTemplateDataField;

  const config = TAX_BAND_CONFIG[templateType as keyof typeof TAX_BAND_CONFIG];

  return {
    title: 'USI_TITLE',

    allowanceText: config?.allowanceText ?? '',

    introduction: 'USI_INTRODUCTION',

    showGenericLayout: templateType === 'GENERIC-USI',

    introParagraphs: [...(config?.introParagraphs ?? [])],

    showStartingRateParagraph: config?.showStartingRateParagraph ?? false,

    isAdditionalRate: config?.isAdditionalRate ?? false,

    showTPHigherLayout: config?.showTPHigherLayout ?? false,

    showTPAdditionalLayout: config?.showTPAdditionalLayout ?? false,

    TaxableAmount: 'TaxableAmount' in taxSummary ? (taxSummary.TaxableAmount as string) : '',

    personalSavingsAllowanceAmount: Number(taxSummary.PSA),
    startingRateForSavingsAmount: Number(dynamicValues.startingRateForSavings),

    savingsInterestThreshold: Number(dynamicValues.savingsInterestThreshold),

    EstimatedUSI: taxSummary?.EstimatedUSI,

    CurrentTaxYear: dynamicValues.CurrentTaxYear,

    NextTaxStartYear: dynamicValues.NextTaxStartYear,

    summaryTable: config?.showSummaryTable
      ? {
          PSA: taxSummary?.PSA,
          EstimatedUSI: taxSummary?.EstimatedUSI,
          TaxToPay: taxSummary?.TaxToPay
        }
      : undefined,

    taxGuidance: {
      heading: config?.guidanceHeading ?? '',

      // TODO : Need to update below template type in upcoming sprint for addtional rate

      paragraphs: [...(config?.guidanceParagraphs ?? [])],

      bullets: [...(config?.guidanceBullets ?? [])]
    },

    details: {
      heading: config?.detailsHeading ?? '',

      paragraphs: []
    },

    contactUsMessage: config?.contactUsMessage ?? '',

    contactUsLinkText: 'USI_CONTACT_US_LINK',

    contactUsLinkUrl: 'https://www.gov.uk/find-hmrc-contacts?keywords=savings',

    CIP_EventID: config?.CIP_EventID ?? ''
  };
};
