import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import AllowanceSection from './AllowanceSection';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

describe('AllowanceSection', () => {
  const defaultProps = {
    allowanceText: 'USI_ALLOWANCE_TEXT_BASIC',
    personalSavingsAllowanceAmount: 1000,
    startingRateForSavingsAmount: 5000,
    showStartingRateParagraph: false,
    isAdditionalRate: false
  };

  test('Given no allowance text exists, when rendered, then nothing is displayed', () => {
    const { container } = render(<AllowanceSection {...defaultProps} allowanceText='' />);

    expect(container.firstChild).toBeNull();
  });

  test('Given an additional rate taxpayer, when rendered, then additional rate content is displayed', () => {
    render(<AllowanceSection {...defaultProps} isAdditionalRate />);

    expect(screen.getByText(/USI_ALLOWANCE_TEXT_BASIC/i)).toBeInTheDocument();

    expect(screen.getByRole('link')).toHaveAttribute('href', 'https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance');
  });

  test('Given a non additional rate taxpayer, when rendered, then allowance amount is displayed', () => {
    render(<AllowanceSection {...defaultProps} />);

    expect(screen.getByText(/1,000/i)).toBeInTheDocument();

    expect(screen.getByRole('link')).toBeInTheDocument();
  });

  test('Given starting rate paragraph flag is true, when rendered, then starting rate content is displayed', () => {
    render(<AllowanceSection {...defaultProps} showStartingRateParagraph />);

    expect(screen.getByText(/USI_STARTING_RATE_PREFIX/i)).toBeInTheDocument();

    expect(screen.getByText(/5,000/i)).toBeInTheDocument();

    expect(
      screen.getByRole('link', {
        name: /USI_STARTING_RATE_LINK/i
      })
    ).toBeInTheDocument();
  });

  test('Given starting rate paragraph flag is false, when rendered, then starting rate content is not displayed', () => {
    render(<AllowanceSection {...defaultProps} showStartingRateParagraph={false} />);

    expect(screen.queryByText(/USI_STARTING_RATE_PREFIX/i)).not.toBeInTheDocument();
  });
});
