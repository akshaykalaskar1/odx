export interface SummaryTableViewModel {
  PSA: string;
  EstimatedUSI: string;
  TaxToPay: string;
}

export interface UntaxedSavingsInterestViewModel {
  title: string;

  introduction: string;
  showTPHigherLayout: boolean;
  showTPAdditionalLayout: boolean;
  showGenericLayout: boolean;
  introParagraphs: readonly string[];
  allowanceText: string;
  savingsInterestThreshold: number;
  TaxableAmount: string;
  personalSavingsAllowanceAmount: number;

  showStartingRateParagraph: boolean;

  isAdditionalRate: boolean;

  startingRateForSavingsAmount: number;

  EstimatedUSI: string;

  CurrentTaxYear?: number;
  NextTaxStartYear?: number;

  contactUsMessage: string;

  contactUsLinkText: string;

  contactUsLinkUrl: string;

  summaryTable?: SummaryTableViewModel;

  taxGuidance: {
    heading: string;
    paragraphs: readonly string[];
    bullets: readonly string[];
  };

  details: {
    heading: string;
    paragraphs: readonly string[];
  };

  CIP_EventID: string;
}
