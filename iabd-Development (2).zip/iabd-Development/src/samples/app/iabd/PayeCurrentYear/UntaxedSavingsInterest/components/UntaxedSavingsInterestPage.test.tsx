import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import UntaxedSavingsInterestPage from './UntaxedSavingsInterestPage';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <h1>{children}</h1>
}));

jest.mock('./AllowanceSection', () => (props: any) => <div data-test-id='allowance-section'>{JSON.stringify(props)}</div>);

jest.mock('./EstimatedInterestSection', () => (props: any) => <div data-test-id='estimated-interest-section'>{JSON.stringify(props)}</div>);

jest.mock('./TaxGuidanceSection', () => (props: any) => <div data-test-id='tax-guidance-section'>{JSON.stringify(props)}</div>);

jest.mock('./ContactUsSection', () => (props: any) => <div data-test-id='contact-us-section'>{JSON.stringify(props)}</div>);

jest.mock('./SavingsInterestDetails', () => (props: any) => <div data-test-id='savings-interest-details'>{JSON.stringify(props)}</div>);

jest.mock('./MoreInformationSection', () => () => <div data-testid='more-information-section'>More Information</div>);

jest.mock('hmrc-odx-features-and-functions', () => ({
  withPageTracking: (Component: React.ComponentType<any>) => Component
}));

describe('UntaxedSavingsInterestPage', () => {
  const viewModel = {
    title: 'USI_TITLE',
    introduction: 'USI_INTRODUCTION',

    introParagraphs: [],
    showGenericLayout: false,

    allowanceText: 'USI_ALLOWANCE_TEXT_BASIC',
    personalSavingsAllowanceAmount: 1000,
    startingRateForSavingsAmount: 5000,

    showStartingRateParagraph: true,
    isAdditionalRate: false,

    EstimatedUSI: '1200',

    CurrentTaxYear: 2025,
    NextTaxStartYear: 2026,

    savingsInterestThreshold: 10000,

    contactUsMessage: 'USI_CONTACT_MESSAGE',
    contactUsLinkText: 'USI_CONTACT_LINK',
    contactUsLinkUrl: 'https://example.com',

    summaryTable: {
      PSA: '1000',
      EstimatedUSI: '1200',
      TaxToPay: '40'
    },

    taxGuidance: {
      heading: 'USI_GUIDANCE_HEADING',
      paragraphs: ['PARAGRAPH_1'],
      bullets: ['USI_BULLET_PSA_1']
    },

    details: {
      heading: 'USI_DETAILS_HEADING',
      paragraphs: []
    },

    CIP_EventID: 'BASIC'
  } as any;

  test('renders page heading and introduction', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByText('USI_TITLE')).toBeInTheDocument();
    expect(screen.getByText('USI_INTRODUCTION')).toBeInTheDocument();
  });

  test('renders allowance section', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByTestId('allowance-section')).toBeInTheDocument();
  });

  test('renders estimated interest section', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByTestId('estimated-interest-section')).toBeInTheDocument();
  });

  test('renders tax guidance section', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByTestId('tax-guidance-section')).toBeInTheDocument();
  });

  test('renders contact us section', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByTestId('contact-us-section')).toBeInTheDocument();
  });

  test('renders savings interest details section', () => {
    render(<UntaxedSavingsInterestPage viewModel={viewModel} pageName='BASIC' />);

    expect(screen.getByTestId('savings-interest-details')).toBeInTheDocument();
  });

  test('passes allowance guidance flag when allowance bullets are present', () => {
    render(
      <UntaxedSavingsInterestPage
        viewModel={{
          ...viewModel,
          taxGuidance: {
            ...viewModel.taxGuidance,
            bullets: ['USI_BULLET_ALLOWANCES_1']
          }
        }}
        pageName='BASIC'
      />
    );

    expect(screen.getByTestId('tax-guidance-section')).toHaveTextContent('"showAllowanceGuidance":true');
  });

  test('passes allowance guidance flag as false when allowance bullets are absent', () => {
    render(
      <UntaxedSavingsInterestPage
        viewModel={{
          ...viewModel,
          taxGuidance: {
            ...viewModel.taxGuidance,
            bullets: ['USI_BULLET_PSA_1']
          }
        }}
        pageName='BASIC'
      />
    );

    expect(screen.getByTestId('tax-guidance-section')).toHaveTextContent('"showAllowanceGuidance":false');
  });
});
