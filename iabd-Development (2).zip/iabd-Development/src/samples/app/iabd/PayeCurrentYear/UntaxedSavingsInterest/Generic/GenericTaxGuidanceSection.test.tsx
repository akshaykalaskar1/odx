import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import GenericTaxGuidanceSection from './GenericTaxGuidanceSection';

describe('GenericTaxGuidanceSection', () => {
  const props = {
    heading: 'Generic guidance heading',
    paragraphs: ['First paragraph', 'Second paragraph', 'Third paragraph']
  };

  test('renders heading', () => {
    render(<GenericTaxGuidanceSection {...props} />);

    expect(screen.getByText('Generic guidance heading')).toBeInTheDocument();
  });

  test('renders all paragraphs', () => {
    render(<GenericTaxGuidanceSection {...props} />);

    expect(screen.getByText('First paragraph')).toBeInTheDocument();

    expect(screen.getByText('Second paragraph')).toBeInTheDocument();

    expect(screen.getByText('Third paragraph')).toBeInTheDocument();
  });
});
