import { useTranslation } from 'react-i18next';
import { Heading } from 'hmrc-gds-react-components';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import GenericAllowanceSection from './GenericAllowanceSection';
import GenericTaxGuidanceSection from './GenericTaxGuidanceSection';
import GenericSavingsInterestDetails from './GenericSavingsInterestDetails';
import MoreInformationSection from '../components/MoreInformationSection';

const UntaxedSavingsInterestPage = ({ CurrentTaxYear, savingsInterestThreshold, startingRateForSavings, NextTaxStartYear }) => {
  const { t } = useTranslation();

  const viewModel = {
    title: 'USI_TITLE',
    introduction: 'USI_INTRODUCTION',
    introParagraphs: ['USI_GENERIC_INTRO', 'USI_ESTIMATED_MESSAGE'],

    allowanceText: 'USI_ALLOWANCE_TEXT_GENERIC',
    contactUsMessage: '',
    showStartingRateParagraph: true,
    isAdditionalRate: false,
    showSummaryTable: false,
    guidanceHeading: 'USI_GENERIC_GUIDANCE_HEADING',
    guidanceParagraphs: ['USI_GENERIC_GUIDANCE_P1', 'USI_GENERIC_GUIDANCE_P2', 'USI_GENERIC_GUIDANCE_P3'],
    detailsHeading: 'USI_GENERIC_DETAILS_HEADING',
    CIP_EventID: 'Untaxed Interest-Generic explainer'
  };

  return (
    <>
      <div className='govuk-grid-row'>
        <div className='govuk-grid-column-two-thirds'>
          <Heading headingLevel={1} className='govuk-heading-l'>
            {t('USI_TITLE')}
          </Heading>

          <p className='govuk-body'>{t('USI_INTRODUCTION')}</p>
          {viewModel.introParagraphs.map(paragraph => (
            <p key={paragraph} className='govuk-body'>
              {t(paragraph, {
                CurrentTaxYear: CurrentTaxYear,
                NextTaxStartYear: NextTaxStartYear
              })}
            </p>
          ))}

          <GenericAllowanceSection startingRateForSavingsAmount={startingRateForSavings} />
          <GenericTaxGuidanceSection
            heading={t(viewModel.guidanceHeading)}
            paragraphs={viewModel.guidanceParagraphs.map(paragraph => t(paragraph))}
          />

          <GenericSavingsInterestDetails savingsInterestThreshold={savingsInterestThreshold} />

          <MoreInformationSection />
        </div>
      </div>
    </>
  );
};

export default withPageTracking(UntaxedSavingsInterestPage);
