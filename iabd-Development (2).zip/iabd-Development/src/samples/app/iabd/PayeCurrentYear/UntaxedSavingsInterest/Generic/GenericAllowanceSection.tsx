import { Link } from 'hmrc-gds-react-components';
import { useTranslation } from 'react-i18next';
import { currencyFormatter } from '../../../../../../components/helpers/utils';

interface Props {
  startingRateForSavingsAmount: number;
}

const GenericAllowanceSection = ({ startingRateForSavingsAmount }: Props) => {
  const { t } = useTranslation();

  return (
    <>
      <h2 className='govuk-heading-m'>{t('USI_GENERIC_ALLOWANCE_HEADING')}</h2>

      <p className='govuk-body'>{t('USI_GENERIC_ALLOWANCE_P1')}</p>

      <p className='govuk-body'>
        {t('USI_GENERIC_ALLOWANCE_P2')}{' '}
        <Link
          href='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
          target='_blank'
          rel='noreferrer noopener'
          data-tracking-type='Outbound'
          data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#personal-savings-allowance'
        >
          {t('USI_PSA_LINK')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        .
      </p>

      <p className='govuk-body'>
        {t('USI_GENERIC_ALLOWANCE_P3', {
          amount: currencyFormatter(startingRateForSavingsAmount.toLocaleString('en-GB'))
        })}{' '}
        <Link
          href='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
          target='_blank'
          rel='noreferrer noopener'
          data-tracking-type='Outbound'
          data-tracking-target='https://www.gov.uk/apply-tax-free-interest-on-savings#starting-rate-for-savings'
        >
          {t('USI_STARTING_RATE_LINK')} {t('OPENS_IN_NEW_TAB')}
        </Link>
        .
      </p>
    </>
  );
};

export default GenericAllowanceSection;
