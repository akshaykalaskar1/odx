import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import ContactUsSection from './ContactUsSection';

describe('ContactUsSection', () => {
  const props = {
    message: 'Contact HMRC if you need help.',
    linkText: 'Contact us',
    linkUrl: 'https://www.gov.uk/contact-hmrc'
  };

  test('renders message and link', () => {
    render(<ContactUsSection {...props} />);

    expect(screen.getByText(/Contact HMRC if you need help./)).toBeInTheDocument();

    const link = screen.getByRole('link', {
      name: 'Contact us'
    });

    expect(link).toBeInTheDocument();
    expect(link).toHaveAttribute('href', 'https://www.gov.uk/contact-hmrc');
  });

  test('renders link with correct accessibility and tracking attributes', () => {
    render(<ContactUsSection {...props} />);

    const link = screen.getByRole('link', {
      name: 'Contact us'
    });

    expect(link).toHaveAttribute('target', '_blank');
    expect(link).toHaveAttribute('rel', 'noreferrer noopener');
    expect(link).toHaveAttribute('data-tracking-type', 'Outbound');
    expect(link).toHaveAttribute('data-tracking-target', 'https://www.gov.uk/contact-hmrc');
  });
});
