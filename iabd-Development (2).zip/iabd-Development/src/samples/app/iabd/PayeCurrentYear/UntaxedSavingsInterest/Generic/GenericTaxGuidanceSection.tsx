interface Props {
  heading: string;
  paragraphs: readonly string[];
}

const GenericTaxGuidanceSection = ({ heading, paragraphs }: Props) => (
  <>
    <h2 className='govuk-heading-m'>{heading}</h2>

    {paragraphs.map(paragraph => (
      <p key={paragraph} className='govuk-body'>
        {paragraph}
      </p>
    ))}
  </>
);

export default GenericTaxGuidanceSection;
