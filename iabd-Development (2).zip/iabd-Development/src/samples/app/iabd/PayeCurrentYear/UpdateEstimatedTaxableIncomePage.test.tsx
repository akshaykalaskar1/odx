import React from 'react';
import { act, cleanup, fireEvent, screen } from '@testing-library/react';
import { renderHook } from '@testing-library/react-hooks';
import '@testing-library/jest-dom';
import UpdateEstimatedTaxableIncomePage from './UpdateEstimatedTaxableIncomePage';
import { AnalyticsConfigProvider } from 'hmrc-odx-features-and-functions';
import { mockNavigate } from '../../../../../tests/mocks/routerMocks';
import renderWithRouter from '../../../../../tests/utils/renderWithRouter';
import { mockGetSdkConfigWithBasepath } from '../../../../../tests/mocks/getSdkConfigMock';
import useHMRCExternalLinks from '../../../../components/helpers/hooks/HMRCExternalLinks';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: () => mockNavigate
}));

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-odx-features-and-functions', () => {
  const featuresNFMock = jest.requireActual('hmrc-odx-features-and-functions');
  return {
    __esModule: true,
    ...featuresNFMock,
    withPageTracking: (Component: any) => Component
  };
});

window.scrollTo = jest.fn();

const mockApiCallback = jest.fn();
const handleNavClick = jest.fn();

describe('UpdateEstimatedTaxableIncomePage', () => {
  afterEach(cleanup);

  beforeEach(async () => {
    handleNavClick.mockClear();

    mockGetSdkConfigWithBasepath();

    const { result } = renderHook(() => useHMRCExternalLinks());

    await act(async () => {
      result.current.referrerURL = 'https://www.staging.tax.service.gov.uk/';
      result.current.hmrcURL = 'https://www.staging.tax.service.gov.uk/';
    });
  });

  const props = {
    employerName: 'Aldi',
    estimatedPay: '202',
    tesUrl: '/mockincome',
    handleNavClick
  };

  const getComponent = (overrideProps = {}) => (
    <AnalyticsConfigProvider apiCallback={mockApiCallback}>
      <UpdateEstimatedTaxableIncomePage {...props} {...overrideProps} />
    </AnalyticsConfigProvider>
  );

  test('should render content when page is loaded', async () => {
    await act(async () => {
      renderWithRouter(getComponent());
    });

    expect(screen.getByText('UPDATE_YOUR_ESTIMATED_PAY')).toBeInTheDocument();
    expect(screen.getByText(/Aldi/)).toBeInTheDocument();
    expect(screen.getByText(/£202.00/)).toBeInTheDocument();
    expect(screen.getByText('START_NOW')).toBeInTheDocument();
  });

  test('should navigate back when clicking the backlink', async () => {
    renderWithRouter(getComponent());

    const backLink = await screen.findByText('BACK');

    fireEvent.click(backLink);

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

  test('should navigate to tes url when clicking start now', async () => {
    renderWithRouter(getComponent());

    fireEvent.click(screen.getByText('START_NOW'));

    expect(handleNavClick).toHaveBeenCalledWith(expect.anything(), '/mockincome');
  });

  test('should display £0.00 when estimated pay is empty', async () => {
    renderWithRouter(
      getComponent({
        estimatedPay: ''
      })
    );

    const matchingElements = screen.getAllByText((_, element) => element?.textContent?.includes('£0.00') ?? false);

    expect(matchingElements.length).toBeGreaterThan(0);
  });
});
