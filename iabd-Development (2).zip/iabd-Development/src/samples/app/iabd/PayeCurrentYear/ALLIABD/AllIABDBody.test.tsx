import React from 'react';
import { render, screen, configure } from '@testing-library/react';
import '@testing-library/jest-dom';

import AllIABDBody from './AllIABDBody';

configure({ testIdAttribute: 'data-testid' });

jest.mock('./AllIABDTable', () => (props: any) => <div data-testid={`table-${props.type}`}>{props.type}</div>);

jest.mock('./MissingDetailsSection', () => () => <div data-testid='missing-links'>links</div>);

describe('AllIABDBody', () => {
  const config = [
    { type: 'incomes', key: 'income', showMoreInfo: true },
    { type: 'allowances', key: 'allowances', showMoreInfo: true },
    { type: 'benefits', key: 'benefits', showMoreInfo: false },
    { type: 'deductions', key: 'deductions', showMoreInfo: true }
  ] as const;

  const data = {
    income: [{}],
    allowances: [{}],
    benefits: [{}],
    deductions: [{}]
  };

  const props = {
    isDetailsAvailable: true,
    data: data as any,
    tableConfig: config,
    handleLinkClick: jest.fn(),
    handleMoreInformationClick: jest.fn()
  };

  test('renders tables and links', () => {
    render(<AllIABDBody {...props} />);

    expect(screen.getByTestId('table-incomes')).toBeInTheDocument();
    expect(screen.getByTestId('table-allowances')).toBeInTheDocument();
    expect(screen.getByTestId('table-benefits')).toBeInTheDocument();
    expect(screen.getByTestId('table-deductions')).toBeInTheDocument();

    expect(screen.getByTestId('missing-links')).toBeInTheDocument();
  });

  test('returns null when no data', () => {
    const { container } = render(<AllIABDBody {...props} isDetailsAvailable={false} />);

    expect(container.firstChild).toBeNull();
  });
});
