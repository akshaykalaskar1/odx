import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import AllIABDTable from './AllIABDTable';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('./config/iabdTableMetaCofig', () => ({
  getIABDTableMetaConfig: () => ({
    benefits: {
      title: 'Benefits Title',
      emptyText: 'No Benefits',
      showEmployment: true,
      hasFallback: false
    },
    incomes: {
      title: 'Income Title',
      emptyText: 'No Income',
      showEmployment: false,
      hasFallback: true
    },
    allowances: {
      title: 'Allowances Title',
      emptyText: 'No Allowances',
      showEmployment: false,
      hasFallback: true
    },
    deductions: {
      title: 'Deductions Title',
      emptyText: 'No Deductions',
      showEmployment: false,
      hasFallback: true
    }
  })
}));

jest.mock('../../../../../components/helpers/AllIABDLanding/AllIABDLandingUtils', () => ({
  getContentOnLanguageSelection: (content: any) => content?.[0] || null,
  getKey: () => 'test-key',
  getEmploymentName: (name: string) => name || ''
}));

jest.mock('../../../../../components/helpers/utils', () => ({
  formatCurrency: (val: number) => `£${val}`
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <div>{children}</div>,
  SummaryList: ({ children }: any) => <div>{children}</div>,
  SummaryListRow: ({ label, value, actions }: any) => (
    <div>
      <span>{label}</span>
      <span>{value}</span>
      {actions}
    </div>
  )
}));

describe('AllIABDTable', () => {
  const baseProps = {
    type: 'incomes' as const,
    handleLinkClick: jest.fn(),
    handleMoreInformationClick: jest.fn()
  };

  const createItem = (override = {}) => ({
    Amount: 100,
    Content: [{ Name: 'Test Item', Language: 'EN' }],
    TESLinks: [
      {
        Content: [
          {
            Name: 'Test Link',
            pyURLContent: 'http://example.com',
            HiddenText: 'hidden'
          }
        ]
      }
    ],
    ...override
  });

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('renders empty state when list is empty', () => {
    render(<AllIABDTable {...baseProps} list={[]} />);

    expect(screen.getByText('Income Title')).toBeInTheDocument();
    expect(screen.getByText('No Income')).toBeInTheDocument();
  });

  test('renders rows when list has data', () => {
    render(<AllIABDTable {...baseProps} list={[createItem()]} />);

    expect(screen.getByText('Test Item')).toBeInTheDocument();
    expect(screen.getByText('£100')).toBeInTheDocument();
  });

  test('renders link when TESLinks present', () => {
    render(<AllIABDTable {...baseProps} list={[createItem()]} />);

    expect(screen.getByText('Test Link')).toBeInTheDocument();
  });

  test('calls handleLinkClick when link clicked', () => {
    render(<AllIABDTable {...baseProps} list={[createItem()]} />);

    fireEvent.click(screen.getByText('Test Link'));

    expect(baseProps.handleLinkClick).toHaveBeenCalledWith('http://example.com');
  });

  test('calls fallback when URL is NA', () => {
    const item = createItem({
      TESLinks: [
        {
          Content: [
            {
              Name: 'Fallback Link',
              pyURLContent: 'NA',
              HiddenText: 'hidden'
            }
          ]
        }
      ]
    });
  });
});
