import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

import ALLIABDHeader from './ALLIABDPageHeader';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('hmrc-gds-react-components', () => ({
  Heading: ({ children }: any) => <div>{children}</div>,
  InsetText: ({ children }: any) => <div>{children}</div>
}));

describe('ALLIABDHeader', () => {
  test('renders detailed content when isDetailsAvailable is true', () => {
    render(<ALLIABDHeader isDetailsAvailable={true} />);

    expect(screen.getByText('OTHER_INCOMES_IABD')).toBeInTheDocument();

    expect(screen.getByText('LIST_SHOWS_ALL_PAY_AS_YOU_EARN')).toBeInTheDocument();

    expect(screen.getByText('AMOUNT_DO_NOT_ACCOUNT_PERSONAL_RELIEFS_1')).toBeInTheDocument();
    expect(screen.getByText('AMOUNT_DO_NOT_ACCOUNT_PERSONAL_RELIEFS_2')).toBeInTheDocument();
  });

  test('renders empty message when isDetailsAvailable is false', () => {
    render(<ALLIABDHeader isDetailsAvailable={false} />);

    expect(screen.getByText('OTHER_INCOMES_IABD')).toBeInTheDocument();

    expect(screen.getByText('NO_INCOME_OTHER_SOURCE')).toBeInTheDocument();
  });

  test('renders empty message when isDetailsAvailable is undefined', () => {
    render(<ALLIABDHeader />);

    expect(screen.getByText('NO_INCOME_OTHER_SOURCE')).toBeInTheDocument();
  });
});
