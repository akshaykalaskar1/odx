import React from 'react';
import AllIABDTable from './AllIABDTable';
import { IABDData, TableConfig } from './config/iabdTableConfig';
import MissingDetailLinksSection from './MissingDetailsSection';

interface Props {
  isDetailsAvailable: boolean;
  data: IABDData;
  tableConfig: readonly TableConfig[];
  handleLinkClick: (d: string) => void;
  handleMoreInformationClick: (d: string) => void;
}

const AllIABDBody: React.FC<Props> = ({ isDetailsAvailable, data, tableConfig, handleLinkClick, handleMoreInformationClick }) => {
  if (!isDetailsAvailable) return null;

  return (
    <div className='govuk-grid-row'>
      <div className='govuk-grid-column-three-quarters'>
        {tableConfig.map(({ type, key, showMoreInfo }) => (
          <AllIABDTable
            key={type}
            type={type}
            list={data[key]}
            handleLinkClick={handleLinkClick}
            handleMoreInformationClick={showMoreInfo ? handleMoreInformationClick : undefined}
          />
        ))}

        <MissingDetailLinksSection />
      </div>
    </div>
  );
};

export default AllIABDBody;
