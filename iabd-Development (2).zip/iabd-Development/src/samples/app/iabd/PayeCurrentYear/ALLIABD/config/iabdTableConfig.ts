import { CurrentListOBJ } from '../../PayeCurrentYearTypes';

export interface IABDData {
  benefits: CurrentListOBJ[];
  income: CurrentListOBJ[];
  allowances: CurrentListOBJ[];
  deductions: CurrentListOBJ[];
}

export type TableType = 'incomes' | 'allowances' | 'benefits' | 'deductions';

export interface TableConfig {
  type: TableType;
  key: keyof IABDData;
  showMoreInfo: boolean;
}

export const IABD_TABLE_CONFIG: readonly TableConfig[] = [
  { type: 'incomes', key: 'income', showMoreInfo: true },
  { type: 'allowances', key: 'allowances', showMoreInfo: true },
  { type: 'benefits', key: 'benefits', showMoreInfo: false },
  { type: 'deductions', key: 'deductions', showMoreInfo: true }
] as const;
