export type TableType = 'benefits' | 'incomes' | 'allowances' | 'deductions';

export interface TableMetaConfig {
  title: string;
  emptyText: string;
  showEmployment: boolean;
  hasFallback: boolean;
}

export const getIABDTableMetaConfig = (t: (key: string) => string): Record<TableType, TableMetaConfig> => ({
  benefits: {
    title: t('EMPLOYMENT_BENEFITS'),
    emptyText: t('NO_BENEFITS'),
    showEmployment: true,
    hasFallback: false
  },
  incomes: {
    title: t('OTHER_INCOME'),
    emptyText: t('NO_INCOME_FROM_OTHER'),
    showEmployment: false,
    hasFallback: true
  },
  allowances: {
    title: t('ALLOWANCES'),
    emptyText: t('NO_ALLOWANCES'),
    showEmployment: false,
    hasFallback: true
  },
  deductions: {
    title: t('DEDUCTIONS'),
    emptyText: t('NO_DEDUCTIONS'),
    showEmployment: false,
    hasFallback: true
  }
});
