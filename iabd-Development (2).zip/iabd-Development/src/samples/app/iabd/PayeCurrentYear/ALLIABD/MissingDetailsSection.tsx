import { useTranslation } from 'react-i18next';
import { appendLangParam } from '../../../../../components/helpers/utils';
import useHMRCExternalLinks from '../../../../../components/helpers/hooks/HMRCExternalLinks';
import { EventType, InteractionTracker } from 'hmrc-odx-features-and-functions';
import { callClientActionDataPage } from '../../eventTrackingConfig';
import { useNavigate } from 'react-router-dom';

const MissingDetailLinksSection = () => {
  const { t } = useTranslation();
  const { hmrcQAURL } = useHMRCExternalLinks();
  const navigate = useNavigate();

  async function handleClick(e: React.MouseEvent<HTMLAnchorElement>, target: string) {
    e.preventDefault();

    const interactionTracker = new InteractionTracker({
      url: null,
      apiCallback: callClientActionDataPage
    });

    await interactionTracker.logEvent(EventType.Outbound, `/${target}`, {});

    // In case of shuttered true above await will not complete and navigation will be prevented
    navigate(appendLangParam(`${hmrcQAURL}${target}`));
  }

  return (
    <div className='govuk-!-margin-top-9'>
      <h2 className='govuk-heading-m'>{t('MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_DETAILS_HEADER')}</h2>
      <div>
        <p className='govuk-body'>{t('MISSING_DETAILS_LINKS.IF_YOU_NOTICE_SOMETHING_MISSING')}</p>
        <ul className='govuk-list govuk-list--bullet'>
          <li>
            <a
              onClick={e => handleClick(e, 'submissions/new-form/tell-hmrc-about-your-tax-free-allowance')}
              className='govuk-link'
              href={appendLangParam(`${hmrcQAURL}submissions/new-form/tell-hmrc-about-your-tax-free-allowance`)}
            >
              {t('MISSING_DETAILS_LINKS.ADD_MISSING_ALLOWANCE_LINK')}
            </a>
          </li>
          <li>
            <a
              onClick={e => handleClick(e, 'digital-forms/form/tell-us-about-other-income/draft/guide')}
              className='govuk-link'
              href={appendLangParam(`${hmrcQAURL}digital-forms/form/tell-us-about-other-income/draft/guide`)}
            >
              {t('MISSING_DETAILS_LINKS.ADD_MISSING_INCOME_LINK')}
            </a>
          </li>
          <li>
            <a
              onClick={e => handleClick(e, 'submissions/new-form/tell-hmrc-about-your-investment-income/')}
              className='govuk-link'
              href={appendLangParam(`${hmrcQAURL}submissions/new-form/tell-hmrc-about-your-investment-income/`)}
            >
              {t('MISSING_DETAILS_LINKS.ADD_INVESTMENT_INCOME_LINK')}
            </a>
          </li>
          <li>
            <a
              onClick={e => handleClick(e, 'submissions/new-form/tell-hmrc-about-your-company-benefits/')}
              className='govuk-link'
              href={appendLangParam(`${hmrcQAURL}submissions/new-form/tell-hmrc-about-your-company-benefits/`)}
            >
              {t('MISSING_DETAILS_LINKS.ADD_COMPANY_BENEFIT_LINK')}
            </a>
          </li>
        </ul>
        <p className='govuk-body'>
          {t('MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_LINK_1')}{' '}
          <a
            onClick={e => handleClick(e, 'submissions/new-form/claim-personal-pension-tax-relief')}
            className='govuk-link'
            href={appendLangParam(`${hmrcQAURL}submissions/new-form/claim-personal-pension-tax-relief`)}
          >
            {t('MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_EXTERNAL_LINK')}
          </a>{' '}
          {t('MISSING_DETAILS_LINKS.ADD_PENSION_RELIEF_LINK_3')}
        </p>
      </div>
    </div>
  );
};

export default MissingDetailLinksSection;
