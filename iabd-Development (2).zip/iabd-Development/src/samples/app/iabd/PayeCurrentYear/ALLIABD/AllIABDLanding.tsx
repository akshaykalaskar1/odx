import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import i18next from 'i18next';
import { useNavigate } from 'react-router-dom';

import Button from '../../../../../components/BaseComponents/Button/Button';
import MainWrapperFull from '../../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import LoadingWrapper from '../../../../../components/helpers/LoadingSpinner/LoadingWrapper';
import setPageTitle from '../../../../../components/helpers/setPageTitleHelpers';

import ErrorMessage from '../../ErrorPage/errorMessage';
import AllIABDBody from './AllIABDBody';

import { withPageTracking } from 'hmrc-odx-features-and-functions';
import PAYE_ROUTES from '../../../../AppSelector/payeRoutes';

import { AllIABDDetails } from '../PayeCurrentYearTypes';
import { IABD_TABLE_CONFIG, IABDData } from './config/iabdTableConfig';
import ALLIABDHeader from './ALLIABDPageHeader';

interface Props {
  comingFromPage: string;
  handleLinkClick: (d: string) => void;
  handleMoreInformationClick: (d: string) => void;
}

const AllIABDLanding = ({ comingFromPage, handleLinkClick, handleMoreInformationClick }: Props) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const [data, setData] = useState<IABDData>({
    benefits: [],
    income: [],
    allowances: [],
    deductions: []
  });

  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const extractErrorMessage = (res: AllIABDDetails) => res?.pyErrors?.pyMessages?.[0]?.pyErrorMessage?.[0] ?? null;

  const fetchAllIABDData = async () => {
    setIsLoading(true);

    try {
      const res: AllIABDDetails = await PCore.getDataPageUtils().getPageDataAsync('D_IABDDetails', 'root');

      setError(extractErrorMessage(res) as unknown as string | null);

      const summary = res?.Customer?.TaxSummaryList?.[0];

      setData({
        benefits: summary?.CurrentBenefitsList ?? [],
        income: summary?.CurrentIncomeList ?? [],
        allowances: summary?.CurrentAllowanceList ?? [],
        deductions: summary?.CurrentDeductionsList ?? []
      });
    } catch (err) {
      console.error('Error fetching IABD:', err);
      setError('ERROR');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllIABDData();
  }, []);

  useEffect(() => {
    setPageTitle();
  }, [i18next.language]);

  const isDetailsAvailable = Object.values(data).some(list => list.length > 0);

  const handleBackClick = (e: React.MouseEvent) => {
    e.preventDefault();

    if (!comingFromPage) {
      navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.SUMMARY);
    } else {
      navigate(-1);
    }
  };

  return (
    <LoadingWrapper
      pageIsLoading={isLoading}
      spinnerProps={{
        bottomText: t('LOADING'),
        label: t('LOADING')
      }}
    >
      <>
        <Button variant='backlink' onClick={handleBackClick} attributes={{ type: 'link' }} />
        {error && <ErrorMessage />}
        {!error && (
          <MainWrapperFull title={t('VIEW_UPDATE_INFORMATION', { lng: 'en' })}>
            <ALLIABDHeader isDetailsAvailable={isDetailsAvailable} />
            <AllIABDBody
              isDetailsAvailable={isDetailsAvailable}
              data={data}
              tableConfig={IABD_TABLE_CONFIG}
              handleLinkClick={handleLinkClick}
              handleMoreInformationClick={handleMoreInformationClick}
            />
          </MainWrapperFull>
        )}
      </>
    </LoadingWrapper>
  );
};

export default withPageTracking(AllIABDLanding);
