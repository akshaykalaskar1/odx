import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import MainWrapperFull from '../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { fetchAnnualCoding, fetchPAYELanding, formatDate } from '../../../components/helpers/utils';
import { withPageTracking } from 'hmrc-odx-features-and-functions';
import { useOutletContext } from 'react-router-dom';
import { IabdOutletContext } from '../../AppSelector/type/routeTypes';
import DelayedErrorMessage from './ErrorPage/delayedErrorMessage';

interface LandingPageProps {
  redirectCurrentYearPage: any;
  handleLinkClick: any;
  userFullName?: string;
  redirectAnnualCodingTemplatePage: (params: { templateValue: string; pageName: string }) => void;
}

const LandingPage = (props: LandingPageProps) => {
  const { redirectCurrentYearPage, handleLinkClick, userFullName, redirectAnnualCodingTemplatePage } = props;

  const { t } = useTranslation();

  const { setCustomerDetails, customerDetails, setAccessGroup, accessGroup, setAnnualCodingData, annualCodingData, setTaxYearStartDate } =
    useOutletContext<IabdOutletContext>();

  const isAnnualCodingAvailable: boolean = annualCodingData?.Customer?.TaxSummaryList?.[0]?.AnnualCodingAvailable?.toLowerCase() === 'yes';

  const annualCodingTemplateValue = annualCodingData?.Customer?.TaxSummaryList?.[0]?.pyTemplateDataField || '';

  const taxYearStartDateAnnualCoding: string = formatDate(annualCodingData?.Customer?.TaxSummaryList?.[0]?.TaxYearStartDate);

  const annualCodingCIPAttributes =
    annualCodingTemplateValue === ''
      ? {
          'data-tracking-type': 'Outbound',
          'data-tracking-target': `/check-income-tax/income-tax-comparison`
        }
      : {};

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, path: string) => {
    e.preventDefault();
    handleLinkClick(path);
  };

  const getAnnualCodingCIPPageName = (templateValue: string) => {
    switch (templateValue) {
      case 'CHECKYOURTAXCODE':
        return 'Check your tax code';
      case 'NOTAXCODECHANGE':
        return 'Income tax stays the same';
      default:
        return '';
    }
  };

  const handleAnnualCodingClick = (e: React.MouseEvent<HTMLAnchorElement, MouseEvent>, templateValue: string) => {
    e.preventDefault();
    if (templateValue) {
      const pageName = getAnnualCodingCIPPageName(templateValue);
      redirectAnnualCodingTemplatePage({ templateValue, pageName });
    } else {
      handleLinkClick('/check-income-tax/income-tax-comparison');
    }
  };

  async function fetchPAYELandingData() {
    try {
      const data = await fetchPAYELanding();
      if (data?.Customer) {
        setCustomerDetails(data?.Customer);
      }
      setAccessGroup(data?.pyAccessGroup);
    } catch (error) {
      console.log(error); // eslint-disable-line no-console
    }
  }

  async function fetchAnnualCodingData() {
    try {
      const data = await fetchAnnualCoding();

      setTaxYearStartDate(data?.Customer?.TaxSummaryList?.[0]?.TaxYearStartDate);
      setAnnualCodingData(data);
    } catch (error) {
      console.log(error); // eslint-disable-line no-console
    }
  }

  useEffect(() => {
    if (!customerDetails) fetchPAYELandingData();
    if (!annualCodingData) fetchAnnualCodingData();
  }, []);

  if (accessGroup === 'PAYE_Dev:UnauthCitizen' || accessGroup === 'PAYE:UnauthCitizen') {
    return <DelayedErrorMessage accessGroupMsg showInstantly />;
  }

  return (
    <MainWrapperFull title={t('PAY_AS_YOU_EARN', { lng: 'en' })}>
      <div className='govuk-grid-row'>
        <div className='govuk-grid-column-two-thirds'>
          <span className='govuk-caption-xl '>{userFullName}</span>
          <h1 className='govuk-heading-xl govuk-!-margin-bottom-0'>{t('PAY_AS_YOU_EARN')}</h1>
          <div className='govuk-inset-text govuk-!-margin-top-2 govuk-!-margin-bottom-6'>
            <a
              className='govuk-link'
              href='#'
              data-tracking-type='Outbound'
              data-tracking-target='/save-your-national-insurance-number'
              onClick={e => handleNavClick(e, '/save-your-national-insurance-number')}
              rel='noopener norefferer noreferrer'
            >
              {t('VIEW_AND_SAVE_YOUR_NATIONAL_INSURANCE_NUMBER')}
            </a>
          </div>
          <h2 className='govuk-heading-m govuk-!-margin-top-4 govuk-!-margin-bottom-1'>{t('PAYE_SERVICES')}</h2>
          <ul className='hmrc-card__container'>
            {isAnnualCodingAvailable && (
              <li className='hmrc-card'>
                <h3 className='hmrc-card__heading'>
                  <a
                    href='#'
                    {...annualCodingCIPAttributes}
                    onClick={e => handleAnnualCodingClick(e, annualCodingTemplateValue)}
                    className='govuk-link govuk-link--no-underline'
                  >
                    {`${t('CHECK_NEXT_TAX_YEAR')} ${taxYearStartDateAnnualCoding}`}
                    <span className='hmrc-card__chevron' aria-hidden='true'></span>
                  </a>
                </h3>
              </li>
            )}
            <li className='hmrc-card'>
              <h3 className='hmrc-card__heading'>
                <a
                  href='#'
                  onClick={e => {
                    e.preventDefault();
                    redirectCurrentYearPage();
                  }}
                  className='govuk-link govuk-link--no-underline'
                >
                  {t('CHECK_CURRENT_TAX_YEAR')}
                  <span className='hmrc-card__chevron' aria-hidden='true'></span>
                </a>
              </h3>
            </li>
            <li className='hmrc-card'>
              <h3 className='hmrc-card__heading'>
                <a
                  href='#'
                  data-tracking-type='Outbound'
                  data-tracking-target='/check-income-tax/income-tax-history'
                  onClick={e => handleNavClick(e, '/check-income-tax/income-tax-history')}
                  className='govuk-link govuk-link--no-underline'
                >
                  {t('VIEW_EMPLOYMENT_PENSION_INCOME_TAX_HISTORY')}
                  <span className='hmrc-card__chevron' aria-hidden='true'></span>
                </a>
              </h3>
            </li>
          </ul>
        </div>
      </div>
    </MainWrapperFull>
  );
};

export default withPageTracking(LandingPage);
