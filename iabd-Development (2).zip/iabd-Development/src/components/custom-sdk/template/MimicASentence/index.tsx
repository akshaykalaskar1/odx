export { default } from './MimicASentence';
