import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import SignoutConfirmationPage from './SignoutConfirmationPage';
import PAYE_ROUTES from '../../../samples/AppSelector/payeRoutes';

const mockNavigate = jest.fn();

jest.mock('react-router-dom', () => ({
  __esModule: true,
  useNavigate: () => mockNavigate
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (k: string) => k })
}));

jest.mock('../../BaseComponents/Button/Button', () => ({
  __esModule: true,
  // Add explicit type to satisfy react/button-has-type
  default: ({ onClick, attributes, children }: any) => (
    <button type='button' onClick={onClick} {...attributes}>
      {children}
    </button>
  )
}));

jest.mock('../../BaseComponents/MainWrapper', () => ({
  __esModule: true,
  default: ({ title, children }: any) => (
    <div className='govuk-width-container'>
      <div data-testid='MainWrapper-title'>{String(title)}</div>
      {children}
    </div>
  )
}));

jest.mock('../AppHeader', () => ({
  __esModule: true,
  default: () => <div>AppHeader</div>
}));

jest.mock('../AppFooter', () => ({
  __esModule: true,
  default: () => <div>AppFooter</div>
}));

jest.mock('../LanguageToggle', () => ({
  __esModule: true,
  default: () => <div>LanguageToggle</div>
}));

jest.mock('../../helpers/setPageTitleHelpers', () => ({
  __esModule: true,
  default: jest.fn()
}));

describe('SignoutConfirmationPage (BDD Style)', () => {
  let originalLocation: Location;

  beforeAll(() => {
    originalLocation = window.location;
    delete (window as any).location;
    (window as any).location = { href: '' } as any;
  });

  afterAll(() => {
    (window as any).location = originalLocation;
  });

  afterEach(() => {
    jest.resetAllMocks();
    jest.spyOn(Storage.prototype, 'getItem').mockRestore();
  });

  describe('Given the user is signed out', () => {
    describe('When the signout confirmation page loads', () => {
      it('Then it shows header, footer, language toggle, heading and Sign in button', () => {
        jest.spyOn(Storage.prototype, 'getItem').mockReturnValue(null);

        render(<SignoutConfirmationPage />);

        expect(screen.getByText('AppHeader')).toBeInTheDocument();
        expect(screen.getByText('AppFooter')).toBeInTheDocument();
        expect(screen.getByText('LanguageToggle')).toBeInTheDocument();
        expect(screen.getByRole('heading', { name: 'FOR_SECURITY_WE_SIGNED_YOU_OUT', level: 1 })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'SIGN_IN' })).toBeInTheDocument();
      });
    });
  });

  describe('Given the page is loaded', () => {
    describe('When the component mounts', () => {
      it('Then it calls setPageTitle', async () => {
        const setPageTitle = (await import('../../helpers/setPageTitleHelpers'))
          .default as jest.Mock;
        jest.spyOn(Storage.prototype, 'getItem').mockReturnValue('en-GB');

        render(<SignoutConfirmationPage />);

        expect(setPageTitle).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('Given the Sign in button is visible', () => {
    describe('When the user clicks Sign in', () => {
      it('Then the user is redirected to the landing page', () => {
        jest.spyOn(Storage.prototype, 'getItem').mockReturnValue('cy-GB');

        render(<SignoutConfirmationPage />);
        const signInBtn = screen.getByRole('button', { name: 'SIGN_IN' });
        fireEvent.click(signInBtn);

        expect(mockNavigate).toHaveBeenCalledWith(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING, {
          replace: true
        });
      });
    });
  });
});
