import { useEffect, useRef, useState } from 'react';
import MainWrapper from '../../BaseComponents/MainWrapper';
import ParsedHTML from '../../helpers/formatters/ParsedHtml';
import setPageTitle from '../../helpers/setPageTitleHelpers';
import fetchSubmissionSummary from '../../../components/helpers/submissionSummaryService';
import { getCurrentLang } from '../../../components/helpers/utils';

interface SummaryPageProps {
  caseId: string;
}

const SummaryPage = ({ caseId }: SummaryPageProps) => {
  const [summaryPageContent, setSummaryPageContent] = useState<any>({
    content: null,
    title: null,
    banner: null
  });
  const summaryDataRef = useRef<any[]>([]);
  const currentLang = getCurrentLang();

  useEffect(() => {
    setPageTitle();
  }, [summaryPageContent.Title, summaryPageContent.Banner]);

  useEffect(() => {
    setSummaryPageContent({ content: null, title: null, banner: null });

    fetchSubmissionSummary({
      PCore,
      caseId,
      currentLang
    })
      .then(({ summaryData, filteredData }) => {
        summaryDataRef.current = summaryData;
        setSummaryPageContent(filteredData);
      })
      .catch(() => {
        // optionally handle error silently or show UI error
      });
  }, [caseId, currentLang]);
  return (
    <MainWrapper title={summaryPageContent.Banner && summaryPageContent.Banner !== '' ? summaryPageContent.Banner : summaryPageContent.Title}>
      {summaryPageContent.Banner && summaryPageContent.Banner !== '' ? (
        <div className='govuk-panel govuk-panel--confirmation govuk-!-margin-bottom-7'>
          <h1 className='govuk-panel__title'>{summaryPageContent.Banner}</h1>
        </div>
      ) : (
        <h1 className='govuk-heading-l'>{summaryPageContent.Title}</h1>
      )}

      <div>
        <ParsedHTML htmlString={summaryPageContent.Content} />
      </div>
    </MainWrapper>
  );
};

export default SummaryPage;
