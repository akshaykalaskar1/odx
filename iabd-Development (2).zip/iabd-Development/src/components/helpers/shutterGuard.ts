import { fetchShutterStatus } from './shutterLookup';
import PAYE_ROUTES from '../../samples/AppSelector/payeRoutes';

export const SHUTTER_DETECTED_EVENT = 'SHUTTER_DETECTED';

interface ShutterGuardConfig {
  featureID: string;
  featureType?: string;
  dataViewName?: string;
  checkDebounceMs?: number;
}

const ALLOWED_DATA_VIEWS_WHEN_SHUTTERED = ['D_AuthServiceLogout', 'D_PAYERedirectURL'];

let shutterConfig: Required<ShutterGuardConfig>;
let lastCheck = 0;
let lastResult = false;
let shutterCheckPromise: Promise<boolean> | null = null;
let isShutterGuardInstalled = false;

function publishShutterDetected(): void {
  PCore.getPubSubUtils().publish(SHUTTER_DETECTED_EVENT);
}

export async function getLatestShutterStatus(): Promise<boolean> {
  if (!shutterConfig) {
    throw new Error('ShutterGuard must be installed before checking status');
  }

  const now = Date.now();

  if (now - lastCheck < shutterConfig.checkDebounceMs) {
    return lastResult;
  }

  if (shutterCheckPromise) {
    return shutterCheckPromise;
  }

  shutterCheckPromise = (async () => {
    try {
      lastResult = await fetchShutterStatus({
        featureID: shutterConfig.featureID,
        featureType: shutterConfig.featureType,
        dataViewName: shutterConfig.dataViewName
      });

      lastCheck = Date.now();

      return lastResult;
    } finally {
      shutterCheckPromise = null;
    }
  })();

  return shutterCheckPromise;
}

function configureXHRInterceptor(): void {
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method: string, url: string, async?: boolean, username?: string | null, password?: string | null) {
    (
      this as XMLHttpRequest & {
        __shutterUrl?: string;
      }
    ).__shutterUrl = url;

    return originalOpen.call(this, method, url, async, username, password);
  };

  XMLHttpRequest.prototype.send = function (body?: Document | XMLHttpRequestBodyInit | null) {
    const xhr = this as XMLHttpRequest & {
      __shutterUrl?: string;
    };

    const url = xhr.__shutterUrl ?? '';
    const isShutterLookup = url.includes('data_views') && url.includes(shutterConfig.dataViewName);
    const isPegaApi = url.includes('/api/application/');
    const onShutterPage = window.location.pathname.endsWith(PAYE_ROUTES.SHUTTER);
    const isAllowedDataView = ALLOWED_DATA_VIEWS_WHEN_SHUTTERED.some(request => url.includes(request));
    const isAllowedWhenShuttered = isAllowedDataView || (url.includes('D_OnClientAction') && onShutterPage);

    if (isShutterLookup) {
      return originalSend.call(xhr, body);
    }

    if (!isPegaApi) {
      return originalSend.call(xhr, body);
    }

    if (isAllowedWhenShuttered) {
      return originalSend.call(xhr, body);
    }

    getLatestShutterStatus()
      .then(shuttered => {
        if (shuttered) {
          publishShutterDetected();

          console.warn(`Shutter blocked request: ${url}`);

          xhr.abort();
          return;
        }

        originalSend.call(xhr, body);
      })
      .catch(error => {
        console.error('Shutter check failed, allowing request', error);

        originalSend.call(xhr, body);
      });
  };
}

export function installShutterGuard(config: ShutterGuardConfig): void {
  if (isShutterGuardInstalled) {
    return;
  }

  shutterConfig = {
    featureType: 'Service',
    dataViewName: 'D_ShutterLookup',
    checkDebounceMs: 3000,
    ...config
  };

  configureXHRInterceptor();

  isShutterGuardInstalled = true;
}
