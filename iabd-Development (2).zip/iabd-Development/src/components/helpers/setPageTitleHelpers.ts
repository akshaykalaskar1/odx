import i18n, { t } from 'i18next';

/*
  setPageTitle()
  sets h1 on the page as the title in following pattern
  `<<pageHeading>> - <<serviceName>> - GOV.UK`
  accepts optional param errorProperty and appends 'Error :' if there is error on page
*/

let previousTitle = '';
let isFirstLoad = true;
const useLiveRegion = true;

export default function setPageTitle(errorProperty = false, skipInterval = false) {
  // In case where there may be multiple H1s on page (e.g. breifly may have pega part of page and confirmation screen shown together)
  // set up an interval to keep checking until we have only one H1, and then set the page title with the remaining H1
  // This assumes we follow the best practice to only display one h1 on the page, and simply works around the 'gap' when our main
  // page updates to hide/show components.
  if (!skipInterval && (document.getElementsByTagName('h1').length > 1 || document.getElementsByTagName('h1')[0] === undefined)) {
    const setPageTitleInterval = setInterval(() => {
      if (document.getElementsByTagName('h1').length === 1) {
        clearInterval(setPageTitleInterval);
        setPageTitle(errorProperty, true);
      }
    }, 200);
  }

  const pageHeading = i18n.t(document.getElementsByTagName('h1')[0]?.innerText);

  // Scope to fetch serviceName dynamically from here
  // TODO fetch serviceName dynamically
  const serviceName = i18n.t('PAYE_SERVICE');
  const errorPrefix = errorProperty ? `${t('ERROR')}: ` : '';
  const title = pageHeading ? `${errorPrefix}${pageHeading} - ${serviceName} - GOV.UK` : `${serviceName} - GOV.UK`;

  if (!pageHeading) {
    return;
  }

  const titleChanged = previousTitle !== title;

  if (!titleChanged) {
    return;
  }

  document.title = title;
  previousTitle = title;

  // Skip aria-live if disabled
  if (!useLiveRegion) {
    return;
  }

  // Announce title changes for screen readers during SPA navigation
  let announcer = document.getElementById('page-change-announcer');
  if (!announcer) {
    announcer = document.createElement('div');
    announcer.id = 'page-change-announcer';
    announcer.className = 'govuk-visually-hidden';
    announcer.setAttribute('aria-atomic', 'true');
    document.body.appendChild(announcer);
  }

  const liveMode = isFirstLoad ? 'polite' : 'assertive';
  const delay = isFirstLoad ? 300 : 150;
  announcer.setAttribute('aria-live', liveMode);

  if (isFirstLoad) {
    isFirstLoad = false;
  }

  announcer.textContent = '';
  setTimeout(() => {
    announcer.textContent = title;
  }, delay);
}
