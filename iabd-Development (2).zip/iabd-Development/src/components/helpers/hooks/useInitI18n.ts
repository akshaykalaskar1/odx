import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import i18n from 'i18next';
import Backend from 'i18next-http-backend';
import { initReactI18next } from 'react-i18next';

export const useInitI18n = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const urlLang = params.get('lang');

    const initialLang = urlLang || sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';

    if (urlLang) {
      params.delete('lang');
      navigate(location.pathname, { replace: true });
      sessionStorage.setItem('rsdk_locale', urlLang);
    }

    i18n
      .use(Backend)
      .use(initReactI18next)
      .init({
        lng: initialLang,
        /* translation file path */
        backend: { loadPath: `assets/i18n/{{lng}}.json` },
        fallbackLng: 'en',
        debug: false,
        returnNull: false,
        react: { useSuspense: false }
      })
      .finally(() => setLoaded(true));
  }, [location.search]);

  return loaded;
};

export default useInitI18n;
