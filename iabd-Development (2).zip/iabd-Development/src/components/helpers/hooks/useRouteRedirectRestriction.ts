import { useEffect } from 'react';
import { useLocation, useNavigate, useOutletContext } from 'react-router-dom';
import PAYE_ROUTES from '../../../samples/AppSelector/payeRoutes';
import { IabdOutletContext, PayeRouteState } from '../../../samples/AppSelector/type/routeTypes';

const PAGE_REFRESHED = 'page_refreshed';

const useRouteRedirectRestriction = <TProps extends object>(mapProps: (args: { outlet: IabdOutletContext; state: PayeRouteState }) => TProps) => {
  const outlet = useOutletContext<IabdOutletContext>();
  const location = useLocation();
  const navigate = useNavigate();

  const state = (location.state || {}) as PayeRouteState;

  useEffect(() => {
    const handleBeforeUnload = () => {
      sessionStorage.setItem(PAGE_REFRESHED, 'true');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  useEffect(() => {
    const allowedRedirections = Object.values(PAYE_ROUTES.ALLOWED_REDIRECTION) as string[];
    const isAllowedRedirect = allowedRedirections.includes(location.pathname);

    const isPageRefresh = sessionStorage.getItem(PAGE_REFRESHED) === 'true';

    if (isPageRefresh) {
      sessionStorage.removeItem(PAGE_REFRESHED);
      if (!isAllowedRedirect) {
        navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING, {
          replace: true
        });
      }
    }
  }, [location.pathname]);

  return mapProps({ outlet, state });
};

export default useRouteRedirectRestriction;
