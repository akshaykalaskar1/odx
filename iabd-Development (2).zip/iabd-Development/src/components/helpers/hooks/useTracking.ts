import { useCallback } from 'react';

export interface TrackingDataType {
  payload?: Record<string, unknown>;
}

export default function useTracking() {
  const trackEvent = useCallback((event: TrackingDataType) => {
    try {
      const trackingData: any = {
        ...event.payload
      };

      const options = {
        invalidateCache: true
      };

      PCore.getDataPageUtils().getPageDataAsync('D_ClientAction', 'root', { ...trackingData }, options);
    } catch (error) {
      console.error('CIP DPage Error:', error);
    }
  }, []);
  return { trackEvent };
}
