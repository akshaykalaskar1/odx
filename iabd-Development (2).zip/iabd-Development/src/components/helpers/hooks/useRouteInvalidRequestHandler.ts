import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import PAYE_ROUTES from '../../../samples/AppSelector/payeRoutes';

const PAGE_REFRESHED = 'page_refreshed';
const PRE_SHUTTER_ROUTE_KEY = 'preShutterRoute';

const useRouteInvalidRequestHandler = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const restrictedRedirections = Object.values(PAYE_ROUTES.RESTRICTED_REDIRECTION) as string[];
  const isRestrictedRedirect = restrictedRedirections.includes(location.pathname);
  if ((!location.state || Object.keys(location.state).length === 0) && isRestrictedRedirect) {
    navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING);
  }

  useEffect(() => {
    const handleBeforeUnload = () => {
      sessionStorage.setItem(PAGE_REFRESHED, 'true');
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  useEffect(() => {
    const allowedRedirections = Object.values(PAYE_ROUTES.ALLOWED_REDIRECTION) as string[];
    const isAllowedRedirect = allowedRedirections.includes(location.pathname);

    const isPageRefresh = sessionStorage.getItem(PAGE_REFRESHED) === 'true';

    if (isPageRefresh) {
      sessionStorage.removeItem(PAGE_REFRESHED);

      const preShutterRoute = sessionStorage.getItem(PRE_SHUTTER_ROUTE_KEY);

      if (preShutterRoute) {
        sessionStorage.removeItem(PRE_SHUTTER_ROUTE_KEY);

        navigate(preShutterRoute, {
          replace: true
        });

        return;
      }
      if (!isAllowedRedirect) {
        navigate(PAYE_ROUTES.ALLOWED_REDIRECTION.LANDING, {
          replace: true
        });
      }
    }
  }, [location.pathname, navigate]);
};

export default useRouteInvalidRequestHandler;
