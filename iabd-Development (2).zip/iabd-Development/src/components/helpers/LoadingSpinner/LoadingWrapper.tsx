import React, { ReactElement } from 'react';
import LoadingSpinner, { LoadingSpinnerProps } from './LoadingSpinner';

interface LoadingWrapperProps {
  pageIsLoading: boolean;
  spinnerProps: LoadingSpinnerProps;
  children: ReactElement;
}

const LoadingWrapper = ({ pageIsLoading, spinnerProps, children }: LoadingWrapperProps) => {
  return (
    <main className='govuk-main-wrapper govuk-main-wrapper--l' role='main' id='main-content'>
      <div aria-live='polite' aria-busy={pageIsLoading ? 'true' : 'false'}>
        {pageIsLoading ? (
          <LoadingSpinner {...spinnerProps} />
        ) : (
          children
        )}
      </div>
    </main>
  )
};

export default LoadingWrapper;
