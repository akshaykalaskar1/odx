import { useEffect, useState, useRef } from 'react';
import { Input, FieldValueList, Text as CosmosText, EmailDisplay, PhoneDisplay, URLDisplay } from '@pega/cosmos-react-core';

import handleEvent from './event-utils';
import StatusWorkRenderer from './StatusWork.jsx';
import { suggestionsHandler } from './suggestions-handler';

import StyledHmrcOdxGdsTextPresentationWrapper from './styles';
import ReadOnlyValue from '../../../BaseComponents/ReadOnlyValue/ReadOnlyValue';
import GDSConstellationCheckAnswers from '../../../BaseComponents/CheckAnswer/constellationGDS.tsx';
import { checkStatus } from '../../../helpers/utils';

const formatExists = formatterVal => {
  const formatterValues = ['TextInput', 'WorkStatus', 'RichText', 'Email', 'Phone', 'URL', 'Operator'];
  return formatterValues.includes(formatterVal);
};

const textFormatter = (formatter, value) => {
  switch (formatter) {
    case 'TextInput':
      return value;
    case 'Email':
      return <EmailDisplay value={value} displayText={value} variant='link' />;
    case 'Phone':
      return <PhoneDisplay value={value} variant='link' />;
    case 'URL':
      return <URLDisplay target='_blank' value={value} displayText={value} variant='link' />;
    default:
      return value;
  }
};

const formatNino = val =>
  val
    ?.toString()
    .toUpperCase()
    .replace(/[^\w\s]/gi, '')
    .replace(/\s/g, '')
    .replace(/(.{2})/g, '$1 ')
    .trim();

const formatFullTrim = val => val?.toString().replace(/\s+/g, '');

const formatPartTrim = val =>
  val
    ?.toString()
    .replace(/\s{2,}/g, ' ')
    .trim();

const formatTrimCaps = val => val?.toString().replace(/\s+/g, '').toUpperCase();

const formatCurrency2DP = val => {
  const number = parseFloat(String(val).replace(/[^\d.-]/g, ''));
  if (Number.isNaN(number)) return val;
  return `£${number.toLocaleString('en-GB', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
};

const HmrcOdxGdsTextPresentation = props => {
  const {
    getPConnect,
    placeholder,
    validatemessage,
    label,
    hideLabel,
    helperText,
    testId,
    fieldMetadata,
    additionalProps,
    displayMode,
    displayAsStatus,
    variant,
    hasSuggestions,
    isTableFormatter,
    enableAdditionalInformation,
    GDSPresentationType
  } = props;

  const { formatter } = props;

  const pConn = getPConnect();
  const actions = pConn.getActionsApi();
  const propName = pConn.getStateProps().value;

  const maxLength = fieldMetadata?.maxLength;
  const fieldDescription = fieldMetadata?.description;

  const hasValueChange = useRef(false);

  let { value, readOnly, required, disabled } = props;

  [readOnly, required, disabled] = [readOnly, required, disabled].map(prop => prop === true || (typeof prop === 'string' && prop === 'true'));

  const [inputValue, setInputValue] = useState(value);
  const [status, setStatus] = useState(hasSuggestions ? 'pending' : undefined);

  useEffect(() => setInputValue(value), [value]);

  useEffect(() => {
    if (validatemessage !== '') {
      setStatus('error');
    }
    if (hasSuggestions) {
      setStatus('pending');
    } else if (!hasSuggestions && status !== 'success') {
      setStatus(validatemessage !== '' ? 'error' : undefined);
    }
  }, [validatemessage, hasSuggestions, status]);

  let formattedValue;

  switch (GDSPresentationType) {
    case 'fulltrim':
      formattedValue = formatFullTrim(value);
      break;
    case 'parttrim':
      formattedValue = formatPartTrim(value);
      break;
    case 'trimcaps':
      formattedValue = formatTrimCaps(value);
      break;
    case 'currency2dp':
      formattedValue = formatCurrency2DP(value);
      break;
    case 'nino':
      formattedValue = formatNino(value);
      break;
    default:
      formattedValue = value ?? '';
  }

  const inprogressStatus = checkStatus();

  const gdsStatuses = [
    'PENDING-INVESTIGATION',
    'RESOLVED-COMPLETED',
    'PENDING-TECH REVIEW',
    'PENDING-BANKRUPTCYINVESTIGATION',
    'PENDING-EXPATINVESTIGATION',
    'PENDING-WELSHINVESTIGATION'
  ];

  if (gdsStatuses.includes(inprogressStatus?.toUpperCase())) {
    return <GDSConstellationCheckAnswers label={label} value={formattedValue} name={propName} placeholder={placeholder} helperText={helperText} />;
  }

  if (readOnly && !displayMode) {
    return <ReadOnlyValue label={label} value={formattedValue} />;
  }

  if (displayAsStatus) {
    const statusValue = StatusWorkRenderer({ value: formattedValue });

    if (!displayMode) {
      return (
        <StyledHmrcOdxGdsTextPresentationWrapper>
          <FieldValueList variant='stacked' data-testid={testId} fields={[{ id: 'status', name: label, value: statusValue }]} />
        </StyledHmrcOdxGdsTextPresentationWrapper>
      );
    }
  }

  if (displayMode === 'LABELS_LEFT' || displayMode === 'DISPLAY_ONLY') {
    let displayComp = formattedValue || '';

    if (isTableFormatter && formatExists(formatter)) {
      displayComp = textFormatter(formatter, formattedValue);
    }

    return (
      <StyledHmrcOdxGdsTextPresentationWrapper>
        <FieldValueList
          variant={hideLabel ? 'stacked' : variant}
          data-testid={testId}
          fields={[
            {
              id: '1',
              name: hideLabel ? '' : label,
              value: displayComp
            }
          ]}
        />
      </StyledHmrcOdxGdsTextPresentationWrapper>
    );
  }

  if (displayMode === 'STACKED_LARGE_VAL') {
    const isValDefined = formattedValue !== '';

    const val = isValDefined ? (
      <CosmosText variant='h1' as='span'>
        {formattedValue}
      </CosmosText>
    ) : (
      ''
    );

    return (
      <StyledHmrcOdxGdsTextPresentationWrapper>
        <FieldValueList
          variant='stacked'
          data-testid={testId}
          fields={[
            {
              id: '2',
              name: hideLabel ? '' : label,
              value: val
            }
          ]}
        />
      </StyledHmrcOdxGdsTextPresentationWrapper>
    );
  }

  const onResolveSuggestionHandler = accepted => {
    suggestionsHandler(accepted, pConn, setStatus);
  };

  return (
    <StyledHmrcOdxGdsTextPresentationWrapper>
      <Input
        {...additionalProps}
        type='text'
        label={label}
        labelHidden={hideLabel}
        info={validatemessage || helperText}
        data-testid={testId}
        value={inputValue}
        status={status}
        placeholder={placeholder}
        disabled={disabled}
        readOnly={readOnly}
        required={required}
        maxLength={maxLength}
        onChange={event => {
          if (hasSuggestions) {
            setStatus(undefined);
          }

          setInputValue(event.target.value);

          if (value !== event.target.value) {
            handleEvent(actions, 'change', propName, event.target.value);
            hasValueChange.current = true;
          }
        }}
        onBlur={event => {
          if ((!value || hasValueChange.current) && !readOnly) {
            handleEvent(actions, 'blur', propName, event.target.value);

            if (hasSuggestions) {
              pConn.ignoreSuggestion();
            }

            hasValueChange.current = false;
          }
        }}
        onResolveSuggestion={onResolveSuggestionHandler}
        {...(enableAdditionalInformation && fieldDescription
          ? {
              additionalInfo: {
                heading: label,
                content: fieldDescription
              }
            }
          : {})}
      />
    </StyledHmrcOdxGdsTextPresentationWrapper>
  );
};

export default HmrcOdxGdsTextPresentation;
