export { default } from './Assignment';
