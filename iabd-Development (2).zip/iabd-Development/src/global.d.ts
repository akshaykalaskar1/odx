interface Window {
  dataLayer: any[];
}
