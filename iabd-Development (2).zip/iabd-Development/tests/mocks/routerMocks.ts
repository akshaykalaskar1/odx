const mockGoTo = jest.fn();
export const mockNavigate = jest.fn();

export default mockGoTo;
