import React from 'react';
import { render, RenderOptions } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';

interface RenderWithRouterOptions extends RenderOptions {
  route?: string;
  state?: unknown;
}

const renderWithRouter = (
  componentPassed: React.ReactElement,
  { route = '/', state = {}, ...renderOptions }: RenderWithRouterOptions = {}
) => {
  return render(
    <MemoryRouter initialEntries={[{ pathname: route, state }]}>{componentPassed}</MemoryRouter>,
    renderOptions
  );
};

export default renderWithRouter;
