const config = {
  baseUrl: 'http://localhost:3502/',
  apps: {
    paye: {
      iabd: {
        username: 'Dummy user',
        email: 'zoe.clarke@example.com',
        vatdate: '2009-03-27',
        selfAssesment: 'Dummy SA ID',
        individual: {
          firstName: 'Zoe',
          lastName: 'Clarke',
          dateOfBirth: '1982-04-22',
          address: {
            line1: '5 Edgware Road',
            line2: 'Uxbridge',
            postcode: 'TS16 1PA'
          }
        },
        groubID: 'Dummy group ID',
        vatNumber: 'Dummy VAT number',
        fullname: 'Zoe Clarke',
        EORI: 'Dummy EORI number',
        nino: 'Dummy NINO number',
        taxId: 'Dummy tax ID'
      }
    }
  }
};

exports.config = config;
