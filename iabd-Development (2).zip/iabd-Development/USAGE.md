## Table of Contents
- [ODX-API Platform - Application Build Template](#odx-api-platform---application-build-template)
  - [Environments](#environments)
    - [Production Environments](#production-environments)
    - [NonProduction Environments](#nonproduction-environments)
  - [Deployment Configuration](#deployment-configuration)
      - [Automatic Jobs](#automatic-jobs)
      - [Manual Jobs](#manual-jobs)
  - [Infrastructure Configuration](#infrastructure-configuration)
    - [GitLab Runners](#gitlab-runners)
    - [Routing](#routing)
    - [Container Images](#container-images)
    - [Build Control Scripts](#build-control-scripts)
    - [Pipeline Templates](#pipeline-templates)
    - [Terraform Modules](#terraform-modules)
    - [Applications Group](#applications-group)
  - [Workflow for Setting Up and Managing a New Service](#workflow-for-setting-up-and-managing-a-new-service)
  - [Running and Deploying the Application](#running-and-deploying-the-application)
  - [Dynatrace SaaS Links](#dynatrace-saas-links)

# ODX-API Platform - Application Build Template

This is the template to use when creating a new application for build and hosting on the ODX-API platform.

The structure of an application repository should be a service-level group containing one or more application repositories (e.g., self-assessment/registry).

## Environments

Each branch in the repository will correspond to an environment in AWS, although deploying supporting infrastructure is optional. Care should be taken to remove infrastructure for temporary branches before removing the branch via a merge request or other mechanism, as once the branch is removed, the associated infrastructure cannot be managed via the pipelines.

**NOTE**: Branch names and other configuration mappings are case-sensitive.

### Production Environments

These environments are pre-configured on these branch names and will be deployed to the production AWS account. Use of the Preproduction and Staging environments are optional, and they can be deleted if not required. If any additional production environments are required, they must be requested as additional backend work will be required.

- **Production**
- **Preproduction**
- **Staging**

### NonProduction Environments

The Development branch is the default branch for the nonprod AWS account. Any other branches created will be deployed to the nonprod AWS account. Custom branch names should be kept short to prevent issues with the pipeline, as some dependent resources have name-length constraints. Branch names MUST not contain special characters except for hyphens.

- **Development (default)**
- Any other branch name, e.g., `dev-1` or `feature-newbutton`

## Deployment Configuration

Configure the `deployment-config.json` as required. The `Build_Command` will be used to build the application in the pipeline. This MUST NOT have any sub-commands that require human interaction, as these are not possible in a pipeline job.

**NOTE**: Any additional routing or Pega-side configuration is not part of this stack and will need to be managed separately.

Exploring the configuration file:

```shell
  # The service configuration is global and contains the application routing path and build command
  "Service": {
    # The Subpath is the host path following the URL for this service, excluding the environment
    "Subpath": "/services/service-name/path",
    # The Build_Command is the command which will be executed to perform the build in the pipeline
    "Build_Command": "npm run build:prod:ci"
    # The Lint_Command is the command to be used to perform lint testing on feature branches
    "Lint_Command": "npm run pipeline:lint"    
  },
  # This is the header for the environment, and must match the branch name (case sensitive)
  "Development": {
    # The high-level environment configuration
    "Environment": {
      # The static-ec2 type is a single host in AWS which will be re-used when a new build is created
      "Type": "static-ec2",
      # The internal routing type means the application will only be available from within the HMRC network
      "Routing" : "internal",
      # The Suffix defines the final component of the routing path in the URL and must start and end with /
      "Suffix": "/dev/"
    },
    # The infrastructure configuration
    "Infrastructure": {
      # The type of EC2 instance to deploy
      "EC2_Type": "c5a.large"
    },
    # The build-specific configuration
    "Build": {
      # The path to the sdk-config file which will be deployed with this build
      "SDK_Path": "sdk-configs/Development.json",
      # The sdkContentServerUrl will be added to the sdk-config file post-deployment
      "sdkContentServerUrl": "https://internal.dxapi-nonprod.ns2n.corp.hmrc.gov.uk/services/service-name/path/dev/"
      # The version is used for the for the appstyles.css and appbundle.js
      "Version": "1.0.0"
    }
  },
  # An example for Production, hpha-ec2 external routing
  "Production": {
    "Environment": {
      # Defines a highly available, blue/green strategy where hosts will be replaced when a new build is
      # deployed with zero downtime, and replaced weekly for security patching
      "Type": "hpha-ec2",
      # External routing type, means this will be accessible from the public Internet
      "Routing" : "external",
      "Suffix": "/"
    },
    "Infrastructure": {
      "EC2_Type": "c5a.large",
      # In hpha configuration, the number of hosts will scale with load - here you can define the minimum
      # and maximum number of hosts which will be deployed and scaled to. For increased resilience specify
      # a minimum host count of more than 1
      "EC2_Minimum_Hosts" : "1",
      "EC2_Maximum_Hosts" : "4"
    },
    "Build": {
      "SDK_Path": "sdk-configs/Production.json",
      "sdkContentServerUrl": "https://external.dxapi-prod.ns2p.corp.hmrc.gov.uk/services/service-name/path/"
      "Version": "1.0.0"
    }
  }
```

The `deployment-config.json` file is used to pass custom parameters to the build pipeline.
The service is global, but each other block is branch-specific.

| Parameter                                          | Description                                                                                                                | Example Values                              |
|----------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
| `.Service.Name`                                    | Short/Abbreviated name of the service.                                                                                     | `hicbc`, `chb`, `sa`                        |
| `.Service.Subpath`                                 | Host path following the URL.                                                                                               | `/self-assessment/make_an_appeal`, `/child-benefit/make_a_claim` |
| `"${CI_COMMIT_BRANCH}".Environment.Type`           | Type of environment to deploy. Choice of single static EC2 instance for non-production environments or highly available platforms for production environments. | `static-ec2`, `hpha-ec2`                   |
| `"${CI_COMMIT_BRANCH}".Environment.Routing`        | Routing stack to attach to. Choice of internal (Stride only) or external (Internet enabled)                                | `internal`, `external`                      |
| `"${CI_COMMIT_BRANCH}".Environment.Suffix`         | Optional host subpath following service name. Must always end with `/`                                                     | `/`, `/dev/`, `/feature/`                   |
| `"${CI_COMMIT_BRANCH}".Infrastructure.EC2_Type`    | Type of EC2 to deploy.                                                                                                     | `t3a.medium`, `t3a.large`, `c5a.large`, `c5a.2xlarge` |
| `"${CI_COMMIT_BRANCH}".Infrastructure.EC2_Minimum_Hosts` | Only applicable for `hpha` deployment types, the minimum hosts to be available.                                        | `1 (default)`, `2`                          |
| `"${CI_COMMIT_BRANCH}".Infrastructure.EC2_Maximum_Hosts` | Only applicable for `hpha` deployment types, the maximum hosts to be scaled to.                                          | `4`                                        |
| `"${CI_COMMIT_BRANCH}".Build.SDK_Path`             | Path to the configuration file to be used by the SDK to determine the deployment configuration.                          | `sdk-configs/Development.json`, `sdk-configs/Production.json` |
| `"${CI_COMMIT_BRANCH}".Build.sdkContentServerUrl`  | URL appended to the sdk-config file.                                                                                       | `https://internal.dxapi-prod.ns2n.corp.hmrc.gov.uk/services/service-name/path/dev/` |
| `"${CI_COMMIT_BRANCH}".Build.Version`              | Version of the service to be deployed.                                                                                     | `1.0.0`                                    |

---

### Automatic Jobs

When running the pipeline, the `build-control-scripts` job parses the configuration and performs validation. The output of this job should be checked on first push to ensure there are no errors or warnings present. Any validation errors will fail the pipeline job and prevent deployment.

The `app-build` job builds the application using the specified build command. The `dockerfile` job creates the container build configuration, and the `app-container` job builds and pushes the container image to Artifactory.

The `plan-infrastructure` job is a dry run and will inform you of any changes to infrastructure that will be made following your code push.
There is also a `plan-dynatrace` job which is also a dry run and will inform you of what will be configured within Dynatrace for the application monitoring.

### Manual Jobs

The `apply-infrastructure` job will build/modify AWS infrastructure as shown in the dry run and will then execute the `deploy-app` job to deploy the application code. In static-ec2 environment types, the `deploy-app` job will show all log output from the build and deployment process. For HPHA environments, it will monitor and provide feedback on the status of the blue/green deployment mechanism.
Along with the `deploy-app` the `deploy-dynatrace` will also run which will make the configuration changes as reported in the earlier `plan-dynatrace`.

The `destroy-infrastructure` and `destroy-dynatrace` jobs are optional and will remove any infrastructure from AWS for the current environment and the configuration from Dynatrace. This is important for housekeeping and to save costs when environments are not in use. Once an environment is destroyed, it can be re-built by creating a new pipeline for that branch or by re-running the `apply-infrastructure` then `deploy-dynatrace` and `deploy-app` jobs (in sequence) on the same pipeline.

## Infrastructure Configuration

The EC2 instances built will use the ECS-provided RHEL8.8 image and will have all mandatory software and security patches configured on boot, including Dynatrace SaaS monitoring in infrastructure only mode. This mode can be changed to full-stack if all cookies agreements are in place.
The Production environment will be attached to Dynatrace Production, PreProduction and Staging will be attached to Dynatrace PreProduction, and any other environments will be attached to Dynatrace Nonproduction.

**Infrastructure**  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg/cmdg-projects/cmdg-product-group-automation/odx-api/infrastructure))  
This group has these repositories:
- **GitLab Runners**: Defines the Docker builder and environment-specific GitLab Runners.
- **Routing**: Manages the static load balancer, Route53, and shared security groups for ingress and egress traffic.
- **Container Images**: Defines the build process for supporting container images.
- **HC Vault**: Used for setting the Hashicorp Vault policy and role up to be used by the hosts.

### GitLab Runners  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg/cmdg-projects/cmdg-product-group-automation/odx-api/infrastructure/gitlab-runners))  
This is a Terraform project linked to the cas-nelson-alm-seed host in CMDG ALM account 352278602812 via a GitLab Runner with the tag odx-api-seed. This configuration was manually applied. The EC2 Instance hosting the runner has an IAM profile allowing it to assume the build role in the ALM account where the runners are deployed. The account is linked to the ODX-API nonprod and prod accounts, enabling GitLab Runner EC2 instances to assume the build roles in both accounts for resource management.  
There are three types of GitLab Runners:
- **Terraform nonprod runner**: For Terraform pipeline jobs in nonprod account(s).
- **Terraform prod runner**: For Terraform pipeline jobs in prod account(s).
- **Docker builder instance**: For application and container builds (no IAM permissions).
The Terraform runners are small instance sizes since the jobs are not resource-intensive, while the Docker builder is larger to handle React application builds.

The EC2 instances are ephemeral and patched weekly, built from the central CMDG Launch Template/ASG Terraform module ([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg-public-repos/terraform-modules/generic/aws/lt-asg)).

### Routing  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg/cmdg-projects/cmdg-product-group-automation/odx-api/infrastructure/routing))  
This Terraform project deploys static routing resources for internal and external connectivity, including security groups and IAM. The resources deployed include:
- **IAM instance profile** for ODX-API EC2 instances for HC Vault integration.
- **TLS certificates** for Route53 records pointing to the load balancers.
- **Application Load Balancers** with default routing rules (404 error for non-matching paths).
- **Security Groups** for the ALBs, allowing traffic over HTTPS, as well as internal routing and health checks. External ALB allows traffic from anywhere; internal ALB only from CIDR range 10.0.0.0/8.
- **Static Security Groups** for EC2 Instances hosting web applications, with port 22 (SSH) access from ALM and bastion, and port 80 (HTTPS) access from the ALB.

The Terraform code integrates with HC Vault via JWT v2, using the odx-api-routing-role against the /hmrc/cas namespace and the cas-int_4 PKI engine for TLS certificate management.

### Container Images  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg/cmdg-projects/cmdg-product-group-automation/odx-api/infrastructure/container-images))  
This repository contains Dockerfile definitions for the container images used in the ODX-API platform. The images are stored in the ccg-dx-api-docker-local.artifactory.alm.corp.hmrc.gov.uk Artifactory repository. Each directory contains a build.sh script, a Dockerfile, and a README.md. The container images defined here include:
- **docker-dind**: Official Docker in Docker image for building application containers.
- **nginx**: Official nginx image with custom hardening for hosting web services.
- **node**: Official node image for building web applications.
- **ssh-runner**: Ubuntu-based image for CI pipelines accessing hosts via SSH.
- **terraform-runner**: Ubuntu-based image with Terraform and Vault CLIs for CI pipeline jobs.
- **traefik**: Official traefik image used to route the traffic to the nginx container.

### Build Control Scripts  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg-public-repos/scripts/odx-api-scripts/build-control-scripts))  
This repository contains the orchestration logic for building and deploying infrastructure. It includes:
- **invoke.sh**: A wrapper script invoking parse_config.sh, allowing future expansions and conditional/argument-based invocation.
- **data directory**: Contains a mappings.properties file, mapping Terraform variables to locations in deployment-config.json.
- **scripts directory**:
  - parse_config.sh: Reads the deployment-config.json based on mappings.properties and generates Terraform variables.
  - run_container.sh: Executes on remote machines for deploying applications.
  - hpha_monitor.sh: Monitors Auto Scaling Group deployments for blue/green deployments.
- **terraform directory**: Contains Terraform code for deploying the infrastructure, integrating with HC Vault, and handling host bootstrap.

### Pipeline Templates  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg-public-repos/pipeline-templates/odx-api-pipeline-templates))  
This repository defines common GitLab CI job stages, including pipeline defaults and workflows for selecting the appropriate GitLab Runner based on the target environment.  
Production branches are defined in pipeline-defaults.yml:
- **Production**
- **Preproduction**
- **Staging**
A development version of this branch does exist but is only used by the platform support team to test out new features and functionality within the development ecosystem.

Job definitions include:
- **React App Build**:
  - app-build: Runs the npm commands to build the React application.
  - app-container: Builds and pushes the container image to Artifactory.

- **Terraform Jobs**:
  - build-control-scripts: Executes the build control scripts to set up the environment for Terraform jobs.
  - terraform: Defines variables and common configurations for Terraform jobs.
  - plan: Executes a Terraform plan.
  - apply: Applies Terraform changes.
  - destroy: Destroys Terraform-managed resources.
  - deploy-app: Deploys the latest application image for static EC2 environments.

### Terraform Modules  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg-public-repos/terraform-modules/odx-api-modules))  
Terraform modules for deploying infrastructure:
- **Static EC2 React**: Defines a single EC2 instance with dynamic routing via Route53.
- **HPHA EC2 React**: Defines a Launch Template and Auto Scaling Group for high availability.

### Applications Group  
([Link](https://gitlab.alm.corp.hmrc.gov.uk/cmdg/cmdg-projects/cmdg-product-group-automation/odx-api/applications))  
Contains the service template and Service/Application repositories, including:
- **.gitlab-ci.yml**: Defines pipeline stages, jobs, and dependencies.
- **deployment-config.json**: Configuration for environment-specific settings.
- **USAGE.md**: Instructions for forking and implementing the template.
- **README.md**: Placeholder for documenting the project.
- **sdk-configs**: Folder containing sdk-config.json files used as part of the deployed application.

---

### Workflow for Setting Up and Managing a New Service

1. **Create a New Service Group and Project**: 
   - Navigate to **Applications** and create a private subgroup if needed.
   - Create a new project from the service template, setting a clear project name and description. Ensure this includes the required branches, such as a protected Production branch.
   - Configure merging rules if required for your project setup.

2. **Set Up Permissions (RBAC)**: 
   - Add team members to the project and assign appropriate roles and permissions.
  
3. **Initialize Environment and Configure Repository**:
   - Initialize the project with the chosen framework (e.g., React), clone the repository, and start development.
   - Push the initial build to GitLab to kick off the first pipeline.

4. **Customize Configuration**:
   - Configure files such as `deployment-config.json` and set up environment-specific SDK configurations. Include a top-level `sdk-config` file to ensure proper application build. This will be replaced by the environment-specific SDK configurations on deployment.

5. **Run Pipeline and Monitor Deployment**:
   - Push code to trigger the pipeline, monitor its progress, and deploy the infrastructure as necessary.
   - Confirm that the application is accessible at the specified URL after deployment.


### Running and Deploying the Application

Once the pipeline runs successfully, monitor the job outputs and deploy the application to the designated EC2 instance. You can view the service URL once deployment completes. Domains in ns2n space route via D4D, and external domains can route via the public internet.

### Dynatrace SaaS links:

- NonProduction: [https://ihb49563.live.dynatrace.com](https://ihb49563.live.dynatrace.com)
- PreProduction: [https://kdv79045.live.dynatrace.com](https://kdv79045.live.dynatrace.com)
- Production: [https://tey47616.live.dynatrace.com](https://tey47616.live.dynatrace.com)

