import { useTranslation } from 'react-i18next';
import { TaxDetail } from '../typings';
import { Link } from 'hmrc-gds-react-components';
import { formatTaxCode } from '../../../../../../components/helpers/utils';

interface Props {
  employerName: string;
  activeOccupationalPension: boolean;
  taxDetails: TaxDetail[];
  monthlyEarnings: number | null;
  redirectToViewTimelineDetailsPage: (pageName: string) => void;
}

const NOW_KEY = 'Now';
const BEFORE_KEY = 'Before';

const HowExplainer: React.FC<Props> = ({
  employerName,
  activeOccupationalPension,
  taxDetails,
  monthlyEarnings,
  redirectToViewTimelineDetailsPage
}) => {
  const { t } = useTranslation();

  const nowTaxCode = taxDetails.find(item => item.pyNote === NOW_KEY)?.AssignedTaxCode;
  const beforeTaxCode = taxDetails.find(item => item.pyNote === BEFORE_KEY)?.AssignedTaxCode;

  const areEarningsMore = monthlyEarnings && monthlyEarnings > 0;

  const payOrPension = activeOccupationalPension
    ? t('THROUGH_YOUR_PENSION')
    : t('THROUGH_YOUR_PAY');

  const autoOrContinue = areEarningsMore
    ? t('WE_WILL_CONTINUE_TO_COLLECT_INCOME_TAX')
    : t('WE_WILL_AUTOMATICALLY_COLLECT_TAX');

  const reduceOrIncreaseTFA = areEarningsMore ? t('AND_INCREASE_TFA') : t('AND_REDUCE_TFA');

  return (
    <>
      <p className='govuk-body'>
        {t('YOU_DO_NOT_NEED_TAKE_ACTION')} {autoOrContinue} {payOrPension} {t('AT')} {employerName}{' '}
        {reduceOrIncreaseTFA}
      </p>

      <p className='govuk-!-margin-top-3'>
        {t('THIS_MEANS_TAX_CODE_WILL_CHANGE_FROM_TO')} {formatTaxCode(beforeTaxCode)} {t('TO')}{' '}
        {formatTaxCode(nowTaxCode)}.
      </p>

      <p className='govuk-!-margin-top-3'>
        <Link
          href='#'
          onClick={e => {
            e.preventDefault();
            redirectToViewTimelineDetailsPage('WIMTC');
          }}
        >
          {t('CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA')}
        </Link>
        .
      </p>
    </>
  );
};

export default HowExplainer;
