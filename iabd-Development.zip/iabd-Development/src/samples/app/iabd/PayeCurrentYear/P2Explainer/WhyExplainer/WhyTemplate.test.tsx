import { render, screen } from '@testing-library/react';
import WhyTemplate from './WhyTemplate';
import templates from './constant/templateDetails';
import { currencyFormatter, formatDate, GBdate } from '../../../../../../components/helpers/utils';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => `T_${key}`
  })
}));

jest.mock('../../../../../../components/helpers/utils', () => ({
  currencyFormatter: jest.fn(() => '£123.00'),
  formatDate: jest.fn(() => '01 January 2024'),
  GBdate: jest.fn(() => '01/01/2024')
}));

describe('WhyTemplate Component', () => {
  const baseProps = {
    ReferenceID: 'INYEARADJUSTMENT045',
    pyActionType: 'ADDED',
    DIG_08: '123',
    DIG_16: '2024-01-01'
  };

  describe('Given missing ReferenceID', () => {
    it('Then it returns null', () => {
      const { container } = render(<WhyTemplate pyActionType='ADDED' />);
      expect(container).toBeEmptyDOMElement();
    });
  });

  describe('Given missing pyActionType', () => {
    it('Then it returns null', () => {
      const { container } = render(<WhyTemplate ReferenceID='ID_123' />);
      expect(container).toBeEmptyDOMElement();
    });
  });

  describe('Given ReferenceID without matching template', () => {
    it('Then it returns null', () => {
      const { container } = render(<WhyTemplate ReferenceID='UNKNOWN_123' pyActionType='ADDED' />);
      expect(container).toBeEmptyDOMElement();
    });
  });

  describe('Given pyActionType not found in template', () => {
    it('Then it returns null', () => {
      const { container } = render(
        <WhyTemplate ReferenceID='INYEARADJUSTMENT045' pyActionType='NOT_FOUND' />
      );
      expect(container).toBeEmptyDOMElement();
    });
  });

  describe('Given valid template with translation segments', () => {
    it('Then it renders translated text', () => {
      render(<WhyTemplate {...baseProps} />);
      expect(screen.getByText(/T_WE_HAVE_ADJUSTED_YOUR_TAX/)).toBeInTheDocument();
    });
  });

  describe('Given currency segment', () => {
    it('Then it formats currency using DIG_* props', () => {
      render(<WhyTemplate {...baseProps} />);
      expect(currencyFormatter).toHaveBeenCalledWith('123');
      expect(screen.getByText(txt => txt.includes('£123.00'))).toBeInTheDocument();
    });
  });

  describe('Given date segment', () => {
    it('Then it formats date', () => {
      render(<WhyTemplate {...baseProps} />);
      expect(formatDate).toHaveBeenCalledWith('2024-01-01');
      expect(screen.getByText(txt => txt.includes('01 January 2024'))).toBeInTheDocument();
    });
  });

  describe('Given gbDate segment', () => {
    it('Then it formats GB date', () => {
      const props = {
        ReferenceID: 'INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023',
        pyActionType: 'ADDED',
        DIG_99: '2024-01-01'
      };

      const original = templates.INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023.ADDED;
      try {
        templates.INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023.ADDED = [
          [{ type: 'gbDate', prop: 'DIG_99' }]
        ];
        render(<WhyTemplate {...props} />);
        expect(GBdate).toHaveBeenCalledWith('2024-01-01');
        expect(screen.getByText(txt => txt.includes('01/01/2024'))).toBeInTheDocument();
      } finally {
        templates.INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023.ADDED = original;
      }
    });
  });

  describe('Given number segment', () => {
    it('Then it prints numeric value', () => {
      const props = {
        ReferenceID: 'INYEARADJUSTMENT045',
        pyActionType: 'ADDED',
        DIG_17: 55
      };

      const original = templates.INYEARADJUSTMENT045.ADDED;
      templates.INYEARADJUSTMENT045.ADDED = [[{ type: 'number', prop: 'DIG_17' }]];
      try {
        render(<WhyTemplate {...props} />);
        expect(screen.getByText(content => content.includes('55'))).toBeInTheDocument();
      } finally {
        templates.INYEARADJUSTMENT045.ADDED = original;
      }
    });
  });

  describe('Given text segment', () => {
    it('Then it prints raw text value', () => {
      const props = {
        ReferenceID: 'OUTSTANDINGDEBTRESTRICTION041',
        pyActionType: 'ADDED',
        DIG_07: '123'
      };

      render(<WhyTemplate {...props} />);
      expect(screen.getByText(txt => txt.includes('.'))).toBeInTheDocument();
    });
  });

  describe('Given link segment', () => {
    it('Then it renders a link with translated text', () => {
      const props = {
        ReferenceID: 'INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023',
        pyActionType: 'ADDED'
      };

      render(<WhyTemplate {...props} />);
      expect(
        screen.getByText(txt => txt.includes('T_BANK_BUILDING_SOCIETY_INTEREST'))
      ).toBeInTheDocument();
    });
  });

  describe('Given multiple paragraphs exist', () => {
    it('Then it renders all paragraphs from template', () => {
      render(<WhyTemplate {...baseProps} />);
      expect(screen.getAllByText(/T_/).length).toBeGreaterThan(1);
    });
  });

  describe('Given DIG_* props', () => {
    it('Then it extracts only DIG_* fields for rendering', () => {
      const props = {
        ...baseProps,
        otherKey: 'ignore',
        DIG_99: 'value'
      };

      render(<WhyTemplate {...props} />);
      expect(currencyFormatter).toHaveBeenCalled();
      expect(screen.getByText(txt => txt.includes('£123.00'))).toBeInTheDocument();
    });
  });

  describe('Punctuation-aware spacing', () => {
    describe('Given next segment begins with punctuation', () => {
      it('Then it does not insert a space before the punctuation', () => {
        const props = {
          ReferenceID: 'PERSONALALLOWANCE013',
          pyActionType: 'ADDED',
          DIG_02: '123'
        };

        const original = templates.PERSONALALLOWANCE013?.ADDED;
        try {
          templates.PERSONALALLOWANCE013 = {
            ...(templates.PERSONALALLOWANCE013 as any),
            ADDED: [
              [
                { type: 't', key: 'YOUR_ADJUSTED_NET_INCOME_IS_NOW_BELOW' },
                { type: 'currency', prop: 'DIG_02' },
                { type: 'text', value: ', so you are entitled.' }
              ]
            ]
          } as any;

          render(<WhyTemplate {...props} />);

          const text = document.body.textContent?.replace(/\s+/g, ' ').trim() ?? '';

          expect(text).toContain('£123.00, so you are entitled.');

          expect(text).not.toContain('£123.00 , so');
        } finally {
          if (original) {
            (templates as any).PERSONALALLOWANCE013.ADDED = original;
          }
        }
      });
    });

    describe('Given previous segment ends with an opening bracket', () => {
      it('Then it does not insert a space after the opening bracket, nor before the closing bracket', () => {
        const props = {
          ReferenceID: 'PERSONALALLOWANCE013',
          pyActionType: 'ADDED',
          DIG_02: '123'
        };

        const original = templates.PERSONALALLOWANCE013?.ADDED;
        try {
          templates.PERSONALALLOWANCE013 = {
            ...(templates.PERSONALALLOWANCE013 as any),
            ADDED: [
              [
                { type: 'text', value: 'Amount (' },
                { type: 'currency', prop: 'DIG_02' },
                { type: 'text', value: ')' }
              ]
            ]
          } as any;

          render(<WhyTemplate {...props} />);

          const text = document.body.textContent?.replace(/\s+/g, ' ').trim() ?? '';

          expect(text).toContain('Amount (£123.00)');

          expect(text).not.toContain('Amount ( £123.00)');
          expect(text).not.toContain('£123.00 )');
        } finally {
          if (original) {
            (templates as any).PERSONALALLOWANCE013.ADDED = original;
          }
        }
      });
    });
  });
});
