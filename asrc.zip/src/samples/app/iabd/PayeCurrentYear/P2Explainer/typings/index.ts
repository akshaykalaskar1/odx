export type PyNote = 'Before' | 'Now';
export type WhyExplainerItemCategory = 'Pega' | 'React';

export type TaxDetail = {
  pyNote?: PyNote;
  AssignedTaxCode?: string | null;
};

export interface PegaContentItem {
  pyKeyString?: string;
  Description?: string | null;
  Language?: string;
}

export interface WhyExplainerItem {
  Category: WhyExplainerItemCategory;
  ReferenceID?: string;
  Content?: PegaContentItem[];
  [k: string]: any; // DIG_* and other dynamic fields for React side templates
}
export interface ExplainerData {
  MonthlyEarnings?: number;
  WhyExplainer?: WhyExplainerItem[];
  TaxDetails: TaxDetail[];
  pyTemplateDataField: string;
}
