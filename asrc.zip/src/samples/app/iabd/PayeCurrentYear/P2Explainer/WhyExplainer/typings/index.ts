export type PyActionType = 'ADDED' | 'REMOVED' | 'INCREASED' | 'DECREASED';

export type Segment =
  | { type: 't'; key: string } // for text need to be translated
  | { type: 'currency'; prop: string } // for currency / amount
  | { type: 'number'; prop: string } // a simple numeric value
  | { type: 'text'; value: string } // a simple string / as is to be displayed
  | { type: 'date'; prop: string } // Date scenario DIG_16 (20206-04-05 : 5 April 2026)
  | { type: 'gbDate'; prop: string } // Date scenario DIG_15 (20206-04-05 : 05/04/2026)
  | { type: 'link'; key: string; href: string }; // for link

export type Paragraph = Segment[];

export type Templates = Record<string, Partial<Record<PyActionType, Paragraph[]>>>;

export interface WhyItem {
  ReferenceID?: string;
  pyActionType?: string;
  [key: string]: unknown; // allow dynamic DIG_* fields
}

export interface WhyTemplateProps {
  item: WhyItem;
}
