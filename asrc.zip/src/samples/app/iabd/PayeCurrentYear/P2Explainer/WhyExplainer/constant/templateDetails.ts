import { Templates } from '../typings';

const templates: Templates = {
  PAYMENTSTOWARDSARETIREMENTANNUITY004: {
    ADDED: [
      [
        {
          type: 't',
          key: 'YOU_GET_TAX_RELIEF_TOWARDS_ANNUITY'
        }
      ],
      [{ type: 't', key: 'PLEASE_TELL_WHEN_PAY_STOP' }]
    ]
  },

  PERSONALALLOWANCE011: {
    ADDED: [
      [
        { type: 't', key: 'YOUR_ADJUSTED_NET_INCOME_IS_NOW_BELOW' },
        { type: 'currency', prop: 'DIG_02' },
        { type: 't', key: 'SO_YOU_ARE_ENTITLED_TO_SOME_PERSONAL_ALLOWANCE' }
      ],
      [{ type: 't', key: 'WE_HAVE_CHECKED_AND_INCLUDED_IN_TAX_CODE' }]
    ],
    INCREASED: [
      [{ type: 't', key: 'YOUR_PERSONAL_ALLOWANCE_HAS_DECREASED' }],
      [
        { type: 't', key: 'YOUR_ALLOWANCE_DECREASES_PROPORTIONALLY_WHEN_ABOVE' },
        { type: 'currency', prop: 'DIG_01' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  INYEARADJUSTMENT045: {
    ADDED: [
      [
        { type: 't', key: 'WE_HAVE_ADJUSTED_YOUR_TAX_BECAUSE_WE_ESTIMATE_YOU_WILL_OWE' },
        { type: 'currency', prop: 'DIG_08' },
        { type: 't', key: 'THIS_TAX_YEAR' }
      ],
      [
        { type: 't', key: 'TO_MAKE_SURE_YOU_PAY_THIS_BY' },
        { type: 'date', prop: 'DIG_16' },
        {
          type: 't',
          key: 'WE_WILL_INCREASE_THE_AMOUNT_OF_TAX_DEDUCTED_FROM_YOUR_WAGE_SALARY_OR_PENSION'
        }
      ]
    ],
    INCREASED: [
      [{ type: 't', key: 'THE_ADJUSTMENT_FOR_ESTIMATED_TAX_HAS_INCREASED' }],
      [
        { type: 't', key: 'TO_MAKE_SURE_YOU_PAY_THIS_BY' },
        { type: 'date', prop: 'DIG_16' },
        {
          type: 't',
          key: 'WE_WILL_INCREASE_THE_AMOUNT_DEDUCTED_FROM_YOUR_WAGE_SALARY_OR_PENSION'
        }
      ]
    ],
    DECREASED: [
      [{ type: 't', key: 'THE_ADJUSTMENT_FOR_ESTIMATED_TAX_HAS_DECREASED' }],
      [
        { type: 't', key: 'TO_MAKE_SURE_YOU_PAY_THIS_BY' },
        { type: 'date', prop: 'DIG_16' },
        {
          type: 't',
          key: 'WE_WILL_DECREASE_THE_AMOUNT_DEDUCTED_FROM_YOUR_WAGE_SALARY_OR_PENSION'
        }
      ]
    ]
  },

  OUTSTANDINGDEBTRESTRICTION041: {
    ADDED: [
      [
        { type: 't', key: 'YOU_HAVE_OUTSTANDING_DEBT_FROM_A_PREVIOUS_YEAR' },

        { type: 't', key: 'FOR_THIS_YEAR_WE_ARE_COLLECTING' },
        { type: 'currency', prop: 'DIG_07' },
        { type: 'text', value: '.' }
      ],
      [{ type: 't', key: 'WE_INTEND_TO_COLLECT_THIS_DEBT_IN_EQUAL_INSTALMENTS' }]
    ],
    INCREASED: [
      [
        { type: 't', key: 'THE_OUTSTANDING_DEBT_RESTRICTION_HAS_INCREASED' },

        { type: 't', key: 'FOR_THIS_YEAR_WE_ARE_COLLECTING' },
        { type: 'currency', prop: 'DIG_07' },
        { type: 'text', value: '.' }
      ],
      [{ type: 't', key: 'WE_INTEND_TO_COLLECT_THIS_DEBT_IN_EQUAL_INSTALMENTS' }]
    ],
    DECREASED: [
      [
        { type: 't', key: 'THE_OUTSTANDING_DEBT_RESTRICTION_HAS_DECREASED' },

        { type: 't', key: 'FOR_THIS_YEAR_WE_ARE_COLLECTING' },
        { type: 'currency', prop: 'DIG_07' },
        { type: 'text', value: '.' }
      ],
      [{ type: 't', key: 'WE_INTEND_TO_COLLECT_THIS_DEBT_IN_EQUAL_INSTALMENTS' }]
    ]
  },

  HICBCPAYE051: {
    ADDED: [
      [
        { type: 't', key: 'WE_NEED_TO_RECOVER_THE_CHILD_BENEFIT' },
        { type: 'currency', prop: 'DIG_03' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'WE_WILL_CHECK_THIS_WHEN_WE_REVIEW_YOUR_FINAL_TAX_POSITION' },
        { type: 'date', prop: 'DIG_16' },
        { type: 'text', value: '.' }
      ]
    ],

    DECREASED: [
      [{ type: 't', key: 'THE_HIGH_INCOME_CHILD_BENEFIT_CHARGE_DEDUCTION_HAS_DECREASED' }],
      [
        {
          type: 't',
          key: 'WE_WILL_CHECK_THIS_WHEN_WE_REVIEW_YOUR_FINAL_TAX_POSITION_FOR_THE_YEAR_TO'
        },
        { type: 'date', prop: 'DIG_16' },
        { type: 'text', value: '.' }
      ]
    ],

    INCREASED: [
      [{ type: 't', key: 'THE_HIGH_INCOME_CHILD_BENEFIT_CHARGE_DEDUCTION_HAS_INCREASED' }],
      [
        {
          type: 't',
          key: 'WE_WILL_CHECK_THIS_WHEN_WE_REVIEW_YOUR_FINAL_TAX_POSITION_FOR_THE_YEAR_TO'
        },
        { type: 'date', prop: 'DIG_16' },
        { type: 'text', value: '.' }
      ]
    ],

    REMOVED: [
      [{ type: 't', key: 'THE_HIGH_INCOME_CHILD_BENEFIT_CHARGE_DEDUCTION_NO_LONGER_APPLIES' }],
      [
        {
          type: 't',
          key: 'WE_WILL_CHECK_THIS_WHEN_WE_REVIEW_YOUR_FINAL_TAX_POSITION_FOR_THE_YEAR_TO'
        },
        { type: 'date', prop: 'DIG_16' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  CHILDBENEFIT042: {
    ADDED: [
      [
        { type: 't', key: 'WE_NEED_TO_RECOVER_THE_CHILD_BENEFIT' },
        { type: 'currency', prop: 'DIG_03' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'WE_WILL_CHECK_THIS_WHEN_WE_RECEIVE_YOUR_TAX_RETURN' },
        { type: 'date', prop: 'DIG_16' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  HIGHERPERSONALALLOWANCERESTRICTION037: {
    ADDED: [
      [
        {
          type: 't',
          key: 'TAX_RELIEF_FOR_MARRIED_COUPLES_ALLOWANCE_AND_MAINTENANCE_PAYMENTS_IS_WORTH_10_PERCENT'
        }
      ],
      [{ type: 't', key: 'SO_WE_NEED_TO_INCLUDE_THIS_RESTRICTION' }]
    ]
  },

  INTERESTWITHOUTTAXTAKENOFFGROSSINTEREST023: {
    ADDED: [
      [
        { type: 't', key: 'YOU_MAY_NEED_PAY_TAX' },
        {
          type: 'link',
          key: 'BANK_BUILDING_SOCIETY_INTEREST',
          href: 'https://www.gov.uk/apply-tax-free-interest-on-savings'
        },
        { type: 't', key: 'YOU_HAVE_EARNED' }
      ]
    ]
  },

  GIFTAIDADJUSTMENT030: {
    ADDED: [
      [
        { type: 't', key: 'YOU_DONATED_TO_A_CHARITY_THROUGH_GIFT_AID' },
        { type: 't', key: 'WE_ESTIMATE_YOU_WILL_NOT_PAY_ENOUGH_TAX' }
      ],
      [
        { type: 't', key: 'TO_COLLECT_THE_TAX_YOU_OWE' },
        { type: 't', key: 'WE_HAVE_REDUCED_YOUR_TAX_FREE_ALLOWANCE' }
      ]
    ],
    INCREASED: [
      [{ type: 't', key: 'YOUR_GIFT_AID_ADJUSTMENT_HAS_INCREASED' }],
      [{ type: 't', key: 'THIS_IS_THE_ADJUSTMENT_WE_MAKE' }]
    ],
    DECREASED: [
      [{ type: 't', key: 'YOUR_GIFT_AID_ADJUSTMENT_HAS_DECREASED' }],
      [{ type: 't', key: 'THIS_IS_THE_ADJUSTMENT_WE_MAKE' }]
    ],
    REMOVED: [
      [{ type: 't', key: 'THE_GIFT_AID_ADJUSTMENT_NO_LONGER_APPLIES' }],
      [{ type: 't', key: 'THIS_WAS_THE_ADJUSTMENT_WE_MADE' }]
    ]
  },

  UNDERPAYMENTAMOUNT035: {
    ADDED: [
      [
        { type: 't', key: 'WE_PREVIOUSLY_TOLD_YOU_THAT_YOU_OWE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_FROM_AN_EARLIER_TAX_YEAR' },
        { type: 't', key: 'WE_HAVE_INCLUDED_AN_ADJUSTMENT_TO_REDUCE_YOUR_TAX_FREE_ALLOWANCE_BY' },
        { type: 'currency', prop: 'DIG_10' },
        { type: 't', key: 'SO_WE_CAN_COLLECT_THE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_IN_EQUAL_INSTALMENTS' }
      ],
      [
        { type: 't', key: 'TO_MAKE_SURE_YOU_PAY_THE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'BY' },
        { type: 'date', prop: 'DIG_16' },
        { type: 't', key: 'WE_WILL_INCREASE_THE_AMOUNT_DEDUCTED_FROM_YOUR_WAGE_SALARY_OR_PENSION' }
      ]
    ],
    DECREASED: [
      [
        { type: 't', key: 'THE_ADJUSTMENT_INCLUDED_HAS_DECREASED' },

        { type: 't', key: 'WE_PREVIOUSLY_TOLD_YOU_THAT_YOU_OWE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_FROM_AN_EARLIER_TAX_YEAR' }
      ],
      [
        { type: 't', key: 'WE_HAVE_CHANGED_THE_ADJUSTMENT_TO_REDUCE_YOUR_ALLOWANCE_TO' },
        { type: 'currency', prop: 'DIG_10' },
        { type: 't', key: 'SO_WE_CAN_COLLECT_THE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_IN_EQUAL_INSTALMENTS_BY_5TH_OF_APRIL' },
        { type: 'text', value: '.' }
      ]
    ],
    INCREASED: [
      [
        { type: 't', key: 'THE_ADJUSTMENT_INCLUDED_HAS_INCREASED' },
        { type: 't', key: 'WE_PREVIOUSLY_TOLD_YOU_THAT_YOU_OWE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_FROM_AN_EARLIER_TAX_YEAR' }
      ],
      [
        { type: 't', key: 'WE_HAVE_CHANGED_THE_ADJUSTMENT_TO_REDUCE_YOUR_ALLOWANCE_TO' },
        { type: 'currency', prop: 'DIG_10' },
        { type: 't', key: 'SO_WE_CAN_COLLECT_THE' },
        { type: 'currency', prop: 'DIG_06' },
        { type: 't', key: 'TAX_IN_EQUAL_INSTALMENTS_BY_5TH_OF_APRIL' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  MARRIEDCOUPLESALLOWANCE016: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_MARRIED_COUPLES_ALLOWANCE' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BASED_ON_YOUR_TOTAL_INCOME_IF_YOU_ARE_MARRIED_OR_IN_A_CIVIL_PARTNERSHIP_AND_LIVING_TOGETHER_AND_AT_LEAST_ONE_PARTNER_WAS_BORN_BEFORE'
        },
        { type: 'number', prop: 'DIG_14' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'TAX_RELIEF_IS_GIVEN_AT_PERCENT_OF_THE_ALLOWANCE' },
        { type: 'number', prop: 'DIG_17' },
        { type: 't', key: 'PERCENT_OF_THE_ALLOWANCE' }
      ]
    ]
  },

  MARRIEDCOUPLESALLOWANCE017: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_MARRIED_COUPLES_ALLOWANCE' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BASED_ON_YOUR_TOTAL_INCOME_IF_YOU_ARE_MARRIED_OR_IN_A_CIVIL_PARTNERSHIP_AND_LIVING_TOGETHER_AND_AT_LEAST_ONE_PARTNER_WAS_BORN_BEFORE'
        },
        { type: 'number', prop: 'DIG_14' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'TAX_RELIEF_IS_GIVEN_AT_PERCENT_OF_THE_ALLOWANCE' },
        { type: 'number', prop: 'DIG_17' },
        { type: 't', key: 'PERCENT_OF_THE_ALLOWANCE' }
      ]
    ]
  },

  MARRIEDCOUPLESALLOWANCE018: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_MARRIED_COUPLES_ALLOWANCE' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BASED_ON_YOUR_TOTAL_INCOME_IF_YOU_ARE_MARRIED_OR_IN_A_CIVIL_PARTNERSHIP_AND_LIVING_TOGETHER_AND_AT_LEAST_ONE_PARTNER_WAS_BORN_BEFORE'
        },
        { type: 'number', prop: 'DIG_14' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'TAX_RELIEF_IS_GIVEN_AT_PERCENT_OF_THE_ALLOWANCE' },
        { type: 'number', prop: 'DIG_17' },
        { type: 't', key: 'PERCENT_OF_THE_ALLOWANCE' }
      ]
    ]
  },

  MARRIEDCOUPLESALLOWANCEFROMHUSBAND019: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_MARRIED_COUPLES_ALLOWANCE' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BASED_ON_YOUR_TOTAL_INCOME_IF_YOU_ARE_MARRIED_OR_IN_A_CIVIL_PARTNERSHIP_AND_LIVING_TOGETHER_AND_AT_LEAST_ONE_PARTNER_WAS_BORN_BEFORE'
        },
        { type: 'number', prop: 'DIG_14' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'TAX_RELIEF_IS_GIVEN_AT_PERCENT_OF_THE_ALLOWANCE' },
        { type: 'number', prop: 'DIG_17' },
        { type: 't', key: 'PERCENT_OF_THE_ALLOWANCE' }
      ]
    ]
  },

  MARRIEDCOUPLESALLOWANCEFROMHUSBAND020: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_MARRIED_COUPLES_ALLOWANCE' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BASED_ON_YOUR_TOTAL_INCOME_IF_YOU_ARE_MARRIED_OR_IN_A_CIVIL_PARTNERSHIP_AND_LIVING_TOGETHER_AND_AT_LEAST_ONE_PARTNER_WAS_BORN_BEFORE'
        },
        { type: 'number', prop: 'DIG_14' },
        { type: 'text', value: '.' }
      ],
      [
        { type: 't', key: 'TAX_RELIEF_IS_GIVEN_AT_PERCENT_OF_THE_ALLOWANCE' },
        { type: 'number', prop: 'DIG_17' },
        { type: 't', key: 'PERCENT_OF_THE_ALLOWANCE' }
      ]
    ]
  },

  PERSONALALLOWANCE: {
    DECREASED: [
      [{ type: 't', key: 'YOUR_PERSONAL_ALLOWANCE_HAS_DECREASED' }],
      [
        {
          type: 't',
          key: 'YOUR_ALLOWANCE_DECREASES_PROPORTIONALLY_WHEN_YOUR_ADJUSTED_NET_INCOME_IS_ABOVE'
        },
        { type: 'currency', prop: 'DIG_01' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  PERSONALALLOWANCE013: {
    ADDED: [
      [
        { type: 't', key: 'YOUR_ADJUSTED_NET_INCOME_IS_NOW_BELOW' },
        { type: 'currency', prop: 'DIG_02' },
        { type: 't', key: 'SO_YOU_ARE_ENTITLED_TO_SOME_PERSONAL_ALLOWANCE' }
      ],
      [{ type: 't', key: 'WE_HAVE_CHECKED_HOW_MUCH_AND_INCLUDED_THIS_IN_YOUR_TAX_CODE' }]
    ],
    INCREASED: [
      [{ type: 't', key: 'YOUR_PERSONAL_ALLOWANCE_HAS_DECREASED' }],
      [
        {
          type: 't',
          key: 'YOUR_ALLOWANCE_DECREASES_PROPORTIONALLY_WHEN_YOUR_ADJUSTED_NET_INCOME_IS_ABOVE'
        },
        { type: 'currency', prop: 'DIG_01' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  PERSONALALLOWANCE012: {
    ADDED: [
      [
        { type: 't', key: 'YOUR_ADJUSTED_NET_INCOME_IS_NOW_BELOW' },
        { type: 'currency', prop: 'DIG_02' },
        { type: 't', key: 'SO_YOU_ARE_ENTITLED_TO_SOME_PERSONAL_ALLOWANCE' }
      ],
      [{ type: 't', key: 'WE_HAVE_CHECKED_AND_INCLUDED_IN_TAX_CODE' }]
    ],
    INCREASED: [
      [{ type: 't', key: 'YOUR_PERSONAL_ALLOWANCE_HAS_DECREASED' }],
      [
        {
          type: 't',
          key: 'YOUR_ALLOWANCE_DECREASES_PROPORTIONALLY_WHEN_YOUR_ADJUSTED_NET_INCOME_IS_ABOVE'
        },
        { type: 'currency', prop: 'DIG_01' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  PERSONALALLOWANCERECEIVEDFROMPARTNER032: {
    ADDED: [
      [
        {
          type: 't',
          key: 'YOUR_SPOUSE_OR_REGISTERED_CIVIL_PARTNER_APPLIED_TO_TRANSFER_ALLOWANCE'
        }
      ],
      [
        { type: 't', key: 'FROM_DATE_THE_AMOUNT_YOU_CAN_RECEIVE_IS' },
        { type: 'gbDate', prop: 'DIG_15' },
        { type: 't', key: 'THE_AMOUNT_YOU_CAN_RECEIVE_IS' },
        { type: 'currency', prop: 'DIG_09' },
        { type: 'text', value: '.' }
      ]
    ],
    REMOVED: [
      [{ type: 't', key: 'YOU_NO_LONGER_HAVE_TRANSFER_OF_ALLOWANCE' }],
      [{ type: 't', key: 'THIS_COULD_BE_BECAUSE_YOU_COMMUNICATED_A_CHANGE' }]
    ]
  },

  WINTERPAYMENTTAXCHARGE052: {
    ADDED: [
      [{ type: 't', key: 'YOU_NEED_TO_REPAY_THE_WINTER_PAYMENT' }],
      [
        {
          type: 't',
          key: 'THIS_IS_BECAUSE_WE_ESTIMATE_THAT_YOUR_TOTAL_INCOME_WILL_BE_MORE_THAN'
        },
        { type: 'currency', prop: 'DIG_04' },
        { type: 'text', value: '.' }
      ]
    ]
  },

  STATEPENSIONSTATEBENEFITS001: {
    ADDED: [
      [{ type: 't', key: 'YOU_GET_STATE_PENSION_OR_TAXABLE_BENEFITS' }],
      [{ type: 't', key: 'IF_FIRST_TAX_YEAR_WE_MAY_HAVE_INCLUDED_FULL_AMOUNT' }],
      [{ type: 't', key: 'YOU_DO_NOT_PAY_NI_WHEN_REACH_STATE_PENSION_AGE' }]
    ],
    DECREASED: [
      [
        {
          type: 't',
          key: 'THE_AMOUNT_OF_STATE_PENSION_AND_OR_OTHER_TAXABLE_BENEFITS_HAS_DECREASED'
        }
      ],
      [{ type: 't', key: 'IF_YOUR_STATE_PENSION_IS_PAID_EVERY_FOUR_WEEKS' }]
    ],
    INCREASED: [
      [
        {
          type: 't',
          key: 'THE_AMOUNT_OF_STATE_PENSION_AND_OR_OTHER_TAXABLE_BENEFITS_HAS_INCREASED'
        }
      ],
      [{ type: 't', key: 'IF_YOUR_STATE_PENSION_IS_PAID_EVERY_FOUR_WEEKS' }]
    ]
  },

  OTHEREARNINGSORPENSION029: {
    INCREASED: [
      [
        { type: 't', key: 'WE_HAVE_INCREASED_THE_AMOUNT_OF_TAX_FREE_ALLOWANCES_ALLOCATED' },
        { type: 'currency', prop: 'DIG_05' },
        { type: 'text', value: '.' }
      ],
      [
        {
          type: 't',
          key: 'THIS_COULD_INCLUDE_ALLOWANCES_ALLOCATED_TO_ENDED_EMPLOYMENTS_OR_PENSIONS'
        }
      ]
    ],
    DECREASED: [
      [
        { type: 't', key: 'WE_HAVE_REDUCED_THE_AMOUNT_OF_TAX_FREE_ALLOWANCES_ALLOCATED' },
        { type: 'currency', prop: 'DIG_05' },
        { type: 'text', value: '.' }
      ],
      [
        {
          type: 't',
          key: 'THIS_COULD_INCLUDE_ALLOWANCES_ALLOCATED_TO_ENDED_EMPLOYMENTS_OR_PENSIONS'
        }
      ]
    ]
  }
};

export default templates;
