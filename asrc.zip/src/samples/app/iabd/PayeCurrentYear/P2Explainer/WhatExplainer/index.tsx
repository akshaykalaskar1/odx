import { useTranslation } from 'react-i18next';
import { currencyFormatter, formatTaxCode } from '../../../../../../components/helpers/utils';
import { Link } from 'hmrc-gds-react-components';
import { TaxDetail } from '../typings';

interface Props {
  monthlyEarnings: number | null;
  isActivePension?: boolean;
  redirectToViewTimelineDetailsPage: (pageName: string) => void;
  taxDetails: TaxDetail[];
}

const WhatExplainer: React.FC<Props> = ({
  monthlyEarnings,
  isActivePension,
  redirectToViewTimelineDetailsPage,
  taxDetails
}) => {
  const { t } = useTranslation();
  const areEarningsMore = monthlyEarnings > 0;
  const earningsLabel = isActivePension ? t('INCOME') : t('EARNING');
  const NOW_KEY = 'Now';
  const BEFORE_KEY = 'Before';

  const nowTaxCode = taxDetails.find(item => item.pyNote === NOW_KEY).AssignedTaxCode;
  const beforeTaxCode = taxDetails.find(item => item.pyNote === BEFORE_KEY).AssignedTaxCode;

  if (!monthlyEarnings) {
    return (
      <>
        <p className='govuk-!-margin-top-3'>
          {t('YOUR_TAX_CODE_WILL_CHANGE_FROM')} {formatTaxCode(beforeTaxCode)} {t('TO')}{' '}
          {formatTaxCode(nowTaxCode)}. {t('BASED_ON_CURRENT')}{' '}
          {isActivePension
            ? t('INCOME_WE_ESTIMATE_AMOUT_TAX_YOU_NOT_CHANGE')
            : t('EARNINGS_WE_ESTIMATE_AMOUT_TAX_YOU_NOT_CHANGE')}
        </p>
        <p className='govuk-!-margin-top-3'>
          <Link
            href='#'
            onClick={e => {
              e.preventDefault();
              redirectToViewTimelineDetailsPage('WIMTC');
            }}
          >
            {t('CHECK_HOW_WE_WORKED_OUT_YOUR_NEW_CODE_AND_TFA')}
          </Link>
          .
        </p>
      </>
    );
  }

  return (
    <>
      <p className='govuk-body'>
        {t('BASED_ON_CURRENT')} {earningsLabel} {t('WE_ESTIMATE_YOU_PAY')}{' '}
        {currencyFormatter(Math.abs(monthlyEarnings))} {areEarningsMore ? t('LESS') : t('MORE')}{' '}
        {t('EVERY_MONTH')}
      </p>

      <p className='govuk-body'>
        {t('THIS_AMOUNT_IS_AN_ESTIMATE')} {earningsLabel} {t('COULD_CHANGE_IN_FUTURE')}
      </p>
    </>
  );
};

export default WhatExplainer;
