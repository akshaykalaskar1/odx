import { render, screen, fireEvent, act } from '@testing-library/react';
import P2Explainer from '.';
import { AnalyticsConfigProvider } from 'hmrc-odx-features-and-functions';
import useServiceShuttered from '../../../../../components/helpers/hooks/useServiceShuttered';

const mockApiCallback = jest.fn();
const mockGetDataAsync = jest.fn();

jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  AnalyticsConfigProvider: ({ children }: any) => <>{children}</>,
  withPageTracking: (Comp: any) => Comp
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({
    t: (key: string) => key
  })
}));

jest.mock('../../../../../components/helpers/hooks/useServiceShuttered');

jest.mock('../../../../../components/helpers/LoadingSpinner/LoadingWrapper', () => ({
  __esModule: true,
  default: ({ children, pageIsLoading }: any) =>
    pageIsLoading ? <div>LOADING</div> : <>{children}</>
}));

jest.mock('../../../../../components/AppComponents/ShutterService/ShutteredServiceWrapper', () => ({
  __esModule: true,
  default: ({ children }: any) => <>{children}</>
}));

jest.mock('../../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  default: ({ onClick }: any) => (
    <button type='button' onClick={onClick}>
      Back
    </button>
  )
}));

jest.mock('../../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <>{children}</>
}));

jest.mock('../../../../../components/helpers/utils', () => ({
  formatDate: (d: any) => `formatted-${d}`,
  getHeadingContent: () => ({ Description: 'Mock Heading' })
}));

jest.mock('./WhyExplainer', () => ({
  __esModule: true,
  default: ({ items }: any) => (
    <div>WHY_EXPLAINER: {Array.isArray(items) ? JSON.stringify(items) : String(items)}</div>
  )
}));

jest.mock('./WhatExplainer', () => ({
  __esModule: true,
  default: ({ monthlyEarnings }: any) => <div>WHAT_EXPLAINER: {monthlyEarnings}</div>
}));

jest.mock('./HowExplainer', () => ({
  __esModule: true,
  default: ({ employerName }: any) => <div>HOW_EXPLAINER: {employerName}</div>
}));

jest.mock('./P2ExplainerDetails', () => ({
  __esModule: true,
  default: ({ timelineDetails, explainerData, eventType, redirectCurrentYearPage }: any) => {
    const monthly = explainerData?.MonthlyEarnings ?? null;
    const whyItems = explainerData?.WhyExplainer ?? [];
    return (
      <>
        <div>WE_ARE_CHANGING_YOUR_TAX_CODE_FOR</div>
        <div>{timelineDetails?.EmployerName}</div>
        <div>{timelineDetails?.EmployerName}</div>
        <div>{`formatted-${timelineDetails?.DisplayDate}`}</div>
        <div>WHY_EXPLAINER: {JSON.stringify(whyItems)}</div>
        <div>WHAT_EXPLAINER: {monthly}</div>
        {monthly ? <div>HOW_EXPLAINER: {timelineDetails?.EmployerName}</div> : null}
        <button type='button' onClick={() => eventType === 'event' && redirectCurrentYearPage()}>
          Back
        </button>
      </>
    );
  }
}));

jest.mock('../../ErrorPage/errorMessage', () => ({
  __esModule: true,
  default: () => <div>Error</div>
}));

jest.mock('../../../../../components/helpers/setPageTitleHelpers', () => jest.fn());

(global as any).PCore = {
  getDataPageUtils: () => ({
    getDataAsync: mockGetDataAsync
  })
};

describe('P2Explainer', () => {
  const baseTimeline = {
    EmploymentType: 'FULL',
    EmploymentSequenceNumber: 123,
    NetCodedAllowance: '100',
    ActiveOccupationalPension: true,
    EmployerName: 'Tesco',
    IntegerSortingHolder: 999,
    issuedtaxCode: 'AA111',
    Content: [{ Description: 'heading' }],
    DisplayDate: '2025-10-01'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    (useServiceShuttered as unknown as jest.Mock).mockReturnValue({
      serviceShuttered: false,
      isLoading: false
    });
  });

  describe('Given the component mounts', () => {
    describe('When the API returns successful data', () => {
      const mockData = {
        MonthlyEarnings: 500,
        WhyExplainer: [{ a: 1 }],
        TaxDetails: [{ x: 1 }],
        pyTemplateDataField: 'P2ExplainerPage'
      };

      beforeEach(() => {
        mockGetDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [mockData]
              }
            }
          ]
        });
      });

      it('Then it renders heading, summaries and snapshot', async () => {
        let container: any;
        await act(async () => {
          const rendered = render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={jest.fn()}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
          container = rendered.container;
        });

        expect(await screen.findByText(/WE_ARE_CHANGING_YOUR_TAX_CODE_FOR/i)).toBeInTheDocument();
        expect(screen.getAllByText(/^Tesco$/i)).toHaveLength(2);
        expect(screen.getByText('formatted-2025-10-01')).toBeInTheDocument();
        expect(screen.getByText(/WHY_EXPLAINER:/i)).toHaveTextContent('[{"a":1}]');
        expect(screen.getByText(/WHAT_EXPLAINER:/i)).toHaveTextContent('500');
        expect(screen.getByText(/HOW_EXPLAINER:/i)).toHaveTextContent('Tesco');
        expect(container).toMatchSnapshot();
      });
    });

    describe('When the API returns MonthlyEarnings as zero', () => {
      const mockData = {
        MonthlyEarnings: 0,
        WhyExplainer: [],
        TaxDetails: []
      };

      beforeEach(() => {
        mockGetDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [mockData]
              }
            }
          ]
        });
      });

      it('Then it renders Why and What but not How', async () => {
        await act(async () => {
          render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={jest.fn()}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
        });

        expect(screen.getByText(/WHAT_EXPLAINER:/i)).toHaveTextContent('0');
        expect(screen.getByText(/WHY_EXPLAINER:/i)).toHaveTextContent('[]');
        expect(screen.queryByText(/HOW_EXPLAINER:/i)).toBeNull();
      });
    });

    describe('When the API returns pyErrors with messages', () => {
      beforeEach(() => {
        mockGetDataAsync.mockResolvedValue({
          data: [
            {
              pyErrors: {
                pyMessages: [{ pyErrorMessage: ['Some error'] }]
              }
            }
          ]
        });
      });

      it('Then it renders the ErrorMessage', async () => {
        await act(async () => {
          render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={jest.fn()}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
        });

        expect(await screen.findByText(/Error/i)).toBeInTheDocument();
        expect(screen.queryByText(/WHAT_EXPLAINER:/i)).toBeNull();
        expect(screen.queryByText(/WHY_EXPLAINER:/i)).toBeNull();
      });
    });

    describe('When the API throws an error', () => {
      beforeEach(() => {
        mockGetDataAsync.mockRejectedValue(new Error('fetch error'));
      });

      it('Then it renders the ErrorMessage and matches snapshot', async () => {
        let container: any;
        await act(async () => {
          const rendered = render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={jest.fn()}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
          container = rendered.container;
        });

        expect(await screen.findByText(/Error/i)).toBeInTheDocument();
        expect(container).toMatchSnapshot();
      });
    });

    describe('When the service is shuttered', () => {
      it('Then the data page is not called and details render with null data', async () => {
        (useServiceShuttered as unknown as jest.Mock).mockReturnValue({
          serviceShuttered: true,
          isLoading: false
        });

        await act(async () => {
          render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={jest.fn()}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
        });

        expect(mockGetDataAsync).not.toHaveBeenCalled();
        expect(screen.getByText(/WE_ARE_CHANGING_YOUR_TAX_CODE_FOR/i)).toBeInTheDocument();
        expect(screen.getAllByText(/^Tesco$/i)).toHaveLength(2);
        expect(screen.getByText('formatted-2025-10-01')).toBeInTheDocument();
      });
    });
  });

  describe('Given the user clicks the back button', () => {
    describe('When eventType is event', () => {
      it('Then it triggers redirectCurrentYearPage', async () => {
        mockGetDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [{ MonthlyEarnings: 0, WhyExplainer: [], TaxDetails: [] }]
              }
            }
          ]
        });

        const redirectMock = jest.fn();

        await act(async () => {
          render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={redirectMock}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='event'
              />
            </AnalyticsConfigProvider>
          );
        });

        fireEvent.click(screen.getByText('Back'));
        expect(redirectMock).toHaveBeenCalled();
      });
    });

    describe('When eventType is not event', () => {
      it('Then redirectCurrentYearPage is not called', async () => {
        mockGetDataAsync.mockResolvedValue({
          data: [
            {
              Customer: {
                TaxSummaryList: [{ MonthlyEarnings: 0, WhyExplainer: [], TaxDetails: [] }]
              }
            }
          ]
        });

        const redirectMock = jest.fn();

        await act(async () => {
          render(
            <AnalyticsConfigProvider apiCallback={mockApiCallback}>
              <P2Explainer
                redirectCurrentYearPage={redirectMock}
                redirectToViewTimelineDetailsPage={jest.fn()}
                timelineDetails={baseTimeline}
                eventType='other'
              />
            </AnalyticsConfigProvider>
          );
        });

        fireEvent.click(screen.getByText('Back'));
        expect(redirectMock).not.toHaveBeenCalled();
      });
    });
  });
});
