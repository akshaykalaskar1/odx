import { useTranslation } from 'react-i18next';
import { Heading, SummaryListRow } from 'hmrc-gds-react-components';
import Button from '../../../../../components/BaseComponents/Button/Button';
import MainWrapperFull from '../../../../../components/BaseComponents/MainWrapper/MainWrapperFull';
import { formatDate, getHeadingContent } from '../../../../../components/helpers/utils';
import WhyExplainer from './WhyExplainer';
import WhatExplainer from './WhatExplainer';
import HowExplainer from './HowExplainer';
import { TimeLineEvent } from '../../../../../reuseables/Types/TimeLineEvents';
import type { ExplainerData } from './typings';
import { withPageTracking } from 'hmrc-odx-features-and-functions';

interface P2ExplainerDetailsProps {
  redirectCurrentYearPage: () => void;
  redirectToViewTimelineDetailsPage: () => void;
  timelineDetails: Partial<TimeLineEvent>;
  eventType: string;
  explainerData: ExplainerData | null;
}

function P2ExplainerDetails({
  redirectCurrentYearPage,
  redirectToViewTimelineDetailsPage,
  timelineDetails,
  eventType,
  explainerData
}: P2ExplainerDetailsProps) {
  const { t } = useTranslation();

  return (
    <>
      <Button
        variant='backlink'
        onClick={e => {
          e.preventDefault();
          if (eventType === 'event') {
            redirectCurrentYearPage();
          }
        }}
        key='ViewTimelineBacklink'
        attributes={{ type: 'link' }}
      />
      <MainWrapperFull title={getHeadingContent(timelineDetails?.Content, 'en')?.Description}>
        <div className='govuk-grid-row'>
          <div className='govuk-grid-column-two-thirds'>
            <Heading headingLevel={1} className='govuk-heading-l govuk-!-margin-bottom-2'>
              {t('WE_ARE_CHANGING_YOUR_TAX_CODE_FOR')} {timelineDetails.EmployerName}
            </Heading>

            <p className='govuk-hint'>{formatDate(timelineDetails.DisplayDate)}</p>

            <dl className='govuk-summary-list'>
              <SummaryListRow
                label={t('WHY_IT_CHANGED')}
                value={<WhyExplainer items={explainerData?.WhyExplainer} />}
              />
              <SummaryListRow
                label={t('WHAT_THIS_MEANS_FOR_YOU')}
                value={
                  <WhatExplainer
                    monthlyEarnings={explainerData?.MonthlyEarnings}
                    isActivePension={timelineDetails?.ActiveOccupationalPension}
                    redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
                    taxDetails={explainerData.TaxDetails}
                  />
                }
              />
              {explainerData?.MonthlyEarnings !== undefined &&
                explainerData.MonthlyEarnings !== 0 && (
                  <SummaryListRow
                    label={t('HOW_WE_WILL_COLLECT_IT')}
                    value={
                      <HowExplainer
                        employerName={timelineDetails.EmployerName}
                        activeOccupationalPension={timelineDetails.ActiveOccupationalPension}
                        monthlyEarnings={explainerData?.MonthlyEarnings}
                        taxDetails={explainerData.TaxDetails}
                        redirectToViewTimelineDetailsPage={redirectToViewTimelineDetailsPage}
                      />
                    }
                  />
                )}
            </dl>
            <Heading headingLevel={2} className='govuk-heading-m'>
              {t('WHAT_HAPPENS_NEXT')}
            </Heading>
            <p className='govuk-body'>
              {t('THIS_IS_FOR_INFO_ONLY_NOT_DO_ANYTHING_UNLESS_CHANGED')}
            </p>
          </div>
        </div>
      </MainWrapperFull>
    </>
  );
}

export default withPageTracking(P2ExplainerDetails);
