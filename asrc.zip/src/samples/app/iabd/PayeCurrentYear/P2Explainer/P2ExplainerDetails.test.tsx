import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import P2ExplainerDetails from './P2ExplainerDetails';
import { ExplainerData } from './typings';

jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  withPageTracking: (Comp: any) => Comp
}));

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (k: string) => k })
}));

jest.mock('../../../../../components/BaseComponents/Button/Button', () => ({
  __esModule: true,
  // eslint-disable-next-line react/button-has-type
  default: ({ onClick }: any) => <button onClick={onClick}>Back</button>
}));

jest.mock('../../../../../components/BaseComponents/MainWrapper/MainWrapperFull', () => ({
  __esModule: true,
  default: ({ children }: any) => <>{children}</>
}));

jest.mock('../../../../../components/helpers/utils', () => ({
  formatDate: (d: any) => `formatted-${d}`,
  getHeadingContent: () => ({ Description: 'Mock Heading' })
}));

jest.mock('./WhyExplainer', () => ({
  __esModule: true,
  default: ({ items }: any) => (
    <div>WHY_EXPLAINER: {Array.isArray(items) ? JSON.stringify(items) : String(items)}</div>
  )
}));

jest.mock('./WhatExplainer', () => ({
  __esModule: true,
  default: ({ monthlyEarnings }: any) => <div>WHAT_EXPLAINER: {monthlyEarnings}</div>
}));

jest.mock('./HowExplainer', () => ({
  __esModule: true,
  default: ({ employerName }: any) => <div>HOW_EXPLAINER: {employerName}</div>
}));

describe('P2ExplainerDetails', () => {
  const baseTimeline: any = {
    EmployerName: 'Tesco',
    ActiveOccupationalPension: true,
    Content: [{ Description: 'heading' }],
    DisplayDate: '2025-10-01'
  };

  describe('Given valid explainer data', () => {
    describe('When MonthlyEarnings is non-zero', () => {
      it('Then it renders heading, formatted date, Why, What and How', () => {
        render(
          <P2ExplainerDetails
            redirectCurrentYearPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
            timelineDetails={baseTimeline}
            eventType='event'
            explainerData={
              {
                MonthlyEarnings: 250,
                WhyExplainer: [{ reason: 'X' } as any],
                TaxDetails: [{ code: 'A' } as any]
              } as any
            }
          />
        );

        expect(screen.getByText(/WE_ARE_CHANGING_YOUR_TAX_CODE_FOR/i)).toBeInTheDocument();
        expect(screen.getByText('formatted-2025-10-01')).toBeInTheDocument();
        expect(screen.getByText(/WHY_EXPLAINER:/i)).toHaveTextContent('[{"reason":"X"}]');
        expect(screen.getByText(/WHAT_EXPLAINER:/i)).toHaveTextContent('250');
        expect(screen.getByText(/HOW_EXPLAINER:/i)).toHaveTextContent('Tesco');
      });
    });

    describe('When MonthlyEarnings is zero', () => {
      it('Then it renders Why and What but not How', () => {
        render(
          <P2ExplainerDetails
            redirectCurrentYearPage={jest.fn()}
            redirectToViewTimelineDetailsPage={jest.fn()}
            timelineDetails={baseTimeline}
            eventType='event'
            explainerData={
              {
                MonthlyEarnings: 0,
                WhyExplainer: [],
                TaxDetails: []
              } as any
            }
          />
        );

        expect(screen.getByText(/WHAT_EXPLAINER:/i)).toHaveTextContent('0');
        expect(screen.getByText(/WHY_EXPLAINER:/i)).toHaveTextContent('[]');
        expect(screen.queryByText(/HOW_EXPLAINER:/i)).toBeNull();
      });
    });
  });

  describe('Given the user clicks back', () => {
    describe('When eventType is event', () => {
      it('Then it calls redirectCurrentYearPage', () => {
        const redirectMock = jest.fn();

        render(
          <P2ExplainerDetails
            redirectCurrentYearPage={redirectMock}
            redirectToViewTimelineDetailsPage={jest.fn()}
            timelineDetails={baseTimeline}
            eventType='event'
            explainerData={
              {
                MonthlyEarnings: 0,
                WhyExplainer: [],
                TaxDetails: []
              } as ExplainerData
            }
          />
        );

        fireEvent.click(screen.getByText('Back'));
        expect(redirectMock).toHaveBeenCalled();
      });
    });

    describe('When eventType is not event', () => {
      it('Then redirectCurrentYearPage is not called', () => {
        const redirectMock = jest.fn();

        render(
          <P2ExplainerDetails
            redirectCurrentYearPage={redirectMock}
            redirectToViewTimelineDetailsPage={jest.fn()}
            timelineDetails={baseTimeline}
            eventType='other'
            explainerData={
              {
                MonthlyEarnings: 0,
                WhyExplainer: [],
                TaxDetails: []
              } as ExplainerData
            }
          />
        );

        fireEvent.click(screen.getByText('Back'));
        expect(redirectMock).not.toHaveBeenCalled();
      });
    });
  });
});
