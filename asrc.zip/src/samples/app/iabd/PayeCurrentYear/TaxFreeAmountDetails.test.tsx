import React from 'react';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom';
import TaxFreeAmountDetails from './TaxFreeAmountDetails';
import { mockGetSdkConfigWithBasepath } from '../../../../../tests/mocks/getSdkConfigMock';
import { act } from 'react-dom/test-utils';
import * as DeductionUtilsModule from './TaxCodeDeduction/DeductionUtils';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({ t: (k: string) => k })
}));


jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn()
}));


jest.mock('./TaxCodeDeduction/DeductionUtils', () => ({
  __esModule: true,
  default: jest.fn()
}));

jest.mock('./TaxCodeDeduction/DeductionHintText', () => ({
  __esModule: true,
  default: ({ explainerPage }: any) => (
    <div data-test-id="deduction-hint">DeductionHintText: {explainerPage}</div>
  )
}));


jest.mock('hmrc-odx-features-and-functions', () => ({
  __esModule: true,
  EventType: { Outbound: 'Outbound' },
  InteractionTracker: jest.fn().mockImplementation(() => ({
    logEvent: jest.fn()
  }))
}));

const TEST_PAGE = 'TestPage';

const EXPLAINER_PAGES = {
  UNTAXED_SAVINGS: 'untaxedsavingsinterest',
  WINTER_FUEL: 'winterfuelpaymentcharge'
};

const buildContent = (name: string) => [
  { pyKeyString: name, Language: 'EN', Name: name },
  { pyKeyString: name, Language: 'CY', Name: `${name} - Welsh` }
];

const buildTESLink = (name: string, url: string) => [
  {
    Content: [
      {
        pyKeyString: name,
        Language: 'EN',
        pyURLContent: url,
        Name: name
      },
      {
        pyKeyString: name,
        Language: 'CY',
        pyURLContent: url,
        Name: `${name} - Welsh`
      }
    ]
  }
];

const buildDeduction = ({
  name,
  explainerPage,
  adjustedAmount = '100',
  sourceAmount = '100'
}: {
  name: string;
  explainerPage?: string;
  adjustedAmount?: string;
  sourceAmount?: string;
}) => ({
  Content: buildContent(name),
  TESLinks: explainerPage ? buildTESLink(name, explainerPage) : undefined,
  AdjustedAmount: adjustedAmount,
  SourceAmount: sourceAmount
});

const renderComponent = async ({
  allowances = [],
  personalAllowances = [],
  deductions = [],
  handleLinkClick = jest.fn(),
  redirectToDeductionExplainerpage = jest.fn()
} = {}) => {
  mockGetSdkConfigWithBasepath();

  await act(async () => {
    render(
      <TaxFreeAmountDetails
        allowances={allowances}
        personalAllowances={personalAllowances}
        deductions={deductions}
        handleLinkClick={handleLinkClick}
        redirectToDeductionExplainerpage={redirectToDeductionExplainerpage}
        comingFrom={TEST_PAGE}
      />
    );
  });

  return { handleLinkClick, redirectToDeductionExplainerpage };
};

afterEach(cleanup);


describe('Tax free amount details behaviour', () => {
  describe('Given explainer deductions are present', () => {
    test.each([
      {
        scenario: 'Untaxed savings interest explainer',
        deduction: buildDeduction({
          name: 'Untaxed savings interest',
          explainerPage: EXPLAINER_PAGES.UNTAXED_SAVINGS,
          adjustedAmount: '200',
          sourceAmount: '200'
        }),
        expectedPage: EXPLAINER_PAGES.UNTAXED_SAVINGS,
        expectedSourceAmount: '200'
      },
      {
        scenario: 'Winter fuel payment charge explainer',
        deduction: buildDeduction({
          name: 'Winter Fuel Payment Charge',
          explainerPage: EXPLAINER_PAGES.WINTER_FUEL,
          adjustedAmount: '300',
          sourceAmount: '600'
        }),
        expectedPage: EXPLAINER_PAGES.WINTER_FUEL,
        expectedSourceAmount: '600'
      }
    ])(
      'When the user clicks the explainer link, then they are redirected to the explainer page',
      async ({ deduction, expectedPage, expectedSourceAmount }) => {
        // known explainer → redirect branch
        (DeductionUtilsModule.default as jest.Mock).mockReturnValue(true);

        const { redirectToDeductionExplainerpage } = await renderComponent({
          deductions: [deduction]
        });

        const link = screen.getByText(deduction.Content[0].Name);
        fireEvent.click(link);

        expect(redirectToDeductionExplainerpage).toHaveBeenCalledWith(
          TEST_PAGE,
          expectedPage,
          expectedSourceAmount
        );
      }
    );
  });
});


describe('Additional coverage for TaxFreeAmountDetails', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('renders plain text instead of link for WinterFuelPaymentCharge', async () => {
    const winterDeduction = {
      Content: buildContent('Winter Fuel Payment Charge'),
      TESLinks: buildTESLink('Winter Fuel Payment Charge', 'WinterFuelPaymentCharge'),
      AdjustedAmount: '200',
      SourceAmount: '200'
    };

    await renderComponent({
      deductions: [winterDeduction]
    });

    expect(screen.getByText('Winter Fuel Payment Charge')).toBeInTheDocument();
    expect(screen.queryByRole('link')).not.toBeInTheDocument();
  });

  test('logs outbound event and calls handleLinkClick for unknown explainer', async () => {
    const handleLinkClick = jest.fn();
    const deduction = buildDeduction({
      name: 'Unknown Link',
      explainerPage: 'SomeRandomUnknownPage'
    });

    (DeductionUtilsModule.default as jest.Mock).mockReturnValue(false);

    await renderComponent({
      deductions: [deduction],
      handleLinkClick
    });

    const link = screen.getByText('Unknown Link');
    fireEvent.click(link);

    expect(handleLinkClick).toHaveBeenCalledWith('SomeRandomUnknownPage');
  });

  test('renders DeductionHintText when explainer page is known', async () => {

    (DeductionUtilsModule.default as jest.Mock).mockReturnValue(true);

    const deduction = buildDeduction({
      name: 'Known deduction',
      explainerPage: 'knowntaxpage'
    });

    await renderComponent({
      deductions: [deduction]
    });

    expect(screen.getByTestId('deduction-hint')).toBeInTheDocument();
  });

  test('renders deduction content when TESLinks missing', async () => {
    const deduction = {
      Content: buildContent('Some Deduction'),
      AdjustedAmount: '150'
    };

    await renderComponent({ deductions: [deduction] });

    expect(screen.getByText('Some Deduction')).toBeInTheDocument();
    expect(screen.getByText('£150')).toBeInTheDocument();
  });


  test('renders main heading HOW_TAX_CODE_CALCULATED', async () => {
    await renderComponent();
    expect(
      screen.getByRole('heading', { name: 'HOW_TAX_CODE_CALCULATED', level: 2 })
    ).toBeInTheDocument();
  });

  test('renders personal allowances list', async () => {
    const personalAllowances = [
      {
        Content: buildContent('Personal Allowance'),
        AdjustedAmount: '12500'
      }
    ];

    await renderComponent({ personalAllowances });


    expect(screen.getByText('Personal Allowance')).toBeInTheDocument();

    expect(screen.getByText('£12,500')).toBeInTheDocument();
  });

  test('renders allowances list and its section heading', async () => {
    const allowances = [
      {
        Content: buildContent('Blind Person Allowance'),
        AdjustedAmount: '2500'
      }
    ];

    await renderComponent({ allowances });


    expect(
      screen.getByText('WHAT_INCREASE_YOUR_TAX_FREE_AMOUNT')
    ).toBeInTheDocument();


    expect(screen.getByText('Blind Person Allowance')).toBeInTheDocument();
    expect(screen.getByText('£2,500')).toBeInTheDocument();
  });
});
