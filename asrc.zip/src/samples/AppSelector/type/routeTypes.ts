export type PayeRouteState = {
  details?: any;
  comingFromPage?: string;
  timelineDetails?: any;
  eventType?: string;
  componentName?: string;
  understandYourTaxDetails?: any;
  fromPage?: string;
  templateValue?: string;
  pageName?: string;
  sourceAmount?: string;
  employmentSequenceNumber?: number;
  previousPage?: string;
};

export type IabdOutletContext = {
  customerDetails: any;
  employmentTaxData: any;
  setEmploymentTaxData: React.Dispatch<React.SetStateAction<any>>;
  dynamicIABDVals: any;
  dynamicDisabledIABDDetails: boolean;
  annualCodingData: any;
  taxYearStartDate: string;
  handleLinkClick: (...args: any[]) => void;
  beginClaim: () => void;
  beginIntrruptionPage: (...args: any[]) => void;
  beginUpdateClaim: () => void;
  beginAddPensionClaim: () => void;
  beginUpdatePensionClaim: () => void;
  redirectLandingPage: () => void;
  redirectCurrentYearPage: () => void;
  redirectToAllIABDLandingPage: (fromPage: string) => void;
  redirecLatestEventPage: (fromPage: string) => void;
  redirectToUnderstandYourTaxPage: () => void;
  redirectToViewTimelineDetailsPage: (fromPage?: string) => void;
  redirectAnnualCodingTemplatePage: (args: { templateValue: string; pageName: string }) => void;
  redirectToDeductionExplainerpage: (
    comingFrom: string,
    explainerPage: string,
    sourceAmount: string
  ) => void;
  handleViewAllDetailsClick: (detail: any) => void;
  handleViewDetailsClick: (timeline: any, event: string) => void;
  handleUnderstandYourTaxCodeClick: (
    understandYourTax: any,
    taxCode: string,
    fromPage: string
  ) => void;
  handleDetailExplainerLinkClick: (componentName: string) => void;
  goBack: () => void;
  navClickHandler: any;
  startNow: (e: React.MouseEvent<HTMLAnchorElement>, caseType: string) => void;
  setComingFromPage: React.Dispatch<React.SetStateAction<string>>;
};
