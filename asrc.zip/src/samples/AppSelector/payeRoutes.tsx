const PAYE_ROUTES = {
  landing: '/paye',
  summary: '/paye/summary',
  otherIncome: '/paye/summary/other-income-allowances-benefits-deductions',
  addEmployment: '/paye/summary/add-employment',
  addPension: '/paye/summary/add-pension',

  // TES redirection not supported for below routes
  updateEmployment: '/paye/summary/end-employment',
  updatePension: '/paye/summary/end-pension',

  // Below routes needs semantic names
  latestEvents: '/paye/latest-events',
  viewAllDetails: '/paye/view-all-details',
  viewTimelineDetails: '/paye/summary/view-timeline-details', // WIMTC
  p2Explainer: '/paye/summary/p2-explainer', // P2
  detailExplainer: '/paye/detail-explainer',
  understandYourTax: '/paye/understand-your-tax',
  understandYourTaxSpecial: '/paye/understand-your-tax-special',
  annualCoding: '/paye/annual-coding',
  winterFuelPayment: '/paye/winter-fuel-payment',
  untaxedSavingsInterest: '/paye/untaxed-savings-interest',
  winterFuelPaymentCharge: '/paye/winter-fuel-payment-charge',
  interruption: '/paye/interruption'
} as const;

export default PAYE_ROUTES;
