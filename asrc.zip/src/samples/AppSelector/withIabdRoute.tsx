import React from 'react';
import { useLocation, useOutletContext } from 'react-router-dom';
import { IabdOutletContext, PayeRouteState } from './type/routeTypes';

type MapProps<TProps> = (args: { outlet: IabdOutletContext; state: PayeRouteState }) => TProps;

const withIabdRoute = <TProps extends object>(
  Component: React.ComponentType<TProps>,
  mapProps: MapProps<TProps>
) => {
  const WrappedComponent = () => {
    const outlet = useOutletContext<IabdOutletContext>();
    const location = useLocation();
    const state = (location.state || {}) as PayeRouteState;

    const props = mapProps({ outlet, state });

    return <Component {...props} />;
  };

  WrappedComponent.displayName = `withIabdRoute(${Component.displayName || Component.name || 'Component'})`;

  return WrappedComponent;
};

export default withIabdRoute;
