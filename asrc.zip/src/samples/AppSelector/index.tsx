import React, { useEffect, useState } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { initReactI18next } from 'react-i18next';
import Backend from 'i18next-http-backend';
import i18n from 'i18next';
import Iabd from '../app/iabd/index';
import CookiePage from '../app/iabd/cookiePage/index';
import Accessibility from '../app/iabd/AccessibilityPage';
import ErrorMessage from '../app/iabd/ErrorPage/errorMessage';
import NoP45InfoPage from '../app/iabd/NoP45InfoPage/NoP45InfoPage';
import ProtectedRoute from '../../components/HOC/ProtectedRoute';
import NoP45PensionInfo from '../app/iabd/NoP45InfoPage/NoP45PensionInfo';
import SignoutConfirmationPage from '../../components/AppComponents/Signout';
import {
  ViewTimelineDetailsRoute,
  DetailExplainerRoute,
  UnderstandYourTaxRoute,
  UnderstandYourTaxSpecialRoute,
  WinterFuelPaymentRoute,
  UntaxedSavingsInterestRoute,
  WinterFuelPaymentChargeRoute,
  InterruptionRoute,
  AddEmploymentRoute,
  AddPensionRoute,
  AnnualCodingRoute,
  LatestEventsRoute,
  OtherIncomeRoute,
  PayeLandingRoute,
  PayeSummaryRoute,
  UpdateEmploymentRoute,
  UpdatePensionRoute,
  ViewAllDetailsRoute,
  P2ExplainerRoute
} from './payeRoutesWrapper';

import PAYE_ROUTES from './payeRoutes';

const AppSelector = () => {
  const location = useLocation();
  const [i18nloaded, seti18nloaded] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const urlLang = params.get('lang');

    const initialLang = urlLang || sessionStorage.getItem('rsdk_locale')?.substring(0, 2) || 'en';

    if (urlLang) {
      sessionStorage.setItem('rsdk_locale', urlLang);
    }

    i18n
      .use(Backend)
      .use(initReactI18next)
      .init({
        lng: initialLang,
        backend: {
          /* translation file path */
          loadPath: `assets/i18n/{{lng}}.json`
        },
        fallbackLng: 'en',
        debug: false,
        returnNull: false,
        react: {
          useSuspense: false
        }
      })
      .finally(() => {
        seti18nloaded(true);
      });
  }, [location.search]);

  if (!i18nloaded) return null;

  return (
    <Routes>
      <Route path='/' element={<Navigate to={PAYE_ROUTES.landing} replace />} />

      <Route path={PAYE_ROUTES.landing} element={<ProtectedRoute component={Iabd} />}>
        <Route index element={<PayeLandingRoute />} />
        <Route path={PAYE_ROUTES.summary} element={<PayeSummaryRoute />} />
        <Route path={PAYE_ROUTES.otherIncome} element={<OtherIncomeRoute />} />
        <Route path={PAYE_ROUTES.latestEvents} element={<LatestEventsRoute />} />
        <Route path={PAYE_ROUTES.viewAllDetails} element={<ViewAllDetailsRoute />} />
        <Route path={PAYE_ROUTES.viewTimelineDetails} element={<ViewTimelineDetailsRoute />} />
        <Route path={PAYE_ROUTES.p2Explainer} element={<P2ExplainerRoute />} />
        <Route path={PAYE_ROUTES.detailExplainer} element={<DetailExplainerRoute />} />
        <Route path={PAYE_ROUTES.understandYourTax} element={<UnderstandYourTaxRoute />} />
        <Route
          path={PAYE_ROUTES.understandYourTaxSpecial}
          element={<UnderstandYourTaxSpecialRoute />}
        />
        <Route path={PAYE_ROUTES.annualCoding} element={<AnnualCodingRoute />} />
        <Route path={PAYE_ROUTES.winterFuelPayment} element={<WinterFuelPaymentRoute />} />
        <Route
          path={PAYE_ROUTES.untaxedSavingsInterest}
          element={<UntaxedSavingsInterestRoute />}
        />
        <Route
          path={PAYE_ROUTES.winterFuelPaymentCharge}
          element={<WinterFuelPaymentChargeRoute />}
        />

        {/* Landing routes who triggers Pega journey */}
        <Route path={PAYE_ROUTES.addEmployment} element={<AddEmploymentRoute />} />
        <Route path={PAYE_ROUTES.updateEmployment} element={<UpdateEmploymentRoute />} />
        <Route path={PAYE_ROUTES.addPension} element={<AddPensionRoute />} />
        <Route path={PAYE_ROUTES.updatePension} element={<UpdatePensionRoute />} />
        {/* Landing routes who triggers Pega journey */}

        <Route path={PAYE_ROUTES.interruption} element={<InterruptionRoute />} />
      </Route>

      <Route path='/cookies' element={<CookiePage />} />
      <Route path='/accessibility' element={<Accessibility />} />
      <Route path='/error' element={<ErrorMessage />} />
      <Route path='/no-information' element={<NoP45InfoPage />} />
      <Route path='/no-pension-info' element={<NoP45PensionInfo />} />
      <Route path='/signout' element={<SignoutConfirmationPage />} />
    </Routes>
  );
};

export default AppSelector;
