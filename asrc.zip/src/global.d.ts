interface Window {
  dataLayer: any[];
}
