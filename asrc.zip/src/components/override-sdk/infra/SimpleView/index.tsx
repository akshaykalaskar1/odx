export { default } from './SimpleView';
